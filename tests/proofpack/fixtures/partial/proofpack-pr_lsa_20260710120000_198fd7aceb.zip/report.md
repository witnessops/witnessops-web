# WitnessOps Local Server Audit

## Result first

The bounded collection contract outcome is **PARTIAL** for proof run ` pr_lsa_20260710120000_198fd7aceb `.
One or more required v1 collection sections is incomplete; inspect the signed failure states and collection-completeness artifact.
This outcome concerns authority admission, bounded collection, artifact binding, and package construction. It is not a conclusion that the host is secure, uncompromised, or compliant.

## Named target and boundary

- Asset id: ` asset-demo-host-001 `
- Observed hostname: ` demo-host `
- Profile: ` linux_baseline_v1 `
- Observed at: ` 2026-07-10T12:00:00Z `
- Execution: operator-present, local, read-only
- Processes, command lines, environment variables, credentials, cookies, tokens, private keys, user documents, event logs, memory, and network discovery were excluded.

## Deterministic posture findings

- Critical: 0
- High: 0
- Medium: 0
- Low: 0
- Informational: 1

### INFORMATIONAL — ` Security-update classification could not be established `

- Finding id: ` lsa_updates_unknown `
- State: ` unresolved `
- Evidence: ` posture.sections.updates.security_classification `
- Observed value: ` {"cache_freshness": "unknown", "command_status": "captured", "diagnostic_reason": "Cached update plan does not classify security updates.", "provider": "apt", "returncode": 0, "security_classification": "unavailable"} `
- Recommendation: ` Review security advisory metadata in a separately authorized follow-up; the successful query established a planned update count without classifying security updates. `
- Limit: ` The planned update count uses local cached metadata. Security-update classification and cache freshness were not established. `

## SSH evaluation context

- Evaluated SSH context: Not recorded in the supplied posture; evaluation context is unknown.
- Findings apply to the recorded evaluation context. Other users, source addresses and SSH Match contexts are outside this check.

## Collection gaps

- updates: ` {"cache_freshness": "unknown", "command_status": "captured", "diagnostic_reason": "Cached update plan does not classify security updates.", "provider": "apt", "returncode": 0, "security_classification": "unavailable", "status": "partial"} `

Gap details summarize structured collection metadata. Raw command output is not reproduced; incomplete fields require review of the named posture and completeness artifacts.

## Verification path

Use the delivered ZIP, detached signature, SHA-256 sidecar, and a separately obtained trust registry with `witnessops-local-audit verify`.
The verifier checks bounded inputs, the ZIP signature, receipt signature, trust-registry key admission, portable ZIP and package-tree safety, receipt-to-manifest binding, artifact hashes, strict claim semantics, reconstructed collection completeness, compatibility receipt equality, prohibited-class declarations, and embedded verifier reconstruction.

## Trust assumptions and unresolved gaps

- The external authority source is represented by its declared identity and SHA-256 digest; v1 does not validate the source signer's identity.
- The collector reports local observations; source-system honesty and kernel integrity are not independently established.
- A package-provided public key is not a trust anchor. Trust comes from the separately supplied registry.
- No network reachability, exploitability, compromise, historical activity, or compliance conclusion is included.
