# WitnessOps Local Server Audit

## Result first

The bounded collection contract outcome is **PASS** for proof run ` pr_lsa_20260710120000_198fd7aceb `.
Every required v1 collection section reached its admitted complete status.
This outcome concerns authority admission, bounded collection, artifact binding, and package construction. It is not a conclusion that the host is secure, uncompromised, or compliant.

## Named target and boundary

- Asset id: ` asset-demo-host-001 `
- Observed hostname: ` demo-host `
- Profile: ` linux_baseline_v1 `
- Observed at: ` 2026-07-10T12:00:00Z `
- Execution: operator-present, local, read-only
- Processes, command lines, environment variables, credentials, cookies, tokens, private keys, user documents, event logs, memory, and network discovery were excluded.

## Deterministic posture findings

- Critical: 0
- High: 5
- Medium: 6
- Low: 7
- Informational: 1

### HIGH — ` Authorized-key file metadata fell outside the admitted baseline `

- Finding id: ` lsa_authorized_keys_metadata `
- State: ` observed `
- Evidence: ` posture.sections.privileged_access `
- Observed value: ` {"root_authorized_keys": {"admitted": false, "mode": "0666", "owner_uid": 0, "status": "observed"}, "unsafe_file_count": 1} `
- Recommendation: ` Review ownership and permissions separately before changing SSH access. `
- Limit: ` Key contents, validity and authentication activity were not collected. `

### HIGH — ` Critical account or privilege file metadata fell outside the admitted baseline `

- Finding id: ` lsa_critical_file_metadata `
- State: ` observed `
- Evidence: ` posture.sections.critical_files.files `
- Observed value: ` [{"admitted": false, "group": "root", "mode": "0666", "owner": "root", "path": "/etc/passwd", "status": "observed"}] `
- Recommendation: ` Review ownership and permissions before changing them; preserve service-specific exceptions. `
- Limit: ` File contents and distribution-specific policy were not assessed. `

### HIGH — ` SSH configuration permits direct root login in an unconfirmed evaluation context `

- Finding id: ` lsa_ssh_root_login `
- State: ` observed `
- Evidence: ` posture.sections.ssh.permit_root_login `
- Observed value: ` "yes" `
- Recommendation: ` Review an attributable administrator account, working privilege elevation and recovery access before considering disabling direct root SSH login. `
- Limit: ` The supplied posture does not record a confirmed root/loopback evaluation context. This does not prove that root login was used or externally reachable. `

### HIGH — ` Sudoers drop-in metadata fell outside the admitted baseline `

- Finding id: ` lsa_sudoers_dropin_metadata `
- State: ` observed `
- Evidence: ` posture.sections.privileged_access.unsafe_sudoers_metadata_count `
- Observed value: ` 1 `
- Recommendation: ` Review affected metadata and validate syntax before making any privilege change. `
- Limit: ` Sudoers contents and effective direct grants were not assessed. `

### HIGH — ` More than one UID 0 account was observed `

- Finding id: ` lsa_uid0_multiple `
- State: ` observed `
- Evidence: ` posture.sections.accounts.uid0_account_count `
- Observed value: ` 2 `
- Recommendation: ` Review whether every UID 0 account is required and separately attributable. `
- Limit: ` Account names and authentication activity were not collected. `

### MEDIUM — ` Failed system services were observed `

- Finding id: ` lsa_failed_services `
- State: ` observed `
- Evidence: ` posture.sections.services.failed_units `
- Observed value: ` ["backup.service"] `
- Recommendation: ` Review each failed unit against the host's intended service inventory. `
- Limit: ` A failed unit is not by itself evidence of compromise or business impact. `

### MEDIUM — ` Host firewall default inbound policy allows traffic `

- Finding id: ` lsa_firewall_default_allow `
- State: ` observed `
- Evidence: ` posture.sections.firewall.inbound_policy `
- Observed value: ` "allow" `
- Recommendation: ` Confirm that every inbound service is intended and change the default policy only with a recovery path. `
- Limit: ` Rule order, upstream controls and external reachability were not tested. `

### MEDIUM — ` The host reports a pending reboot `

- Finding id: ` lsa_reboot_required `
- State: ` observed `
- Evidence: ` posture.sections.updates.reboot_required `
- Observed value: ` true `
- Recommendation: ` Schedule a controlled reboot with service and recovery checks. `
- Limit: ` The marker does not identify the package or guarantee that a reboot resolves every pending update. `

### MEDIUM — ` Cached package metadata reports available security updates `

- Finding id: ` lsa_security_updates_available `
- State: ` observed `
- Evidence: ` posture.sections.updates.security_update_count `
- Observed value: ` 2 `
- Recommendation: ` Review and schedule the security updates through the host's normal change process. `
- Limit: ` The scan used local cached metadata and did not refresh repositories or install packages. `

### MEDIUM — ` SSH password authentication is enabled in an unconfirmed evaluation context `

- Finding id: ` lsa_ssh_password_auth `
- State: ` observed `
- Evidence: ` posture.sections.ssh.password_authentication `
- Observed value: ` "yes" `
- Recommendation: ` Review attributable administrator access, working privilege elevation and key-based recovery before considering disabling password authentication. `
- Limit: ` The supplied posture does not record a confirmed root/loopback evaluation context. This does not prove weak passwords, exposure, or successful authentication. `

### MEDIUM — ` Listening endpoints fell outside the declared listener baseline `

- Finding id: ` lsa_unexpected_listener `
- State: ` observed `
- Evidence: ` posture.sections.listeners.unexpected_endpoints `
- Observed value: ` [{"address": "0.0.0.0", "port": 22, "transport": "tcp"}, {"address": "0.0.0.0", "port": 8080, "transport": "tcp"}, {"address": "::", "port": 443, "transport": "tcp"}, {"address": "0.0.0.0", "port": 53, "transport": "udp"}] `
- Recommendation: ` Identify the owning service and confirm each endpoint before changing or stopping it. `
- Limit: ` The declared listener baseline does not independently establish service intent. Process identifiers and external reachability were not collected. `

### LOW — ` Host clock reported not synchronized `

- Finding id: ` lsa_clock_unsynchronized `
- State: ` observed `
- Evidence: ` posture.sections.clock.ntp_synchronized `
- Observed value: ` false `
- Recommendation: ` Restore approved time synchronization and record the source used. `
- Limit: ` The collector did not compare the clock against an independent time authority. `

### LOW — ` No enabled AppArmor or enforcing SELinux state was established `

- Finding id: ` lsa_mandatory_access_control `
- State: ` observed `
- Evidence: ` posture.sections.hardening `
- Observed value: ` {"apparmor_enabled": false, "selinux_enforcing": false} `
- Recommendation: ` Confirm the host's intended mandatory-access-control policy and platform support. `
- Limit: ` This is a posture observation, not proof that workload isolation is ineffective. `

### LOW — ` Kernel protection is disabled: fs.protected_hardlinks `

- Finding id: ` lsa_sysctl_fs_protected_hardlinks `
- State: ` observed `
- Evidence: ` posture.sections.hardening.sysctl.fs.protected_hardlinks `
- Observed value: ` "0" `
- Recommendation: ` Review enabling this protection against the host's workload and recovery requirements. `
- Limit: ` A bounded configuration observation; platform exceptions and exploitability require analyst review. `

### LOW — ` Kernel protection is disabled: fs.protected_symlinks `

- Finding id: ` lsa_sysctl_fs_protected_symlinks `
- State: ` observed `
- Evidence: ` posture.sections.hardening.sysctl.fs.protected_symlinks `
- Observed value: ` "0" `
- Recommendation: ` Review enabling this protection against the host's workload and recovery requirements. `
- Limit: ` A bounded configuration observation; platform exceptions and exploitability require analyst review. `

### LOW — ` Kernel protection is disabled: kernel.dmesg_restrict `

- Finding id: ` lsa_sysctl_kernel_dmesg_restrict `
- State: ` observed `
- Evidence: ` posture.sections.hardening.sysctl.kernel.dmesg_restrict `
- Observed value: ` "0" `
- Recommendation: ` Review enabling this protection against the host's workload and recovery requirements. `
- Limit: ` A bounded configuration observation; platform exceptions and exploitability require analyst review. `

### LOW — ` Kernel protection is disabled: kernel.kptr_restrict `

- Finding id: ` lsa_sysctl_kernel_kptr_restrict `
- State: ` observed `
- Evidence: ` posture.sections.hardening.sysctl.kernel.kptr_restrict `
- Observed value: ` "0" `
- Recommendation: ` Review enabling this protection against the host's workload and recovery requirements. `
- Limit: ` A bounded configuration observation; platform exceptions and exploitability require analyst review. `

### LOW — ` Kernel protection is disabled: kernel.unprivileged_bpf_disabled `

- Finding id: ` lsa_sysctl_kernel_unprivileged_bpf_disabled `
- State: ` observed `
- Evidence: ` posture.sections.hardening.sysctl.kernel.unprivileged_bpf_disabled `
- Observed value: ` "0" `
- Recommendation: ` Review enabling this protection against the host's workload and recovery requirements. `
- Limit: ` A bounded configuration observation; platform exceptions and exploitability require analyst review. `

### INFORMATIONAL — ` Expected listening endpoints were not observed `

- Finding id: ` lsa_expected_listener_missing `
- State: ` observed `
- Evidence: ` posture.sections.listeners.missing_endpoints `
- Observed value: ` [{"address": "127.0.0.1", "port": 22, "transport": "tcp"}] `
- Recommendation: ` Confirm whether the endpoint in the declared listener baseline is intentionally absent or bound to a different address. `
- Limit: ` A point-in-time local socket view does not establish service availability over time. `

## SSH evaluation context

- Evaluated SSH context: Not recorded in the supplied posture; evaluation context is unknown.
- Findings apply to the recorded evaluation context. Other users, source addresses and SSH Match contexts are outside this check.

## Collection gaps

No required collection gaps were identified from the supplied posture.

Gap details summarize structured collection metadata. Raw command output is not reproduced; incomplete fields require review of the named posture and completeness artifacts.

## Verification path

Use the delivered ZIP, detached signature, SHA-256 sidecar, and a separately obtained trust registry with `witnessops-local-audit verify`.
The verifier checks bounded inputs, the ZIP signature, receipt signature, trust-registry key admission, portable ZIP and package-tree safety, receipt-to-manifest binding, artifact hashes, strict claim semantics, reconstructed collection completeness, compatibility receipt equality, prohibited-class declarations, and embedded verifier reconstruction.

## Trust assumptions and unresolved gaps

- The external authority source is represented by its declared identity and SHA-256 digest; v1 does not validate the source signer's identity.
- The collector reports local observations; source-system honesty and kernel integrity are not independently established.
- A package-provided public key is not a trust anchor. Trust comes from the separately supplied registry.
- No network reachability, exploitability, compromise, historical activity, or compliance conclusion is included.
