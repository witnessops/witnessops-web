from __future__ import annotations

from datetime import datetime, timezone
import ipaddress
import re
from typing import Any

from .canonical import canonical_json_bytes, exact_keys, parse_utc, sha256_bytes
from .contracts import ADMISSION_SCHEMA, AUTHORITY_SCHEMA, PROFILE_ID, PROHIBITED_ARTIFACT_CLASSES, SHA256_RE


def _hostname(value: str) -> str:
    return value.strip().rstrip(".").casefold()


def _operator_declaration_errors(source: dict[str, Any]) -> list[str]:
    if source.get("kind") != "operator_declared_scope":
        return ["operator_declaration is only allowed for operator_declared_scope"] if "operator_declaration" in source else []
    declaration = source.get("operator_declaration")
    if not isinstance(declaration, dict):
        return ["operator_declared_scope requires an operator_declaration object"]
    errors = exact_keys(declaration, {"customer", "purpose", "expected_ssh_exposure"})
    for field in ("customer", "purpose"):
        value = declaration.get(field)
        if (
            not isinstance(value, str)
            or not value.strip()
            or len(value) > 256
            or any(ord(character) < 32 or 127 <= ord(character) <= 159 or character in "\u2028\u2029" for character in value)
        ):
            errors.append(f"operator_declaration.{field} must be a non-empty single-line string of at most 256 characters")
    if declaration.get("expected_ssh_exposure") not in ("public", "private", "none"):
        errors.append("operator_declaration.expected_ssh_exposure must be public, private, or none")
    if not errors and source.get("artifact_sha256") != sha256_bytes(canonical_json_bytes(declaration)):
        errors.append("authority_source.artifact_sha256 does not match operator_declaration")
    return errors


def normalize_listener_address(address: str) -> str:
    """Normalize numeric socket addresses without losing IPv6 interface scope."""
    if not isinstance(address, str) or not address.strip() or len(address) > 255:
        raise ValueError("listener address must be a numeric IP address")
    value = address.strip()
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    if value == "*":
        return value
    host, separator, scope = value.partition("%")
    if separator and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,64}", scope):
        raise ValueError("invalid listener interface scope")
    try:
        parsed = ipaddress.ip_address(host)
    except ValueError as exc:
        raise ValueError("listener address must be a numeric IP address") from exc
    # ss appends the interface to IPv4 binds too. It is not part of the IP.
    # For IPv6 link-local addresses the zone disambiguates the endpoint.
    return str(parsed) + ("%" + scope if separator and parsed.version == 6 else "")


def normalize_expected_listeners(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list) or len(value) > 200:
        raise ValueError("target.expected_listeners must be an array of at most 200 endpoints")
    normalized: list[dict[str, Any]] = []
    seen: set[tuple[str, str, int]] = set()
    for item in value:
        if not isinstance(item, dict) or set(item) != {"transport", "address", "port"}:
            raise ValueError("each expected listener must contain transport, address, and port")
        transport = str(item["transport"]).casefold()
        address = normalize_listener_address(item["address"])
        port = item["port"]
        if transport not in {"tcp", "udp"} or not address or len(address) > 255 or type(port) is not int or not 1 <= port <= 65535:
            raise ValueError("invalid expected listener endpoint")
        key = (transport, address, port)
        if key in seen:
            raise ValueError("duplicate expected listener endpoint")
        seen.add(key)
        normalized.append({"transport": transport, "address": address, "port": port})
    return sorted(normalized, key=lambda item: (item["transport"], item["address"], item["port"]))


def validate_authority_shape(record: Any) -> list[str]:
    if not isinstance(record, dict):
        return ["authority must be an object"]
    errors = exact_keys(
        record,
        {
            "schema",
            "authorization_id",
            "case_id",
            "authority_source",
            "operator_id",
            "target",
            "profile_id",
            "authorization_window",
            "execution_mode",
            "allowed_actions",
            "prohibited_artifact_classes",
        },
    )
    if record.get("schema") != AUTHORITY_SCHEMA:
        errors.append("unsupported authority schema")
    for field in ("authorization_id", "case_id", "operator_id"):
        if not isinstance(record.get(field), str) or not record[field].strip():
            errors.append(f"{field} must be a non-empty string")
    source = record.get("authority_source")
    if not isinstance(source, dict):
        errors.append("authority_source must be an object")
    else:
        errors.extend(
            f"authority_source: {item}"
            for item in exact_keys(source, {"kind", "authority_identity", "artifact_sha256", "approved_at_utc"}, {"operator_declaration"})
        )
        errors.extend(_operator_declaration_errors(source))
        if not SHA256_RE.fullmatch(str(source.get("artifact_sha256", ""))):
            errors.append("authority_source.artifact_sha256 must be lowercase SHA-256 hex")
        try:
            parse_utc(str(source.get("approved_at_utc", "")))
        except ValueError as exc:
            errors.append(f"authority_source.approved_at_utc: {exc}")
    target = record.get("target")
    if not isinstance(target, dict):
        errors.append("target must be an object")
    else:
        errors.extend(f"target: {item}" for item in exact_keys(target, {"asset_id", "allowed_hostnames", "expected_listeners"}))
        allowed = target.get("allowed_hostnames")
        if not isinstance(allowed, list) or not allowed or any(not isinstance(item, str) or not item.strip() for item in allowed):
            errors.append("target.allowed_hostnames must be a non-empty string array")
        try:
            normalize_expected_listeners(target.get("expected_listeners"))
        except ValueError as exc:
            errors.append(str(exc))
    window = record.get("authorization_window")
    if not isinstance(window, dict):
        errors.append("authorization_window must be an object")
    else:
        errors.extend(f"authorization_window: {item}" for item in exact_keys(window, {"starts_at_utc", "ends_at_utc"}))
        try:
            start = parse_utc(str(window.get("starts_at_utc", "")))
            end = parse_utc(str(window.get("ends_at_utc", "")))
            if start >= end:
                errors.append("authorization_window start must precede end")
        except ValueError as exc:
            errors.append(f"authorization_window: {exc}")
    if record.get("profile_id") != PROFILE_ID:
        errors.append("profile_id is not admitted by v1")
    if record.get("execution_mode") != "operator_present_local":
        errors.append("execution_mode must be operator_present_local")
    actions = record.get("allowed_actions")
    if not isinstance(actions, list) or actions != ["read_only_posture_collection"]:
        errors.append("allowed_actions must be exactly [read_only_posture_collection]")
    prohibited = record.get("prohibited_artifact_classes")
    if not isinstance(prohibited, list) or not PROHIBITED_ARTIFACT_CLASSES.issubset(set(prohibited)):
        errors.append("authority must prohibit every v1 prohibited artifact class")
    return errors


def evaluate_authority(
    record: Any,
    *,
    observed_hostname: str,
    operator_id: str,
    evaluation_time: datetime | None = None,
) -> dict[str, Any]:
    now = (evaluation_time or datetime.now(timezone.utc)).astimezone(timezone.utc)
    reasons = validate_authority_shape(record)
    checks: dict[str, str] = {}

    if reasons:
        checks["authority_shape"] = "failed"
    else:
        checks["authority_shape"] = "passed"
        operator_ok = record["operator_id"] == operator_id
        checks["operator_match"] = "passed" if operator_ok else "failed"
        if not operator_ok:
            reasons.append("operator_id is outside authority")

        allowed = {_hostname(item) for item in record["target"]["allowed_hostnames"]}
        host_ok = _hostname(observed_hostname) in allowed
        checks["target_hostname_match"] = "passed" if host_ok else "failed"
        if not host_ok:
            reasons.append("observed hostname is outside authority")

        start = parse_utc(record["authorization_window"]["starts_at_utc"])
        end = parse_utc(record["authorization_window"]["ends_at_utc"])
        window_ok = start <= now <= end
        checks["authorization_window"] = "passed" if window_ok else "failed"
        if not window_ok:
            reasons.append("evaluation time is outside authority window")

        checks["profile_binding"] = "passed"
        checks["read_only_action_binding"] = "passed"
        checks["prohibited_classes_bound"] = "passed"

    return {
        "schema": ADMISSION_SCHEMA,
        "decision": "ADMIT" if not reasons else "DENY",
        "authorization_id": record.get("authorization_id") if isinstance(record, dict) else None,
        "case_id": record.get("case_id") if isinstance(record, dict) else None,
        "operator_id": operator_id,
        "observed_hostname": observed_hostname,
        "evaluated_at_utc": now.replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "checks": checks,
        "reasons": reasons,
        "boundary": "admission decision only; it does not validate the honesty of the external authority source",
    }
