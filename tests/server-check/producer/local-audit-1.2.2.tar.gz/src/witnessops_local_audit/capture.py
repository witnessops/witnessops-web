"""Unsigned internal transport. Correspondence is not authenticated host evidence."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Any

from .authority import evaluate_authority, normalize_expected_listeners
from .canonical import canonical_json_bytes, parse_utc, write_bytes_new, write_text_new
from .collector import build_posture, validate_observations
from .assessment import check_observation_authority

SCHEMA = "witnessops.local_server_audit.capture.v1"
MAX_CAPTURE_BYTES = 25 * 1024 * 1024
FIELDS = {"schema", "product_version", "authority", "operator_id", "hostname", "admitted_at",
          "finished_at", "collector_hash", "mode", "observations"}


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate capture JSON key")
        result[key] = value
    return result


def validate_capture(data: bytes) -> tuple[dict[str, Any], dict[str, Any]]:
    if not isinstance(data, bytes) or not 0 < len(data) <= MAX_CAPTURE_BYTES:
        raise ValueError("capture size is outside bounds")
    try:
        c = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite number")))
        if canonical_json_bytes(c) != data:
            raise ValueError("capture must use canonical JSON encoding")
        if not isinstance(c, dict) or set(c) != FIELDS or c["schema"] != SCHEMA or c["product_version"] != "1.2.2":
            raise ValueError("unsupported capture contract")
        if c["mode"] not in ("fixture", "live_approved") or not isinstance(c["collector_hash"], str) or not re.fullmatch(r"[a-f0-9]{64}", c["collector_hash"]):
            raise ValueError("invalid capture mode or collector fingerprint")
        if not all(isinstance(c[k], str) and c[k] for k in ("operator_id", "hostname", "admitted_at", "finished_at")):
            raise ValueError("invalid capture identity/time")
        o = c["observations"]
        validate_observations(o, allow_live=True)
        if set(o) != {"schema", "observed_at_utc", "target", "profile_id", "sections", "command_evidence", "declared_exclusions", "declared_side_effects", "synthetic", "data_classification"}:
            raise ValueError("unknown observation fields")
        if not all(isinstance(o[k], list) and all(isinstance(v, str) for v in o[k])
                   for k in ("declared_exclusions", "declared_side_effects")):
            raise ValueError("invalid observation declarations")
        if (c["mode"] == "fixture") != o["synthetic"]:
            raise ValueError("synthetic/live classification mismatch")
        start, observed, end = (parse_utc(v) for v in (c["admitted_at"], o["observed_at_utc"], c["finished_at"]))
        if not start <= observed <= end:
            raise ValueError("capture times out of order")
        admission = evaluate_authority(c["authority"], observed_hostname=c["hostname"], operator_id=c["operator_id"], evaluation_time=start)
        finish = evaluate_authority(c["authority"], observed_hostname=c["hostname"], operator_id=c["operator_id"], evaluation_time=end)
        if admission["decision"] != "ADMIT" or finish["decision"] != "ADMIT":
            raise ValueError("capture outside admitted authority")
        check_observation_authority(c["authority"], o, c["operator_id"])
        if o["target"]["hostname"] != c["hostname"] or o["target"]["asset_id"] != c["authority"]["target"]["asset_id"]:
            raise ValueError("capture identity differs from authority")
        posture = build_posture(o)
        if posture["sections"]["listeners"].get("expected_endpoints") != normalize_expected_listeners(c["authority"]["target"]["expected_listeners"]):
            raise ValueError("capture listener policy differs from authority")
        return c, admission
    except (KeyError, TypeError, AttributeError, RecursionError, UnicodeError, OverflowError) as exc:
        raise ValueError("malformed capture") from exc


def freeze_capture(*, authority: dict[str, Any], admission: dict[str, Any], operator_id: str,
                   observations: dict[str, Any], collector_hash: str, finished_at: str, mode: str) -> bytes:
    data = canonical_json_bytes({"schema": SCHEMA, "product_version": "1.2.2", "authority": authority,
        "operator_id": operator_id, "hostname": admission["observed_hostname"], "admitted_at": admission["evaluated_at_utc"],
        "finished_at": finished_at, "collector_hash": collector_hash, "mode": mode, "observations": observations})
    _, reconstructed = validate_capture(data)
    if reconstructed != admission:
        raise ValueError("supplied admission differs from reconstruction")
    return data


def read_capture(path: Path, expected_sha256: str) -> bytes:
    if not re.fullmatch(r"[a-f0-9]{64}", expected_sha256):
        raise ValueError("explicit expected capture SHA-256 required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_CAPTURE_BYTES:
            raise ValueError("capture must be a bounded regular file")
        data = stream.read(MAX_CAPTURE_BYTES + 1)
    if len(data) > MAX_CAPTURE_BYTES or hashlib.sha256(data).hexdigest() != expected_sha256:
        raise ValueError("capture digest mismatch")
    validate_capture(data)
    return data


def write_capture(path: Path, data: bytes) -> str:
    validate_capture(data)
    digest = hashlib.sha256(data).hexdigest()
    sidecar = path.with_name(path.name + ".sha256")
    if path.exists() or path.is_symlink() or sidecar.exists() or sidecar.is_symlink():
        raise FileExistsError("capture output already exists")
    write_bytes_new(path, data)
    write_text_new(sidecar, f"{digest}  {path.name}\n")
    return digest
