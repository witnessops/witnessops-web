"""Shared Linux assessment rules, bundled identically in both standalone kits."""
from __future__ import annotations

import copy
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any

from .authority import evaluate_authority
from .canonical import parse_utc

SYSCTL_VALUES = {
    "kernel.unprivileged_bpf_disabled": {"0", "1", "2"},
    "kernel.kptr_restrict": {"0", "1", "2"},
    "kernel.dmesg_restrict": {"0", "1"},
    "fs.protected_hardlinks": {"0", "1"},
    "fs.protected_symlinks": {"0", "1"},
}
CRITICAL_PATHS = {"/etc/passwd", "/etc/group", "/etc/shadow", "/etc/gshadow", "/etc/sudoers"}
SSH_VALUES = {
    "permit_root_login": {"yes", "no", "prohibit-password", "without-password", "forced-commands-only"},
    "password_authentication": {"yes", "no"},
    "pubkey_authentication": {"yes", "no"},
}
_window = ContextVar("linux_collection_window", default=None)


def command_complete(command: Any) -> bool:
    return (isinstance(command, dict) and command.get("status") == "captured"
            and command.get("returncode") == 0
            and not command.get("stdout_truncated") and not command.get("stderr_truncated"))


def section_complete(name: str, record: Any) -> bool:
    if not isinstance(record, dict) or record.get("truncated"):
        return False
    status = record.get("status")
    if name == "firewall":
        if status not in {"active", "inactive"}:
            return False
        if "inbound_policy" in record:
            return (record.get("inbound_policy") in {"allow", "deny", "drop", "reject", "managed"}
                    and type(record.get("inbound_rule_count")) is int and record["inbound_rule_count"] >= 0
                    and type(record.get("inbound_allow_rule_count")) is int and record["inbound_allow_rule_count"] >= 0
                    and record["inbound_allow_rule_count"] <= record["inbound_rule_count"])
        return True
    if status != "observed":
        return False
    if name == "ssh":
        return all(isinstance(record.get(k), str) and record[k] in values for k, values in SSH_VALUES.items())
    if name == "hardening":
        values = record.get("sysctl", {})
        mac = [record.get("apparmor_enabled"), record.get("selinux_enforcing")]
        return (isinstance(values, dict) and all(isinstance(values.get(k), str) and values[k] in allowed for k, allowed in SYSCTL_VALUES.items())
                and (any(v is True for v in mac) or all(type(v) is bool for v in mac)))
    if name == "critical_files":
        files = record.get("files")
        if not isinstance(files, list) or len(files) != len(CRITICAL_PATHS):
            return False
        if any(not isinstance(f, dict) or not isinstance(f.get("path"), str) for f in files):
            return False
        return {f["path"] for f in files} == CRITICAL_PATHS and all(
            f.get("status") == "missing" or (f.get("status") == "observed"
                and isinstance(f.get("mode"), str) and isinstance(f.get("owner"), str)
                and isinstance(f.get("group"), str) and type(f.get("admitted")) is bool)
            for f in files)
    if name == "updates":
        return (type(record.get("available_update_count")) is int and record["available_update_count"] >= 0
                and type(record.get("security_update_count")) is int and record["security_update_count"] >= 0
                and record["security_update_count"] <= record["available_update_count"]
                and type(record.get("reboot_required")) is bool and record.get("cache_only") is True)
    if name == "privileged_access":
        counts = ("non_root_admin_group_member_count", "authorized_key_file_count",
                  "unsafe_authorized_key_file_count", "sudoers_dropin_file_count",
                  "unsafe_sudoers_metadata_count")
        root_keys = record.get("root_authorized_keys")
        return (all(type(record.get(k)) is int and record[k] >= 0 for k in counts)
                and record["unsafe_authorized_key_file_count"] <= record["authorized_key_file_count"]
                and record["unsafe_sudoers_metadata_count"] <= record["sudoers_dropin_file_count"]
                and isinstance(root_keys, dict) and root_keys.get("status") in {"observed", "missing"}
                and type(root_keys.get("admitted")) is bool
                and record.get("direct_sudo_grants_assessed") is False
                and record.get("key_contents_collected") is False
                and record.get("sudoers_contents_collected") is False)
    if name == "listeners" and "expected_endpoints" in record:
        lists = ("actual_endpoints", "expected_endpoints", "unexpected_endpoints", "missing_endpoints")
        if not all(isinstance(record.get(k), list) for k in lists):
            return False
        def keys(values: list[Any]) -> set[tuple[str, str, int]] | None:
            result = set()
            for item in values:
                if (not isinstance(item, dict) or set(item) != {"transport", "address", "port"}
                        or item.get("transport") not in {"tcp", "udp"}
                        or not isinstance(item.get("address"), str) or not item["address"]
                        or type(item.get("port")) is not int or not 1 <= item["port"] <= 65535):
                    return None
                result.add((item["transport"], item["address"], item["port"]))
            return result if len(result) == len(values) else None
        actual, expected, unexpected, missing = (keys(record[k]) for k in lists)
        return (type(record.get("listener_count")) is int and record["listener_count"] >= 0
                and type(record.get("unparsed_line_count")) is int and record["unparsed_line_count"] == 0
                and all(value is not None for value in (actual, expected, unexpected, missing))
                and record["listener_count"] == len(record["actual_endpoints"])
                and unexpected == actual - expected and missing == expected - actual
                and record.get("process_identifiers_collected") is False)
    fields = {"accounts": ("total_account_count", "uid0_account_count", "interactive_shell_account_count"),
              "listeners": ("listener_count",), "services": ("failed_unit_count",)}
    if name in fields:
        if not all(type(record.get(k)) is int and record[k] >= 0 for k in fields[name]):
            return False
        return name != "services" or (isinstance(record.get("failed_units"), list)
            and all(isinstance(v, str) for v in record["failed_units"])
            and len(record["failed_units"]) == record["failed_unit_count"])
    if name == "clock":
        return type(record.get("ntp_synchronized")) is bool
    if name == "host_identity":
        return all(isinstance(record.get(k), str) and record[k] for k in ("hostname", "kernel", "architecture"))
    return False


def assessed_sections(observations: dict[str, Any]) -> dict[str, Any]:
    sections = copy.deepcopy(observations["sections"])
    evidence = observations.get("command_evidence", {})
    for name, record in sections.items():
        if not isinstance(record, dict):
            continue
        commands = evidence.get(name)
        if isinstance(commands, dict):
            if "status" in commands and not command_complete(commands):
                record["status"] = "partial"
            # Empty fixture command arrays are allowed; field checks still apply.
            for command in commands.get("commands", []):
                if not command_complete(command):
                    record["status"] = "partial"
        if not section_complete(name, record) and record.get("status") in {"observed", "active", "inactive"}:
            record["status"] = "partial"
    return sections


def check_observation_authority(authority: dict[str, Any], observations: dict[str, Any], operator_id: str) -> None:
    decision = evaluate_authority(authority, observed_hostname=observations["target"]["hostname"],
        operator_id=operator_id, evaluation_time=parse_utc(observations["observed_at_utc"]))
    if decision["decision"] != "ADMIT":
        raise ValueError("observation outside authority: " + "; ".join(decision["reasons"]))


def checkpoint() -> None:
    context = _window.get()
    if context is not None:
        authority, operator_id, hostname = context
        decision = evaluate_authority(authority, observed_hostname=hostname, operator_id=operator_id)
        if decision["decision"] != "ADMIT":
            raise ValueError("live collection outside authority: " + "; ".join(decision["reasons"]))


def command_timeout(default: float) -> float:
    checkpoint()
    context = _window.get()
    if context is None:
        return default
    remaining = (parse_utc(context[0]["authorization_window"]["ends_at_utc"]) - datetime.now(timezone.utc)).total_seconds()
    if remaining <= 0:
        raise ValueError("live collection authority window expired")
    return min(default, remaining)


@contextmanager
def authorized_collection(authority: dict[str, Any], operator_id: str, hostname: str, *, live: bool):
    if not live:
        yield
        return
    token = _window.set((authority, operator_id, hostname))
    try:
        checkpoint()
        yield
        checkpoint()
    finally:
        _window.reset(token)
