from __future__ import annotations

from .assessment import section_complete, check_observation_authority
from .collector import build_posture
from .findings import derive_findings
from .authority import evaluate_authority
from .canonical import parse_utc

import hashlib
import json
import os
import stat
import tempfile
import zipfile
import zlib
from pathlib import Path
from typing import Any, Callable

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .canonical import canonical_json_bytes, contained_path, exact_keys, load_json, safe_relative_path, sha256_file
from .contracts import (
    COLLECTION_COMPLETENESS_SCHEMA,
    CORE_MANIFEST_EXCLUSIONS,
    CORE_MANIFEST_POLICY,
    PROHIBITED_ARTIFACT_CLASSES,
    PUBLIC_KEY_SCHEMA,
    REQUIRED_SECTION_STATUSES,
    VERIFIER_VERSION,
    validate_manifest_shape,
    validate_receipt_shape,
)
from .crypto import load_trusted_public_key, verify_detached_file_signature, verify_signed_record
MAX_ZIP_FILES = 200
MAX_ZIP_FILE_BYTES = 25 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 100 * 1024 * 1024
MAX_ZIP_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_SIGNATURE_BYTES = 1024 * 1024
MAX_TRUST_REGISTRY_BYTES = 5 * 1024 * 1024


def _check(checks: dict[str, dict[str, str]], name: str, action: Callable[[], str], *, skipped: bool = False) -> None:
    if skipped:
        checks[name] = {"status": "skipped", "detail": "not required for producer core reconstruction"}
        return
    try:
        detail = action()
        checks[name] = {"status": "passed", "detail": detail}
    except FileNotFoundError as exc:
        checks[name] = {"status": "failed", "detail": f"missing: {exc}"}
    except (
        ValueError,
        TypeError,
        PermissionError,
        OSError,
        UnicodeError,
        RuntimeError,
        NotImplementedError,
        json.JSONDecodeError,
        zipfile.BadZipFile,
        zipfile.LargeZipFile,
        zlib.error,
        KeyError,
        AttributeError,
        IndexError,
    ) as exc:
        checks[name] = {"status": "failed", "detail": str(exc)}


def _verify_package_tree(package_dir: Path) -> str:
    if package_dir.is_symlink() or not package_dir.is_dir():
        raise ValueError("package directory must be a real directory, not a symlink")
    pending = [package_dir]
    entries = files = total = 0
    portable_paths: set[str] = set()
    while pending:
        with os.scandir(pending.pop()) as children:
            for entry in children:
                entries += 1
                if entries > MAX_ZIP_FILES * 2:
                    raise ValueError("package tree exceeds entry limit")
                candidate = Path(entry.path)
                name = safe_relative_path(candidate.relative_to(package_dir).as_posix())
                if name.casefold() in portable_paths:
                    raise ValueError("package tree has a portable path collision")
                portable_paths.add(name.casefold())
                metadata = entry.stat(follow_symlinks=False)
                if stat.S_ISDIR(metadata.st_mode):
                    pending.append(candidate)
                elif stat.S_ISREG(metadata.st_mode):
                    files += 1
                    total += metadata.st_size
                    if files > MAX_ZIP_FILES or metadata.st_size > MAX_ZIP_FILE_BYTES or total > MAX_ZIP_TOTAL_BYTES:
                        raise ValueError("package tree exceeds file count or byte limits")
                else:
                    raise ValueError(f"package tree requires regular files and directories: {name}")
    return "package tree contains only bounded regular files and directories"


def _stage_package_tree(source: Path, destination: Path) -> str:
    """Capture a bounded directory through no-follow descriptors for one verification."""
    directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    file_flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0)
    for option in ("O_CLOEXEC", "O_NOFOLLOW"):
        directory_flags |= getattr(os, option, 0)
        file_flags |= getattr(os, option, 0)
    root_descriptor = os.open(source, directory_flags)
    pending: list[tuple[int, Path, str]] = []
    entries = files = total = 0
    portable_paths: set[str] = set()
    try:
        root_info = os.fstat(root_descriptor)
        if not stat.S_ISDIR(root_info.st_mode):
            raise ValueError("package directory must be a real directory, not a symlink")
        destination.mkdir(mode=0o700)
        pending.append((root_descriptor, destination, ""))
        root_descriptor = -1
        while pending:
            descriptor, output_dir, prefix = pending.pop()
            before_directory = os.fstat(descriptor)
            try:
                with os.scandir(descriptor) as children:
                    for entry in children:
                        entries += 1
                        if entries > MAX_ZIP_FILES * 2:
                            raise ValueError("package tree exceeds entry limit")
                        relative = safe_relative_path(f"{prefix}/{entry.name}".lstrip("/"))
                        folded = relative.casefold()
                        if folded in portable_paths:
                            raise ValueError("package tree has a portable path collision")
                        portable_paths.add(folded)
                        admitted = entry.stat(follow_symlinks=False)
                        if stat.S_ISDIR(admitted.st_mode):
                            child_descriptor = os.open(entry.name, directory_flags, dir_fd=descriptor)
                            opened = os.fstat(child_descriptor)
                            if not stat.S_ISDIR(opened.st_mode) or (opened.st_dev, opened.st_ino) != (admitted.st_dev, admitted.st_ino):
                                os.close(child_descriptor)
                                raise ValueError(f"package tree entry changed during capture: {relative}")
                            child_output = output_dir / entry.name
                            child_output.mkdir(mode=0o700)
                            pending.append((child_descriptor, child_output, relative))
                            continue
                        if not stat.S_ISREG(admitted.st_mode):
                            raise ValueError(f"package tree requires regular files and directories: {relative}")
                        source_descriptor = os.open(entry.name, file_flags, dir_fd=descriptor)
                        try:
                            opened = os.fstat(source_descriptor)
                            if not stat.S_ISREG(opened.st_mode) or (opened.st_dev, opened.st_ino) != (admitted.st_dev, admitted.st_ino):
                                raise ValueError(f"package tree entry changed during capture: {relative}")
                            files += 1
                            if files > MAX_ZIP_FILES or opened.st_size > MAX_ZIP_FILE_BYTES or total + opened.st_size > MAX_ZIP_TOTAL_BYTES:
                                raise ValueError("package tree exceeds file count or byte limits")
                            output_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
                            for option in ("O_CLOEXEC", "O_NOFOLLOW"):
                                output_flags |= getattr(os, option, 0)
                            output_descriptor = os.open(output_dir / entry.name, output_flags, 0o600)
                            copied = 0
                            try:
                                os.fchmod(output_descriptor, 0o600)
                                with os.fdopen(output_descriptor, "wb") as output:
                                    output_descriptor = -1
                                    while True:
                                        chunk = os.read(source_descriptor, 1024 * 1024)
                                        if not chunk:
                                            break
                                        copied += len(chunk)
                                        if copied > MAX_ZIP_FILE_BYTES or total + copied > MAX_ZIP_TOTAL_BYTES:
                                            raise ValueError("package tree exceeds file count or byte limits")
                                        output.write(chunk)
                            finally:
                                if output_descriptor >= 0:
                                    os.close(output_descriptor)
                            after = os.fstat(source_descriptor)
                            if (
                                copied != opened.st_size
                                or after.st_size != opened.st_size
                                or after.st_mtime_ns != opened.st_mtime_ns
                                or after.st_ctime_ns != opened.st_ctime_ns
                            ):
                                raise ValueError(f"package tree entry changed during capture: {relative}")
                            total += copied
                        finally:
                            os.close(source_descriptor)
                after_directory = os.fstat(descriptor)
                if (
                    after_directory.st_mtime_ns != before_directory.st_mtime_ns
                    or after_directory.st_ctime_ns != before_directory.st_ctime_ns
                ):
                    raise ValueError(f"package directory changed during capture: {prefix or '.'}")
            finally:
                os.close(descriptor)
    finally:
        if root_descriptor >= 0:
            os.close(root_descriptor)
        for descriptor, _, _ in pending:
            os.close(descriptor)
    return f"{files} bounded regular files captured in one private package snapshot"


def _load_required(package_dir: Path, filename: str) -> Any:
    path = package_dir / filename
    if not path.is_file():
        raise FileNotFoundError(filename)
    return load_json(path)


def _package_public_key(package_dir: Path) -> tuple[dict[str, Any], Ed25519PublicKey]:
    record = _load_required(package_dir, "public_key.json")
    if not isinstance(record, dict) or record.get("schema") != PUBLIC_KEY_SCHEMA:
        raise ValueError("invalid package public_key.json schema")
    required = {"schema", "algorithm", "public_key_id", "encoding", "public_key", "purpose", "trust_boundary"}
    if set(record) != required:
        raise ValueError("public_key.json has missing or unknown fields")
    if record["algorithm"] != "ed25519" or record["encoding"] != "hex":
        raise ValueError("unsupported package public key")
    if (record["purpose"] != "witnessops_local_server_audit_receipt_and_proofpack"
            or record["trust_boundary"] != "package-provided public key is not a trust anchor"):
        raise ValueError("unsupported public key purpose or trust boundary")
    try:
        raw = bytes.fromhex(record["public_key"])
    except ValueError as exc:
        raise ValueError("package public key is not hex") from exc
    if len(raw) != 32:
        raise ValueError("package public key must be 32 bytes")
    return record, Ed25519PublicKey.from_public_bytes(raw)


def _verify_core_manifest(package_dir: Path) -> str:
    policy = _load_required(package_dir, "MANIFEST-POLICY.json")
    if policy != CORE_MANIFEST_POLICY:
        raise ValueError("manifest policy does not match the frozen policy")
    manifest_path = package_dir / "MANIFEST.sha256"
    if not manifest_path.is_file():
        raise FileNotFoundError("MANIFEST.sha256")
    entries: dict[str, str] = {}
    for index, line in enumerate(manifest_path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line:
            continue
        if len(line) < 67 or line[64:66] != "  ":
            raise ValueError(f"invalid MANIFEST.sha256 line {index}")
        digest, name = line[:64], line[66:]
        if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
            raise ValueError(f"invalid digest at MANIFEST.sha256 line {index}")
        name = safe_relative_path(name)
        if name in entries:
            raise ValueError(f"duplicate MANIFEST.sha256 path: {name}")
        entries[name] = digest
    actual = {
        path.relative_to(package_dir).as_posix()
        for path in package_dir.rglob("*")
        if path.is_file() and path.relative_to(package_dir).as_posix() not in CORE_MANIFEST_EXCLUSIONS
    }
    listed = set(entries)
    if actual != listed:
        missing = sorted(listed - actual)
        unlisted = sorted(actual - listed)
        raise ValueError(f"core manifest file-set mismatch missing={missing} unlisted={unlisted}")
    for name, expected in entries.items():
        observed = sha256_file(contained_path(package_dir, name))
        if observed != expected:
            raise ValueError(f"core manifest hash mismatch: {name}")
    return f"{len(entries)} core package files matched MANIFEST.sha256"


def _verify_receipt_and_manifest(
    package_dir: Path,
    *,
    trust_registry: Path | None,
    require_trust: bool,
) -> tuple[dict[str, Any], dict[str, Any], str]:
    receipt = _load_required(package_dir, "receipt.json")
    manifest = _load_required(package_dir, "evidence_manifest.json")
    receipt_errors = validate_receipt_shape(receipt)
    manifest_errors = validate_manifest_shape(manifest)
    if receipt_errors or manifest_errors:
        raise ValueError("contract validation failed: " + "; ".join(receipt_errors + manifest_errors))
    if receipt["proof_run_id"] != manifest["proof_run_id"]:
        raise ValueError("receipt and manifest proof_run_id mismatch")
    package_key_record, package_key = _package_public_key(package_dir)
    if package_key_record["public_key_id"] != receipt["signature"]["public_key_id"]:
        raise ValueError("receipt public_key_id differs from package public key")
    if require_trust:
        if trust_registry is None:
            raise ValueError("external trust registry is required")
        trusted_key = load_trusted_public_key(
            trust_registry,
            receipt["signature"]["public_key_id"],
            "witnessops_local_server_audit_receipt",
        )
        trusted_hex = trusted_key.public_bytes_raw().hex()
        if trusted_hex != package_key_record["public_key"]:
            raise ValueError("package public key differs from external trust registry")
        verify_signed_record(receipt, trusted_key)
        trust_detail = "receipt signature verified with an externally admitted trust-registry key"
    else:
        verify_signed_record(receipt, package_key)
        trust_detail = "receipt signature verified with package key; signer authority not established"
    import hashlib

    observed_manifest_hash = "sha256:" + hashlib.sha256(canonical_json_bytes(manifest)).hexdigest()
    if receipt["manifest_hash"] != observed_manifest_hash:
        raise ValueError("receipt manifest_hash mismatch")
    return receipt, manifest, trust_detail


def _verify_artifacts(package_dir: Path, manifest: dict[str, Any]) -> str:
    by_id = {item["artifact_id"]: item for item in manifest["artifacts"]}
    for artifact_id, path in {"buyer_report": "report.md", "buyer_walkthrough": "BUYER_WALKTHROUGH.md"}.items():
        if by_id.get(artifact_id, {}).get("path") != path:
            raise ValueError(f"signed manifest must bind {path}")
    envelope_paths = {"receipt.json", "RECEIPT-COMPAT.json", "evidence_manifest.json", "public_key.json",
                      "MANIFEST.sha256", "MANIFEST-POLICY.json", "verification_result.json"}
    allowed_paths = envelope_paths | {item["path"] for item in manifest["artifacts"]}
    if any(path.relative_to(package_dir).as_posix() not in allowed_paths for path in package_dir.rglob("*") if path.is_file()):
        raise ValueError("package contains a file outside the signed artifact set and verifier envelope")
    artifact_ids = {item["artifact_id"] for item in manifest["artifacts"]}
    for artifact in manifest["artifacts"]:
        relative = safe_relative_path(artifact["path"])
        path = contained_path(package_dir, relative)
        if not path.is_file():
            raise FileNotFoundError(relative)
        if f"sha256:{sha256_file(path)}" != artifact["sha256"]:
            raise ValueError(f"evidence artifact hash mismatch: {relative}")
        if artifact.get("artifact_class") in PROHIBITED_ARTIFACT_CLASSES:
            raise ValueError(f"prohibited artifact class declared: {artifact['artifact_class']}")
    receipt = _load_required(package_dir, "receipt.json")
    for claim in receipt["claims"]:
        if not isinstance(claim, dict) or set(claim) != {"claim", "status", "evidence_refs"}:
            raise ValueError("invalid receipt claim shape")
        unknown = sorted(set(claim["evidence_refs"]) - artifact_ids)
        if unknown:
            raise ValueError(f"claim {claim.get('claim')} references unknown artifacts: {unknown}")
    _verify_collection_semantics(package_dir, manifest, receipt)
    return f"{len(manifest['artifacts'])} evidence artifacts and all claim references matched"


def _verify_collection_semantics(
    package_dir: Path,
    manifest: dict[str, Any],
    receipt: dict[str, Any],
) -> None:
    by_id = {item["artifact_id"]: item for item in manifest["artifacts"]}
    required_ids = {"admission_decision", "authority_record", "collection_completeness", "host_observations", "host_posture"}
    missing_ids = sorted(required_ids - set(by_id))
    if missing_ids:
        raise ValueError("manifest is missing required semantic artifacts: " + ", ".join(missing_ids))
    completeness_artifact = by_id.get("collection_completeness")
    if completeness_artifact is None:
        raise ValueError("manifest is missing collection_completeness artifact")
    completeness = load_json(contained_path(package_dir, completeness_artifact["path"]))
    if not isinstance(completeness, dict):
        raise ValueError("collection completeness must be an object")
    shape_errors = exact_keys(
        completeness,
        {
            "schema",
            "profile_id",
            "required_sections",
            "section_results",
            "complete",
            "failure_states",
            "claim_boundary",
        },
    )
    if shape_errors or completeness.get("schema") != COLLECTION_COMPLETENESS_SCHEMA:
        raise ValueError("invalid collection completeness contract: " + "; ".join(shape_errors or ["unsupported schema"]))
    if completeness.get("required_sections") != sorted(REQUIRED_SECTION_STATUSES):
        raise ValueError("collection completeness required section set differs from v1")
    results = completeness.get("section_results")
    if not isinstance(results, list) or len(results) != len(REQUIRED_SECTION_STATUSES):
        raise ValueError("collection completeness section_results are incomplete")
    observed_results: dict[str, bool] = {}
    posture = _load_required(package_dir, "posture.json")
    observations = load_json(contained_path(package_dir, by_id["host_observations"]["path"]))
    authority = load_json(contained_path(package_dir, by_id["authority_record"]["path"]))
    admission = load_json(contained_path(package_dir, by_id["admission_decision"]["path"]))
    if build_posture(observations) != posture:
        raise ValueError("posture does not reconstruct from observations")
    if derive_findings(posture) != _load_required(package_dir, "findings.json"):
        raise ValueError("findings do not reconstruct from posture")
    check_observation_authority(authority, observations, authority["operator_id"])
    reconstructed = evaluate_authority(authority, observed_hostname=admission["observed_hostname"],
        operator_id=admission["operator_id"], evaluation_time=parse_utc(admission["evaluated_at_utc"]))
    if reconstructed != admission or admission.get("decision") != "ADMIT":
        raise ValueError("admission does not reconstruct to ADMIT")
    posture_sections = posture.get("sections") if isinstance(posture, dict) else None
    if not isinstance(posture_sections, dict):
        raise ValueError("posture sections are missing")
    for index, item in enumerate(results):
        if not isinstance(item, dict) or exact_keys(
            item,
            {"section", "observed_status", "admitted_complete_statuses", "complete"},
        ):
            raise ValueError(f"invalid collection completeness section_results[{index}]")
        section = item.get("section")
        if section not in REQUIRED_SECTION_STATUSES or section in observed_results:
            raise ValueError(f"invalid or duplicate completeness section: {section}")
        expected_status = posture_sections.get(section, {}).get("status") if isinstance(posture_sections.get(section), dict) else None
        expected_admitted = sorted(REQUIRED_SECTION_STATUSES[section])
        expected_complete = expected_status in REQUIRED_SECTION_STATUSES[section] and section_complete(section, posture_sections.get(section))
        if item.get("observed_status") != expected_status or item.get("admitted_complete_statuses") != expected_admitted:
            raise ValueError(f"collection completeness does not reconstruct posture section: {section}")
        if item.get("complete") is not expected_complete:
            raise ValueError(f"collection completeness boolean is wrong for section: {section}")
        observed_results[section] = expected_complete
    expected_complete = all(observed_results.values())
    expected_failures = [] if expected_complete else ["required_collection_incomplete"]
    if completeness.get("complete") is not expected_complete or completeness.get("failure_states") != expected_failures:
        raise ValueError("collection completeness summary is inconsistent")
    matches = [item for item in receipt["claims"] if item["claim"] == "required_collection_sections_available"]
    if len(matches) != 1:
        raise ValueError("receipt must contain exactly one required-collection claim")
    expected_claim_status = "passed" if expected_complete else "partial"
    expected_outcome = "pass" if expected_complete else "partial"
    if matches[0]["status"] != expected_claim_status:
        raise ValueError("required-collection claim status contradicts reconstructed completeness")
    if receipt["result"] != {"outcome": expected_outcome, "failure_states": expected_failures}:
        raise ValueError("receipt result contradicts reconstructed completeness")


def _verify_receipt_projection(package_dir: Path) -> str:
    canonical = package_dir / "receipt.json"
    projection = package_dir / "RECEIPT-COMPAT.json"
    if not canonical.is_file() or not projection.is_file():
        raise FileNotFoundError("receipt.json or RECEIPT-COMPAT.json")
    if canonical.read_bytes() != projection.read_bytes():
        raise ValueError("RECEIPT-COMPAT.json differs from canonical receipt.json")
    return "canonical and compatibility receipt bytes are identical"


def _base_core_result(package_dir: Path, trust_registry: Path | None, require_trust: bool) -> dict[str, Any]:
    checks: dict[str, dict[str, str]] = {}
    state: dict[str, Any] = {}
    def admission_check() -> str:
        detail = _verify_package_tree(package_dir)
        if require_trust:
            if trust_registry is None:
                raise ValueError("external trust registry is required")
            _input_record(trust_registry, MAX_TRUST_REGISTRY_BYTES)
        return detail

    _check(checks, "package_tree", admission_check)
    if checks["package_tree"]["status"] == "failed":
        return {
            "verifier_version": VERIFIER_VERSION,
            "status": "invalid",
            "proof_run_id": "unknown",
            "workflow_class": "unknown",
            "checks": checks,
            "outcome": "inconclusive",
            "failure_states": ["unsafe_package_tree"],
            "proof_boundary": "package tree failed before core package admission",
        }
    _check(checks, "core_manifest", lambda: _verify_core_manifest(package_dir))

    def receipt_check() -> str:
        receipt, manifest, detail = _verify_receipt_and_manifest(package_dir, trust_registry=trust_registry, require_trust=require_trust)
        state["receipt"] = receipt
        state["manifest"] = manifest
        return detail

    _check(checks, "receipt_signature_and_manifest_binding", receipt_check)
    if "manifest" in state:
        _check(checks, "evidence_artifact_hashes_and_claim_refs", lambda: _verify_artifacts(package_dir, state["manifest"]))
    else:
        checks["evidence_artifact_hashes_and_claim_refs"] = {"status": "failed", "detail": "receipt/manifest validation did not complete"}
    _check(checks, "receipt_compatibility_projection", lambda: _verify_receipt_projection(package_dir))
    if require_trust:
        checks["signer_trust"] = {
            "status": "passed" if checks["receipt_signature_and_manifest_binding"]["status"] == "passed" else "failed",
            "detail": "external trust registry required and compared",
        }
    else:
        checks["signer_trust"] = {"status": "skipped", "detail": "producer core reconstruction does not establish signer authority"}
    failed = any(item["status"] == "failed" for item in checks.values())
    receipt = state.get("receipt", {})
    return {
        "verifier_version": VERIFIER_VERSION,
        "status": "invalid" if failed else "valid",
        "proof_run_id": receipt.get("proof_run_id", "unknown"),
        "workflow_class": receipt.get("workflow_class", "unknown"),
        "checks": checks,
        "outcome": receipt.get("result", {}).get("outcome", "inconclusive"),
        "failure_states": receipt.get("result", {}).get("failure_states", ["verification_incomplete"]),
        "proof_boundary": "package integrity and declared bindings only; no host security, compromise, completeness, or compliance conclusion",
    }


def _verify_core_package(
    package_dir: Path,
    *,
    trust_registry: Path | None,
    require_trust: bool,
    check_embedded: bool = True,
) -> dict[str, Any]:
    result = _base_core_result(package_dir, trust_registry, require_trust)
    if not check_embedded or result["checks"]["package_tree"]["status"] == "failed":
        return result
    expected = _base_core_result(package_dir, None, False)
    embedded_path = package_dir / "verification_result.json"
    if not embedded_path.is_file():
        result["checks"]["embedded_core_verifier_result"] = {"status": "failed", "detail": "missing verification_result.json"}
        result["status"] = "invalid"
        return result
    try:
        embedded = load_json(embedded_path)
        if embedded != expected:
            raise ValueError("embedded core verifier result differs from fresh reconstruction")
        result["checks"]["embedded_core_verifier_result"] = {"status": "passed", "detail": "embedded producer core result matched fresh reconstruction"}
    except (ValueError, json.JSONDecodeError) as exc:
        result["checks"]["embedded_core_verifier_result"] = {"status": "failed", "detail": str(exc)}
        result["status"] = "invalid"
    return result


def verify_core_package(
    package_dir: Path,
    *,
    trust_registry: Path | None,
    require_trust: bool,
    check_embedded: bool = True,
) -> dict[str, Any]:
    try:
        with tempfile.TemporaryDirectory(prefix="witnessops-lsa-core-verify-") as temp:
            input_root = Path(temp) / "inputs"
            input_root.mkdir(mode=0o700)
            staged_package = input_root / "package"
            _stage_package_tree(package_dir, staged_package)
            staged_registry = None
            if trust_registry is not None:
                staged_registry, _ = _stage_verification_input(
                    trust_registry,
                    input_root,
                    "trust_registry",
                    MAX_TRUST_REGISTRY_BYTES,
                )
            return _verify_core_package(
                staged_package,
                trust_registry=staged_registry,
                require_trust=require_trust,
                check_embedded=check_embedded,
            )
    except (ValueError, TypeError, PermissionError, OSError, UnicodeError, RuntimeError, KeyError, AttributeError, IndexError) as exc:
        return {
            "verifier_version": VERIFIER_VERSION,
            "status": "invalid",
            "proof_run_id": "unknown",
            "workflow_class": "unknown",
            "checks": {"package_tree": {"status": "failed", "detail": str(exc)}},
            "outcome": "inconclusive",
            "failure_states": ["unsafe_package_tree"],
            "proof_boundary": "package tree failed before core package admission",
        }


def _safe_extract(archive_path: Path, destination: Path) -> str:
    seen: set[str] = set()
    portable_seen: set[str] = set()
    total = 0
    with zipfile.ZipFile(archive_path, "r") as archive:
        infos = archive.infolist()
        if len(infos) > MAX_ZIP_FILES:
            raise ValueError("proofpack exceeds maximum file count")
        for info in infos:
            name = safe_relative_path(info.filename)
            if name in seen:
                raise ValueError(f"duplicate ZIP entry: {name}")
            seen.add(name)
            portable_name = name.casefold()
            if portable_name in portable_seen:
                raise ValueError(f"portable ZIP path collision: {name}")
            portable_seen.add(portable_name)
            mode = (info.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK:
                raise ValueError(f"ZIP symlink is not permitted: {name}")
            if info.is_dir():
                raise ValueError(f"explicit ZIP directory entry is not permitted: {name}")
            if info.flag_bits & 0x1:
                raise ValueError(f"encrypted ZIP entry is not permitted: {name}")
            if info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
                raise ValueError(f"unsupported ZIP compression method: {name}")
            if info.file_size > MAX_ZIP_FILE_BYTES:
                raise ValueError(f"ZIP entry exceeds size limit: {name}")
            total += info.file_size
            if total > MAX_ZIP_TOTAL_BYTES:
                raise ValueError("proofpack exceeds total uncompressed size limit")
            target = contained_path(destination, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(archive.read(info))
    return f"safely extracted {len(seen)} files totaling {total} bytes"


def _input_record(path: Path, max_bytes: int) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError(path)
    size = path.stat().st_size
    if size > max_bytes:
        raise ValueError(f"verification input exceeds size limit: {path.name}")
    return {"name": path.name, "sha256": sha256_file(path), "size_bytes": size}


def _stage_verification_input(source: Path, destination_root: Path, label: str, max_bytes: int) -> tuple[Path, dict[str, Any]]:
    """Capture one bounded regular file and use only that private snapshot."""
    if not source.name:
        raise FileNotFoundError(source)
    flags = os.O_RDONLY
    for option in ("O_CLOEXEC", "O_NOFOLLOW", "O_NONBLOCK"):
        flags |= getattr(os, option, 0)
    descriptor = os.open(source, flags)
    try:
        destination_dir = destination_root / label
        destination_dir.mkdir(mode=0o700)
        staged = destination_dir / source.name
        digest = hashlib.sha256()
        total = 0
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError(f"verification input must be a regular file: {source.name}")
        if before.st_size > max_bytes:
            raise ValueError(f"verification input exceeds size limit: {source.name}")
        output_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
        output_descriptor = os.open(staged, output_flags, 0o600)
        try:
            os.fchmod(output_descriptor, 0o600)
            with os.fdopen(output_descriptor, "wb") as output:
                output_descriptor = -1
                while True:
                    remaining = max_bytes + 1 - total
                    chunk = os.read(descriptor, min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError(f"verification input exceeds size limit: {source.name}")
                    digest.update(chunk)
                    output.write(chunk)
        finally:
            if output_descriptor >= 0:
                os.close(output_descriptor)
        after = os.fstat(descriptor)
        if (
            after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
            or after.st_ctime_ns != before.st_ctime_ns
            or total != before.st_size
        ):
            raise ValueError(f"verification input changed during capture: {source.name}")
    finally:
        os.close(descriptor)
    return staged, {"name": source.name, "sha256": digest.hexdigest(), "size_bytes": total}


def verify_proofpack(proofpack: Path, signature_path: Path, trust_registry: Path) -> dict[str, Any]:
    transport_checks: dict[str, dict[str, str]] = {}
    envelope_state: dict[str, Any] = {}
    verification_inputs: dict[str, Any] = {}

    with tempfile.TemporaryDirectory(prefix="witnessops-lsa-verify-") as temp:
        captured: dict[str, Path] = {}
        input_root = Path(temp) / "inputs"
        input_root.mkdir(mode=0o700)

        def input_check() -> str:
            for label, source, limit in (
                ("proofpack", proofpack, MAX_ZIP_ARCHIVE_BYTES),
                ("signature", signature_path, MAX_SIGNATURE_BYTES),
                ("trust_registry", trust_registry, MAX_TRUST_REGISTRY_BYTES),
            ):
                captured[label], verification_inputs[label] = _stage_verification_input(source, input_root, label, limit)
            return "proofpack, signature, and trust registry were captured as bounded private snapshots"

        _check(transport_checks, "verification_inputs", input_check)
        if transport_checks["verification_inputs"]["status"] == "failed":
            return {
                "verifier_version": VERIFIER_VERSION,
                "status": "invalid",
                "proof_run_id": "unknown",
                "workflow_class": "unknown",
                "checks": transport_checks,
                "outcome": "inconclusive",
                "failure_states": ["verification_input_invalid"],
                "proof_boundary": "verification inputs failed before signature admission",
                "verification_inputs": verification_inputs,
            }

        def signature_check() -> str:
            envelope = load_json(captured["signature"])
            verify_detached_file_signature(captured["proofpack"], envelope, captured["trust_registry"])
            envelope_state["envelope"] = envelope
            return "detached ZIP signature and external trust-registry admission passed"

        _check(transport_checks, "proofpack_detached_signature", signature_check)
        if transport_checks["proofpack_detached_signature"]["status"] == "failed":
            return {
                "verifier_version": VERIFIER_VERSION,
                "status": "invalid",
                "proof_run_id": "unknown",
                "workflow_class": "unknown",
                "checks": transport_checks,
                "outcome": "inconclusive",
                "failure_states": ["proofpack_signature_invalid"],
                "proof_boundary": "transport signature failed; package contents were not admitted",
                "verification_inputs": verification_inputs,
            }

        package_dir = Path(temp) / "package"
        package_dir.mkdir()
        _check(transport_checks, "safe_zip_structure", lambda: _safe_extract(captured["proofpack"], package_dir))
        if transport_checks["safe_zip_structure"]["status"] == "failed":
            return {
                "verifier_version": VERIFIER_VERSION,
                "status": "invalid",
                "proof_run_id": "unknown",
                "workflow_class": "unknown",
                "checks": transport_checks,
                "outcome": "inconclusive",
                "failure_states": ["unsafe_proofpack_structure"],
                "proof_boundary": "ZIP structure failed before core package admission",
                "verification_inputs": verification_inputs,
            }
        core = _verify_core_package(package_dir, trust_registry=captured["trust_registry"], require_trust=True, check_embedded=True)
        envelope = envelope_state["envelope"]

        def signer_continuity_check() -> str:
            receipt = load_json(package_dir / "receipt.json")
            if not isinstance(receipt, dict) or not isinstance(receipt.get("signature"), dict):
                raise ValueError("receipt signature must be an object")
            if envelope.get("public_key_id") != receipt["signature"].get("public_key_id"):
                raise ValueError("detached ZIP signer and receipt signer key ids differ")
            return "detached ZIP signer and receipt signer key ids match"

        _check(transport_checks, "transport_receipt_signer_continuity", signer_continuity_check)
        checks = {**transport_checks, **{f"core.{name}": value for name, value in core["checks"].items()}}
        failed = core["status"] != "valid" or any(item["status"] == "failed" for item in transport_checks.values())
        return {
            "verifier_version": VERIFIER_VERSION,
            "status": "invalid" if failed else "valid",
            "proof_run_id": core["proof_run_id"],
            "workflow_class": core["workflow_class"],
            "checks": checks,
            "outcome": core["outcome"],
            "failure_states": core["failure_states"] if not failed else sorted(set(core["failure_states"] + ["verification_check_failed"])),
            "proof_boundary": core["proof_boundary"],
            "verification_inputs": verification_inputs,
        }
