from __future__ import annotations

import re
from typing import Any

from .canonical import exact_keys, safe_relative_path

WORKFLOW_CLASS = "host_triage_evidence_collection"
PROFILE_ID = "linux_baseline_v1"
AUTHORITY_SCHEMA = "witnessops.local_server_audit.authority.v1"
ADMISSION_SCHEMA = "witnessops.local_server_audit.admission_decision.v1"
POSTURE_SCHEMA = "witnessops.local_server_audit.posture.v1"
FINDINGS_SCHEMA = "witnessops.local_server_audit.findings.v1"
OBSERVATIONS_SCHEMA = "witnessops.local_server_audit.observations.v1"
COLLECTION_COMPLETENESS_SCHEMA = "witnessops.local_server_audit.collection_completeness.v1"
RUN_RECORD_SCHEMA = "witnessops.local_server_audit.run_record.v1"
MANIFEST_VERSION = "witnessops.evidence_manifest.v0"
RECEIPT_VERSION = "witnessops.receipt.v0"
VERIFIER_VERSION = "witnessops.local_server_audit.verifier.v1.2.2"
PUBLIC_KEY_SCHEMA = "witnessops.public_key.v1"
TRUST_REGISTRY_SCHEMA = "witnessops.key_registry.snapshot.v1"
DETACHED_SIGNATURE_SCHEMA = "witnessops.detached_signature.v1"
CORE_MANIFEST_EXCLUSIONS = ["MANIFEST.sha256", "verification_result.json"]
CORE_MANIFEST_POLICY = {
    "schema": "witnessops.local_server_audit.manifest_policy.v1",
    "hash_algorithm": "sha256",
    "excluded_paths": CORE_MANIFEST_EXCLUSIONS,
    "exclusion_reason": "MANIFEST.sha256 cannot list itself; verification_result.json records reconstruction after the core manifest is frozen; final ZIP signature binds both",
}

PROHIBITED_ARTIFACT_CLASSES = frozenset(
    {
        "credentials",
        "browser_cookies",
        "oauth_tokens",
        "private_keys",
        "password_manager_data",
        "screenshots",
        "clipboard",
        "full_user_documents",
        "full_memory_dump",
        "process_command_lines",
        "process_environment",
    }
)

SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
TOKEN_RE = re.compile(r"^[a-z][a-z0-9_]*$")
RUN_ID_RE = re.compile(r"^pr_[A-Za-z0-9_:-]+$")
CLAIM_STATUSES = frozenset({"passed", "partial", "failed", "inconclusive"})
MAX_PACKAGE_ENTRIES = 200
REQUIRED_RECEIPT_CLAIMS = frozenset(
    {
        "artifact_hashes_present",
        "authority_record_exists",
        "collection_profile_bound",
        "collector_hash_recorded",
        "collector_signature_status_recorded",
        "host_clock_trust_declared",
        "known_side_effects_declared",
        "launcher_boundary_declared",
        "manifest_contains_all_artifacts",
        "operator_is_authorized",
        "package_is_offline_verifiable",
        "prohibited_artifacts_absent",
        "required_collection_sections_available",
        "target_host_in_scope",
    }
)
REQUIRED_SECTION_STATUSES = {
    "accounts": frozenset({"observed"}),
    "clock": frozenset({"observed"}),
    "critical_files": frozenset({"observed"}),
    "firewall": frozenset({"active", "inactive"}),
    "hardening": frozenset({"observed"}),
    "host_identity": frozenset({"observed"}),
    "listeners": frozenset({"observed"}),
    "privileged_access": frozenset({"observed"}),
    "services": frozenset({"observed"}),
    "ssh": frozenset({"observed"}),
    "updates": frozenset({"observed"}),
}


def validate_manifest_shape(manifest: Any) -> list[str]:
    if not isinstance(manifest, dict):
        return ["manifest must be an object"]
    errors = exact_keys(
        manifest,
        {"manifest_version", "workflow_class", "proof_run_id", "source_systems", "artifacts"},
        {"authority", "target", "collector", "launcher", "collection_profile", "declared_exclusions", "declared_side_effects", "host_clock"},
    )
    if manifest.get("manifest_version") != MANIFEST_VERSION:
        errors.append("unsupported manifest_version")
    if manifest.get("workflow_class") != WORKFLOW_CLASS:
        errors.append("unsupported workflow_class")
    if not RUN_ID_RE.fullmatch(str(manifest.get("proof_run_id", ""))):
        errors.append("invalid proof_run_id")
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        errors.append("artifacts must be a non-empty array")
        return errors
    if len(artifacts) > MAX_PACKAGE_ENTRIES:
        errors.append(f"artifacts must contain at most {MAX_PACKAGE_ENTRIES} entries")
        return errors
    seen_ids: set[str] = set()
    seen_paths: set[str] = set()
    observed_source_systems: set[str] = set()
    for index, artifact in enumerate(artifacts):
        prefix = f"artifacts[{index}]"
        if not isinstance(artifact, dict):
            errors.append(f"{prefix} must be an object")
            continue
        errors.extend(
            f"{prefix}: {item}"
            for item in exact_keys(
                artifact,
                {"artifact_id", "artifact_type", "source_system", "path", "sha256"},
                {"artifact_class", "collector_method", "sensitivity"},
            )
        )
        artifact_id = str(artifact.get("artifact_id", ""))
        if not TOKEN_RE.fullmatch(artifact_id):
            errors.append(f"{prefix}: invalid artifact_id")
        if artifact_id in seen_ids:
            errors.append(f"{prefix}: duplicate artifact_id")
        seen_ids.add(artifact_id)
        for field in ("artifact_type", "source_system"):
            if not TOKEN_RE.fullmatch(str(artifact.get(field, ""))):
                errors.append(f"{prefix}: invalid {field}")
        source_system = str(artifact.get("source_system", ""))
        if TOKEN_RE.fullmatch(source_system):
            observed_source_systems.add(source_system)
        collector_method = artifact.get("collector_method")
        if collector_method is not None and not TOKEN_RE.fullmatch(str(collector_method)):
            errors.append(f"{prefix}: invalid collector_method")
        sensitivity = artifact.get("sensitivity")
        if sensitivity is not None and sensitivity not in {"low", "medium", "high", "restricted"}:
            errors.append(f"{prefix}: invalid sensitivity")
        try:
            artifact_path = safe_relative_path(str(artifact.get("path", "")))
        except ValueError:
            errors.append(f"{prefix}: unsafe path")
            artifact_path = ""
        if artifact_path in seen_paths:
            errors.append(f"{prefix}: duplicate path")
        seen_paths.add(artifact_path)
        digest = str(artifact.get("sha256", ""))
        if not digest.startswith("sha256:") or not SHA256_RE.fullmatch(digest.removeprefix("sha256:")):
            errors.append(f"{prefix}: invalid sha256")
        artifact_class = artifact.get("artifact_class")
        if artifact_class in PROHIBITED_ARTIFACT_CLASSES:
            errors.append(f"{prefix}: prohibited artifact_class {artifact_class}")
    source_systems = manifest.get("source_systems")
    if (
        not isinstance(source_systems, list)
        or any(not TOKEN_RE.fullmatch(str(item)) for item in source_systems)
        or len(source_systems) != len(set(source_systems))
        or source_systems != sorted(source_systems)
    ):
        errors.append("source_systems must be a sorted unique token array")
    elif set(source_systems) != observed_source_systems:
        errors.append("source_systems must exactly match artifact source_system values")
    return errors


def validate_receipt_shape(receipt: Any) -> list[str]:
    if not isinstance(receipt, dict):
        return ["receipt must be an object"]
    errors = exact_keys(
        receipt,
        {"receipt_version", "workflow_class", "proof_run_id", "result", "claims", "manifest_hash", "signature"},
    )
    if receipt.get("receipt_version") != RECEIPT_VERSION:
        errors.append("unsupported receipt_version")
    if receipt.get("workflow_class") != WORKFLOW_CLASS:
        errors.append("unsupported workflow_class")
    if not RUN_ID_RE.fullmatch(str(receipt.get("proof_run_id", ""))):
        errors.append("invalid proof_run_id")
    result = receipt.get("result")
    if not isinstance(result, dict):
        errors.append("result must be an object")
    else:
        errors.extend(f"result: {item}" for item in exact_keys(result, {"outcome", "failure_states"}))
        if result.get("outcome") not in {"pass", "partial", "fail", "inconclusive"}:
            errors.append("invalid result outcome")
        states = result.get("failure_states")
        if (
            not isinstance(states, list)
            or any(not TOKEN_RE.fullmatch(str(item)) for item in states)
            or len(states) != len(set(states))
        ):
            errors.append("invalid failure_states")
    claims = receipt.get("claims")
    if not isinstance(claims, list) or not claims:
        errors.append("claims must be a non-empty array")
    elif len(claims) != len(REQUIRED_RECEIPT_CLAIMS):
        errors.append(f"claims must contain exactly {len(REQUIRED_RECEIPT_CLAIMS)} entries")
    else:
        seen_claims: set[str] = set()
        valid_claims: list[dict[str, Any]] = []
        for index, claim in enumerate(claims):
            prefix = f"claims[{index}]"
            if not isinstance(claim, dict):
                errors.append(f"{prefix} must be an object")
                continue
            errors.extend(
                f"{prefix}: {item}"
                for item in exact_keys(claim, {"claim", "status", "evidence_refs"})
            )
            claim_id = claim.get("claim")
            if not isinstance(claim_id, str) or not TOKEN_RE.fullmatch(claim_id):
                errors.append(f"{prefix}: invalid claim")
                continue
            if claim_id not in REQUIRED_RECEIPT_CLAIMS:
                errors.append(f"{prefix}: unknown claim")
                continue
            if claim_id in seen_claims:
                errors.append(f"{prefix}: duplicate claim")
            seen_claims.add(claim_id)
            if claim.get("status") not in CLAIM_STATUSES:
                errors.append(f"{prefix}: invalid status")
            refs = claim.get("evidence_refs")
            if (
                not isinstance(refs, list)
                or not refs
                or any(not isinstance(item, str) or not TOKEN_RE.fullmatch(item) for item in refs)
                or len(refs) != len(set(refs))
            ):
                errors.append(f"{prefix}: evidence_refs must be a non-empty unique token array")
            valid_claims.append(claim)
        if seen_claims != REQUIRED_RECEIPT_CLAIMS:
            missing = sorted(REQUIRED_RECEIPT_CLAIMS - seen_claims)
            unknown = sorted(seen_claims - REQUIRED_RECEIPT_CLAIMS)
            errors.append(f"receipt claim set mismatch missing={missing} unknown={unknown}")
        outcome = result.get("outcome") if isinstance(result, dict) else None
        states = result.get("failure_states") if isinstance(result, dict) else None
        statuses = {str(item.get("claim")): item.get("status") for item in valid_claims}
        completeness_status = statuses.get("required_collection_sections_available")
        if outcome == "pass":
            if states != []:
                errors.append("pass outcome requires empty failure_states")
            if any(item.get("status") != "passed" for item in valid_claims):
                errors.append("pass outcome requires every claim to be passed")
        elif outcome == "partial":
            if not isinstance(states, list) or "required_collection_incomplete" not in states:
                errors.append("partial outcome requires required_collection_incomplete failure state")
            if completeness_status != "partial":
                errors.append("partial outcome requires a partial required-collection claim")
        elif outcome in {"fail", "inconclusive"} and states == []:
            errors.append("non-pass outcome requires at least one failure_state")
    manifest_hash = str(receipt.get("manifest_hash", ""))
    if not manifest_hash.startswith("sha256:") or not SHA256_RE.fullmatch(manifest_hash.removeprefix("sha256:")):
        errors.append("invalid manifest_hash")
    signature = receipt.get("signature")
    if not isinstance(signature, dict):
        errors.append("signature must be an object")
    else:
        errors.extend(
            f"signature: {item}"
            for item in exact_keys(signature, {"algorithm", "public_key_id", "encoding", "signature"})
        )
        if signature.get("algorithm") != "ed25519" or signature.get("encoding") != "hex":
            errors.append("unsupported signature contract")
        if not TOKEN_RE.fullmatch(str(signature.get("public_key_id", ""))):
            errors.append("invalid signature public_key_id")
        try:
            raw = bytes.fromhex(str(signature.get("signature", "")))
            if len(raw) != 64:
                errors.append("invalid Ed25519 signature length")
        except ValueError:
            errors.append("signature is not hex")
    return errors
