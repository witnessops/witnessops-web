from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .canonical import canonical_json_bytes, exact_keys, load_json, require_private_key_permissions, sha256_file, write_json_new, write_text_new
from .contracts import DETACHED_SIGNATURE_SCHEMA, PUBLIC_KEY_SCHEMA, TOKEN_RE, TRUST_REGISTRY_SCHEMA


def _require_key_id(public_key_id: str) -> None:
    if not isinstance(public_key_id, str) or not TOKEN_RE.fullmatch(public_key_id):
        raise ValueError("public_key_id must be a lowercase token")


def load_private_key(path: Path) -> Ed25519PrivateKey:
    require_private_key_permissions(path)
    value = path.read_text(encoding="utf-8").strip()
    try:
        raw = bytes.fromhex(value)
    except ValueError as exc:
        raise ValueError("private key file must contain raw Ed25519 hex") from exc
    if len(raw) != 32:
        raise ValueError("private key file must contain exactly 32 raw bytes")
    return Ed25519PrivateKey.from_private_bytes(raw)


def private_key_hex(key: Ed25519PrivateKey) -> str:
    raw = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    return raw.hex()


def public_key_hex(key: Ed25519PublicKey) -> str:
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def public_key_record(private_key: Ed25519PrivateKey, public_key_id: str) -> dict[str, Any]:
    _require_key_id(public_key_id)
    return {
        "schema": PUBLIC_KEY_SCHEMA,
        "algorithm": "ed25519",
        "public_key_id": public_key_id,
        "encoding": "hex",
        "public_key": public_key_hex(private_key.public_key()),
        "purpose": "witnessops_local_server_audit_receipt_and_proofpack",
        "trust_boundary": "package-provided public key is not a trust anchor",
    }


def sign_record(unsigned: dict[str, Any], private_key: Ed25519PrivateKey, public_key_id: str) -> dict[str, Any]:
    _require_key_id(public_key_id)
    signature = private_key.sign(canonical_json_bytes(unsigned)).hex()
    return {
        **unsigned,
        "signature": {
            "algorithm": "ed25519",
            "public_key_id": public_key_id,
            "encoding": "hex",
            "signature": signature,
        },
    }


def load_trusted_public_key(registry_path: Path, public_key_id: str, purpose: str) -> Ed25519PublicKey:
    registry = load_json(registry_path)
    if not isinstance(registry, dict):
        raise ValueError("trust registry must be an object")
    errors = exact_keys(registry, {"schema", "registry_id", "version", "keys"})
    if errors or registry.get("schema") != TRUST_REGISTRY_SCHEMA:
        raise ValueError("invalid trust registry: " + "; ".join(errors or ["unsupported schema"]))
    matches = [item for item in registry.get("keys", []) if isinstance(item, dict) and item.get("public_key_id") == public_key_id]
    if len(matches) != 1:
        raise ValueError("public_key_id must resolve to exactly one trust-registry entry")
    record = matches[0]
    required = {"public_key_id", "algorithm", "encoding", "public_key", "status", "purposes"}
    record_errors = exact_keys(record, required)
    if record_errors:
        raise ValueError("invalid trust-registry key: " + "; ".join(record_errors))
    if record["algorithm"] != "ed25519" or record["encoding"] != "hex" or record["status"] != "active":
        raise ValueError("trust-registry key is not an active Ed25519 hex key")
    if not isinstance(record["purposes"], list) or purpose not in record["purposes"]:
        raise ValueError("trust-registry key is not admitted for the requested purpose")
    try:
        raw = bytes.fromhex(record["public_key"])
    except ValueError as exc:
        raise ValueError("trust-registry public key is not hex") from exc
    if len(raw) != 32:
        raise ValueError("trust-registry Ed25519 public key must be 32 bytes")
    return Ed25519PublicKey.from_public_bytes(raw)


def verify_signed_record(record: dict[str, Any], public_key: Ed25519PublicKey) -> None:
    signature = record.get("signature")
    if not isinstance(signature, dict):
        raise ValueError("signed record is missing signature")
    if signature.get("algorithm") != "ed25519" or signature.get("encoding") != "hex":
        raise ValueError("unsupported signature contract")
    try:
        signature_bytes = bytes.fromhex(str(signature.get("signature", "")))
    except ValueError as exc:
        raise ValueError("signature is not hex") from exc
    unsigned = deepcopy(record)
    unsigned.pop("signature", None)
    try:
        public_key.verify(signature_bytes, canonical_json_bytes(unsigned))
    except InvalidSignature as exc:
        raise ValueError("Ed25519 signature did not verify") from exc


def build_detached_file_signature(subject_path: Path, private_key: Ed25519PrivateKey, public_key_id: str) -> dict[str, Any]:
    _require_key_id(public_key_id)
    unsigned = {
        "schema": DETACHED_SIGNATURE_SCHEMA,
        "subject": subject_path.name,
        "subject_sha256": sha256_file(subject_path),
        "algorithm": "ed25519",
        "public_key_id": public_key_id,
        "encoding": "hex",
        "purpose": "witnessops_local_server_audit_proofpack",
    }
    signature = private_key.sign(canonical_json_bytes(unsigned)).hex()
    return {**unsigned, "signature": signature}


def verify_detached_file_signature(subject_path: Path, envelope: Any, registry_path: Path) -> None:
    if not isinstance(envelope, dict):
        raise ValueError("detached signature must be an object")
    errors = exact_keys(
        envelope,
        {"schema", "subject", "subject_sha256", "algorithm", "public_key_id", "encoding", "purpose", "signature"},
    )
    if errors:
        raise ValueError("invalid detached signature: " + "; ".join(errors))
    if envelope.get("schema") != DETACHED_SIGNATURE_SCHEMA or envelope.get("subject") != subject_path.name:
        raise ValueError("detached signature subject contract mismatch")
    if envelope.get("subject_sha256") != sha256_file(subject_path):
        raise ValueError("detached signature subject hash mismatch")
    if envelope.get("algorithm") != "ed25519" or envelope.get("encoding") != "hex":
        raise ValueError("unsupported detached signature algorithm")
    key = load_trusted_public_key(registry_path, envelope["public_key_id"], "witnessops_local_server_audit_proofpack")
    unsigned = deepcopy(envelope)
    signature_hex = unsigned.pop("signature")
    try:
        key.verify(bytes.fromhex(signature_hex), canonical_json_bytes(unsigned))
    except (ValueError, InvalidSignature) as exc:
        raise ValueError("detached proofpack signature did not verify") from exc


def create_test_key_material(private_path: Path, registry_path: Path, public_key_id: str) -> None:
    _require_key_id(public_key_id)
    existing = [path for path in (private_path, registry_path) if path.exists() or path.is_symlink()]
    if existing:
        raise FileExistsError("refusing to overwrite test key material: " + ", ".join(str(path) for path in existing))
    key = Ed25519PrivateKey.generate()
    private_path.parent.mkdir(parents=True, exist_ok=True)
    write_text_new(private_path, private_key_hex(key) + "\n", mode=0o600)
    private_path.chmod(0o600)
    try:
        write_json_new(
            registry_path,
            {
                "schema": TRUST_REGISTRY_SCHEMA,
                "registry_id": "synthetic_test_registry",
                "version": 1,
                "keys": [
                    {
                        "public_key_id": public_key_id,
                        "algorithm": "ed25519",
                        "encoding": "hex",
                        "public_key": public_key_hex(key.public_key()),
                        "status": "active",
                        "purposes": [
                            "witnessops_local_server_audit_receipt",
                            "witnessops_local_server_audit_proofpack",
                        ],
                    }
                ],
            },
        )
    except Exception:
        private_path.unlink(missing_ok=True)
        raise
