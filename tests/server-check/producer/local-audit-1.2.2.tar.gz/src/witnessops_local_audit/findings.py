from __future__ import annotations

from typing import Any

from .contracts import FINDINGS_SCHEMA
from .assessment import SYSCTL_VALUES, section_complete

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "informational": 4}


def _finding(
    finding_id: str,
    severity: str,
    title: str,
    *,
    state: str,
    evidence_ref: str,
    observed: Any,
    recommendation: str,
    limit: str,
) -> dict[str, Any]:
    return {
        "finding_id": finding_id,
        "severity": severity,
        "title": title,
        "state": state,
        "evidence_refs": [evidence_ref],
        "observed_value": observed,
        "recommendation": recommendation,
        "claim_limit": limit,
    }


def derive_findings(posture: dict[str, Any]) -> dict[str, Any]:
    sections = posture["sections"]
    findings: list[dict[str, Any]] = []

    accounts = sections.get("accounts", {})
    uid0 = accounts.get("uid0_account_count")
    if isinstance(uid0, int) and uid0 > 1:
        findings.append(
            _finding(
                "lsa_uid0_multiple",
                "high",
                "More than one UID 0 account was observed",
                state="observed",
                evidence_ref="posture.sections.accounts.uid0_account_count",
                observed=uid0,
                recommendation="Review whether every UID 0 account is required and separately attributable.",
                limit="Account names and authentication activity were not collected.",
            )
        )

    ssh = sections.get("ssh", {})
    context = ssh.get("evaluated_context")
    root_loopback = (isinstance(context, dict) and context.get("user") == "root"
                     and context.get("addr") == "127.0.0.1" and bool(context.get("host")))
    context_label = "the evaluated root/loopback context" if root_loopback else "an unconfirmed evaluation context"
    context_limit = (
        "Other users, source addresses and SSH Match contexts were not evaluated."
        if root_loopback else "The supplied posture does not record a confirmed root/loopback evaluation context."
    )
    root_login = str(ssh.get("permit_root_login", "unknown")).casefold()
    if root_login in {"yes", "prohibit-password", "without-password"}:
        findings.append(
            _finding(
                "lsa_ssh_root_login",
                "high",
                f"SSH configuration permits direct root login in {context_label}",
                state="observed",
                evidence_ref="posture.sections.ssh.permit_root_login",
                observed=root_login,
                recommendation="Review an attributable administrator account, working privilege elevation and recovery access before considering disabling direct root SSH login.",
                limit=f"{context_limit} This does not prove that root login was used or externally reachable.",
            )
        )
    elif root_login == "unknown":
        findings.append(
            _finding(
                "lsa_ssh_root_login_unknown",
                "informational",
                f"SSH root-login setting could not be resolved in {context_label}",
                state="unresolved",
                evidence_ref="posture.sections.ssh.status",
                observed=ssh.get("status"),
                recommendation="Resolve effective SSH configuration in a separately authorized follow-up.",
                limit=f"{context_limit} Unknown is not evidence that root login is enabled.",
            )
        )

    password_auth = str(ssh.get("password_authentication", "unknown")).casefold()
    if password_auth == "yes":
        findings.append(
            _finding(
                "lsa_ssh_password_auth",
                "medium",
                f"SSH password authentication is enabled in {context_label}",
                state="observed",
                evidence_ref="posture.sections.ssh.password_authentication",
                observed=password_auth,
                recommendation="Review attributable administrator access, working privilege elevation and key-based recovery before considering disabling password authentication.",
                limit=f"{context_limit} This does not prove weak passwords, exposure, or successful authentication.",
            )
        )

    firewall = sections.get("firewall", {})
    firewall_state = firewall.get("status")
    if firewall_state == "inactive":
        findings.append(
            _finding(
                "lsa_host_firewall_inactive",
                "medium",
                "Queried host-firewall controls reported inactive",
                state="observed",
                evidence_ref="posture.sections.firewall.status",
                observed=firewall_state,
                recommendation="Confirm the intended network-control boundary and enable a host firewall where required.",
                limit="The collector queried supported local providers; upstream controls and actual reachability were not tested.",
            )
        )
    elif firewall_state not in {"active", "inactive"}:
        findings.append(
            _finding(
                "lsa_host_firewall_unknown",
                "informational",
                "Host firewall state could not be established",
                state="unresolved",
                evidence_ref="posture.sections.firewall.status",
                observed=firewall_state,
                recommendation="Confirm the intended firewall provider and collect its state with suitable read authority.",
                limit="Unknown is not evidence that no firewall exists.",
            )
        )
    if firewall_state == "active" and firewall.get("inbound_policy") == "allow":
        findings.append(_finding(
            "lsa_firewall_default_allow", "medium", "Host firewall default inbound policy allows traffic",
            state="observed", evidence_ref="posture.sections.firewall.inbound_policy", observed="allow",
            recommendation="Confirm that every inbound service is intended and change the default policy only with a recovery path.",
            limit="Rule order, upstream controls and external reachability were not tested."))

    listeners = sections.get("listeners", {})
    unexpected = listeners.get("unexpected_endpoints", [])
    if unexpected:
        findings.append(_finding(
            "lsa_unexpected_listener", "medium", "Listening endpoints fell outside the declared listener baseline",
            state="observed", evidence_ref="posture.sections.listeners.unexpected_endpoints", observed=unexpected,
            recommendation="Identify the owning service and confirm each endpoint before changing or stopping it.",
            limit="The declared listener baseline does not independently establish service intent. Process identifiers and external reachability were not collected."))
    missing = listeners.get("missing_endpoints", [])
    if missing and "expected_endpoints" in listeners and section_complete("listeners", listeners):
        findings.append(_finding(
            "lsa_expected_listener_missing", "informational", "Expected listening endpoints were not observed",
            state="observed", evidence_ref="posture.sections.listeners.missing_endpoints", observed=missing,
            recommendation="Confirm whether the endpoint in the declared listener baseline is intentionally absent or bound to a different address.",
            limit="A point-in-time local socket view does not establish service availability over time."))

    privileged = sections.get("privileged_access", {})
    root_keys = privileged.get("root_authorized_keys", {})
    if (privileged.get("unsafe_authorized_key_file_count", 0) > 0
            or (root_keys.get("status") == "observed" and root_keys.get("admitted") is False)):
        findings.append(_finding(
            "lsa_authorized_keys_metadata", "high", "Authorized-key file metadata fell outside the admitted baseline",
            state="observed", evidence_ref="posture.sections.privileged_access", observed={
                "unsafe_file_count": privileged.get("unsafe_authorized_key_file_count"),
                "root_authorized_keys": root_keys},
            recommendation="Review ownership and permissions separately before changing SSH access.",
            limit="Key contents, validity and authentication activity were not collected."))
    if root_keys.get("status") == "unknown":
        findings.append(_finding(
            "lsa_authorized_keys_metadata_unknown", "informational", "Root authorized-key metadata could not be read",
            state="unresolved", evidence_ref="posture.sections.privileged_access.root_authorized_keys",
            observed=root_keys, recommendation="Review root SSH access metadata separately with approved read authority before changing access.",
            limit="Unreadable metadata is not evidence of unsafe ownership, permissions, or key content."))
    if privileged.get("unsafe_sudoers_metadata_count", 0) > 0:
        findings.append(_finding(
            "lsa_sudoers_dropin_metadata", "high", "Sudoers drop-in metadata fell outside the admitted baseline",
            state="observed", evidence_ref="posture.sections.privileged_access.unsafe_sudoers_metadata_count",
            observed=privileged.get("unsafe_sudoers_metadata_count"),
            recommendation="Review affected metadata and validate syntax before making any privilege change.",
            limit="Sudoers contents and effective direct grants were not assessed."))

    updates = sections.get("updates", {})
    if isinstance(updates.get("security_update_count"), int) and updates["security_update_count"] > 0:
        findings.append(_finding(
            "lsa_security_updates_available", "medium", "Cached package metadata reports available security updates",
            state="observed", evidence_ref="posture.sections.updates.security_update_count",
            observed=updates["security_update_count"], recommendation="Review and schedule the security updates through the host's normal change process.",
            limit="The scan used local cached metadata and did not refresh repositories or install packages."))
    elif isinstance(updates.get("available_update_count"), int) and updates["available_update_count"] > 0:
        findings.append(_finding(
            "lsa_updates_available", "low", "Cached package metadata reports available updates",
            state="observed", evidence_ref="posture.sections.updates.available_update_count",
            observed=updates["available_update_count"], recommendation="Review the available updates through the host's normal change process.",
            limit="The scan used local cached metadata and did not refresh repositories or install packages."))
    if updates.get("reboot_required") is True:
        findings.append(_finding(
            "lsa_reboot_required", "medium", "The host reports a pending reboot",
            state="observed", evidence_ref="posture.sections.updates.reboot_required", observed=True,
            recommendation="Schedule a controlled reboot with service and recovery checks.",
            limit="The marker does not identify the package or guarantee that a reboot resolves every pending update."))
    if updates.get("status") not in {"observed"}:
        if (updates.get("security_classification") == "unavailable"
                and updates.get("command_status") == "captured" and updates.get("returncode") == 0
                and type(updates.get("available_update_count")) is int and updates["available_update_count"] >= 0):
            findings.append(_finding(
                "lsa_updates_unknown", "informational", "Security-update classification could not be established",
                state="unresolved", evidence_ref="posture.sections.updates.security_classification",
                observed={field: updates.get(field) for field in (
                    "provider", "command_status", "returncode", "security_classification", "cache_freshness", "diagnostic_reason")},
                recommendation="Review security advisory metadata in a separately authorized follow-up; the successful query established a planned update count without classifying security updates.",
                limit="The planned update count uses local cached metadata. Security-update classification and cache freshness were not established."))
        else:
            findings.append(_finding(
                "lsa_updates_unknown", "informational", "Available update status could not be established",
                state="unresolved", evidence_ref="posture.sections.updates.status", observed=updates.get("status"),
                recommendation="Confirm the package manager and refresh policy in a separately authorized maintenance window.",
                limit="Unknown is not evidence that the host is current or outdated."))

    services = sections.get("services", {})
    failed_count = services.get("failed_unit_count")
    if isinstance(failed_count, int) and failed_count > 0:
        findings.append(
            _finding(
                "lsa_failed_services",
                "medium",
                "Failed system services were observed",
                state="observed",
                evidence_ref="posture.sections.services.failed_units",
                observed=services.get("failed_units", []),
                recommendation="Review each failed unit against the host's intended service inventory.",
                limit="A failed unit is not by itself evidence of compromise or business impact.",
            )
        )

    clock = sections.get("clock", {})
    if clock.get("ntp_synchronized") is False:
        findings.append(
            _finding(
                "lsa_clock_unsynchronized",
                "low",
                "Host clock reported not synchronized",
                state="observed",
                evidence_ref="posture.sections.clock.ntp_synchronized",
                observed=False,
                recommendation="Restore approved time synchronization and record the source used.",
                limit="The collector did not compare the clock against an independent time authority.",
            )
        )

    critical = sections.get("critical_files", {}).get("files", [])
    unsafe = [item for item in critical if isinstance(item, dict) and item.get("admitted") is False and item.get("status") == "observed"]
    if unsafe:
        findings.append(
            _finding(
                "lsa_critical_file_metadata",
                "high",
                "Critical account or privilege file metadata fell outside the admitted baseline",
                state="observed",
                evidence_ref="posture.sections.critical_files.files",
                observed=unsafe,
                recommendation="Review ownership and permissions before changing them; preserve service-specific exceptions.",
                limit="File contents and distribution-specific policy were not assessed.",
            )
        )

    for state, title, severity in (("missing", "A required critical file was reported missing", "medium"), ("unknown", "Critical-file metadata could not be read", "informational")):
        records = [item for item in critical if isinstance(item, dict) and item.get("status") == state]
        if records:
            findings.append(_finding("lsa_critical_file_" + state, severity, title,
                state="observed" if state == "missing" else "unresolved",
                evidence_ref="posture.sections.critical_files.files", observed=records,
                recommendation="Confirm the file's expected presence and approved read access before changing anything.",
                limit="Unreadable metadata is not evidence of unsafe permissions."))

    hardening = sections.get("hardening", {})
    if hardening.get("apparmor_enabled") is not True and hardening.get("selinux_enforcing") is not True:
        findings.append(
            _finding(
                "lsa_mandatory_access_control",
                "low",
                "No enabled AppArmor or enforcing SELinux state was established",
                state="observed" if hardening.get("apparmor_enabled") is False and hardening.get("selinux_enforcing") is False else "unresolved",
                evidence_ref="posture.sections.hardening",
                observed={"apparmor_enabled": hardening.get("apparmor_enabled"), "selinux_enforcing": hardening.get("selinux_enforcing")},
                recommendation="Confirm the host's intended mandatory-access-control policy and platform support.",
                limit="This is a posture observation, not proof that workload isolation is ineffective.",
            )
        )

    for key, allowed in SYSCTL_VALUES.items():
        value = hardening.get("sysctl", {}).get(key)
        if value == "0":
            findings.append(_finding("lsa_sysctl_" + key.replace(".", "_"), "low",
                "Kernel protection is disabled: " + key, state="observed",
                evidence_ref="posture.sections.hardening.sysctl." + key, observed=value,
                recommendation="Review enabling this protection against the host's workload and recovery requirements.",
                limit="A bounded configuration observation; platform exceptions and exploitability require analyst review."))
    if password_auth not in {"yes", "no"}:
        findings.append(_finding("lsa_ssh_password_auth_unknown", "informational",
            f"SSH password authentication could not be resolved in {context_label}", state="unresolved",
            evidence_ref="posture.sections.ssh.password_authentication", observed=password_auth,
            recommendation="Resolve the effective configuration within the approved scope.",
            limit=f"{context_limit} Unknown does not establish enabled or disabled authentication."))

    findings.sort(key=lambda item: (SEVERITY_ORDER[item["severity"]], item["finding_id"]))
    counts = {severity: sum(1 for item in findings if item["severity"] == severity) for severity in SEVERITY_ORDER}
    return {
        "schema": FINDINGS_SCHEMA,
        "profile_id": posture["profile_id"],
        "target": posture["target"],
        "observed_at_utc": posture["observed_at_utc"],
        "findings": findings,
        "counts": counts,
        "claim_boundary": "deterministic posture findings only; no secure, compromised, or compliant conclusion",
    }
