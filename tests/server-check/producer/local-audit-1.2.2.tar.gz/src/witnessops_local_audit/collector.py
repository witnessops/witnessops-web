from __future__ import annotations

import copy
import grp
import json
import os
import platform
import pwd
import re
import selectors
import signal
import shutil
import socket
import stat
import subprocess
import time
from pathlib import Path
from typing import Any

from .assessment import assessed_sections

from .canonical import sha256_bytes, utc_now_text
from .assessment import checkpoint, command_complete, command_timeout, SSH_VALUES
from .authority import normalize_expected_listeners, normalize_listener_address
from .contracts import OBSERVATIONS_SCHEMA, POSTURE_SCHEMA, PROFILE_ID

MAX_COMMAND_BYTES = 256 * 1024
COMMAND_TIMEOUT_SECONDS = 12
ALLOWED_COMMANDS = frozenset({"firewall-cmd", "nft", "ss", "sshd", "sysctl", "systemctl", "timedatectl", "ufw"})
TRUSTED_COMMAND_PATH = "/usr/sbin:/usr/bin:/sbin:/bin"
UPDATE_COMMANDS = {
    # Simulation reads existing package indexes without installing/downloading.
    # --no-download also rejects uncached archives during some APT simulations.
    "apt": ("apt-get", "--simulate", "--option", "Debug::NoLocking=1", "upgrade"),
    "dnf_all": ("dnf", "--cacheonly", "--quiet", "check-update"),
    "dnf_security": ("dnf", "--cacheonly", "--quiet", "updateinfo", "list", "--security", "--available"),
    "yum_all": ("yum", "--cacheonly", "--quiet", "check-update"),
    "yum_security": ("yum", "--cacheonly", "--quiet", "updateinfo", "list", "--security", "--available"),
}


def observed_hostname() -> str:
    return socket.gethostname().strip()


def _terminate_process(process: subprocess.Popen[bytes], *, process_group: bool) -> None:
    """Stop the admitted child and its private process group, then reap it."""
    try:
        if process_group:
            os.killpg(process.pid, signal.SIGTERM)
        elif process.poll() is None:
            process.terminate()
    except ProcessLookupError:
        pass
    except PermissionError:
        process_group = False
        if process.poll() is None:
            process.terminate()
    grace_deadline = time.monotonic() + 0.25
    while process_group and time.monotonic() < grace_deadline:
        try:
            os.killpg(process.pid, 0)
        except (ProcessLookupError, PermissionError):
            break
        time.sleep(0.01)
    try:
        process.wait(timeout=max(0.0, grace_deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        pass
    try:
        if process_group:
            os.killpg(process.pid, signal.SIGKILL)
        elif process.poll() is None:
            process.kill()
    except (ProcessLookupError, PermissionError):
        if process.poll() is None:
            process.kill()
    if process.poll() is None:
        process.wait()


def _drain_process(
    process: subprocess.Popen[bytes], timeout: float, *, process_group: bool = False
) -> tuple[bytes, bytes, bool, bool, bool]:
    """Drain both pipes while retaining at most MAX_COMMAND_BYTES per stream."""
    selector = selectors.DefaultSelector()
    streams = {"stdout": process.stdout, "stderr": process.stderr}
    buffers = {"stdout": bytearray(), "stderr": bytearray()}
    truncated = {"stdout": False, "stderr": False}
    for name, stream in streams.items():
        if stream is None:
            raise RuntimeError(f"subprocess {name} pipe is unavailable")
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, name)
    deadline = time.monotonic() + timeout
    timed_out = False
    try:
        while selector.get_map() or process.poll() is None:
            checkpoint()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                timed_out = True
                _terminate_process(process, process_group=process_group)
                break
            if selector.get_map():
                events = selector.select(min(0.1, remaining))
            else:
                try:
                    process.wait(timeout=min(0.1, remaining))
                except subprocess.TimeoutExpired:
                    pass
                continue
            if not events and process.poll() is not None:
                events = [(key, selectors.EVENT_READ) for key in selector.get_map().values()]
            for key, _ in events:
                try:
                    chunk = os.read(key.fd, 64 * 1024)
                except BlockingIOError:
                    continue
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                target = buffers[key.data]
                room = MAX_COMMAND_BYTES - len(target)
                if room:
                    target.extend(chunk[:room])
                if len(chunk) > room:
                    truncated[key.data] = True
        for key in list(selector.get_map().values()):
            while True:
                try:
                    chunk = os.read(key.fd, 64 * 1024)
                except BlockingIOError:
                    break
                if not chunk:
                    break
                target = buffers[key.data]
                room = MAX_COMMAND_BYTES - len(target)
                if room:
                    target.extend(chunk[:room])
                if len(chunk) > room:
                    truncated[key.data] = True
        if process.poll() is None:
            process.wait()
    finally:
        selector.close()
        if process.poll() is None or (process_group and any(not stream.closed for stream in streams.values() if stream is not None)):
            _terminate_process(process, process_group=process_group)
        for stream in streams.values():
            if stream is not None and not stream.closed:
                stream.close()
    return bytes(buffers["stdout"]), bytes(buffers["stderr"]), truncated["stdout"], truncated["stderr"], timed_out


def _run_resolved_command(argv: list[str]) -> dict[str, Any]:
    checkpoint()
    executable = shutil.which(argv[0], path=TRUSTED_COMMAND_PATH)
    if executable is None:
        return {"status": "unavailable", "argv": argv, "returncode": None, "stdout": "", "stderr": "command unavailable"}
    executable = str(Path(executable).resolve(strict=True))
    env = {"PATH": TRUSTED_COMMAND_PATH, "LC_ALL": "C", "LANG": "C"}
    timeout = command_timeout(COMMAND_TIMEOUT_SECONDS)
    process = subprocess.Popen(
        [executable, *argv[1:]],
        cwd="/",
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        close_fds=True,
        start_new_session=True,
    )
    stdout_bytes, stderr_bytes, stdout_truncated, stderr_truncated, timed_out = _drain_process(
        process, timeout, process_group=True
    )
    checkpoint()
    stdout = stdout_bytes.decode("utf-8", errors="replace")
    stderr = stderr_bytes.decode("utf-8", errors="replace")
    return {
        "status": "timeout" if timed_out else "captured" if process.returncode == 0 else "command_error",
        "argv": argv,
        "returncode": None if timed_out else process.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "stdout_truncated": stdout_truncated,
        "stderr_truncated": stderr_truncated,
    }


def run_read_only_command(argv: list[str]) -> dict[str, Any]:
    if not argv or argv[0] != Path(argv[0]).name or argv[0] not in ALLOWED_COMMANDS:
        raise ValueError("command is outside the v1 read-only allowlist")
    return _run_resolved_command(argv)


def _run_update_command(argv: list[str]) -> dict[str, Any]:
    if tuple(argv) not in UPDATE_COMMANDS.values():
        raise ValueError("package-status command is outside the fixed cache-only allowlist")
    return _run_resolved_command(argv)


def _os_release() -> dict[str, str]:
    checkpoint()
    result: dict[str, str] = {}
    path = Path("/etc/os-release")
    if not path.is_file():
        return result
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return result
    for line in lines:
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key in {"ID", "VERSION_ID", "PRETTY_NAME"}:
            result[key.lower()] = value.strip().strip('"')
    return result


def _hashed_machine_identity() -> dict[str, Any]:
    checkpoint()
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        if candidate.is_file():
            try:
                raw = candidate.read_bytes().strip()
            except OSError:
                continue
            return {"status": "observed", "sha256": sha256_bytes(raw), "source": candidate.as_posix()}
    return {"status": "unavailable", "sha256": None, "source": None}


def _account_posture() -> dict[str, Any]:
    checkpoint()
    try:
        entries = pwd.getpwall()
    except OSError as exc:
        return {
            "status": "unknown",
            "total_account_count": None,
            "uid0_account_count": None,
            "interactive_shell_account_count": None,
            "account_names_collected": False,
            "collector_method": "python_pwd_database_counts",
            "error": type(exc).__name__,
        }
    uid0 = [entry for entry in entries if entry.pw_uid == 0]
    interactive = [entry for entry in entries if entry.pw_shell not in {"", "/usr/sbin/nologin", "/sbin/nologin", "/bin/false"}]
    return {
        "status": "observed",
        "total_account_count": len(entries),
        "uid0_account_count": len(uid0),
        "interactive_shell_account_count": len(interactive),
        "account_names_collected": False,
        "collector_method": "python_pwd_database_counts",
    }


def _metadata_record(path: Path, admitted_modes: set[int], admitted_uid: int | None = None) -> dict[str, Any]:
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return {"status": "missing", "mode": None, "owner_uid": None, "admitted": True}
    except OSError as exc:
        return {"status": "unknown", "mode": None, "owner_uid": None, "admitted": False, "error": type(exc).__name__}
    mode = stat.S_IMODE(metadata.st_mode)
    regular = stat.S_ISREG(metadata.st_mode)
    admitted = regular and mode in admitted_modes and (admitted_uid is None or metadata.st_uid == admitted_uid)
    return {"status": "observed", "mode": f"{mode:04o}", "owner_uid": metadata.st_uid, "admitted": admitted}


def _privileged_access_posture() -> dict[str, Any]:
    checkpoint()
    incomplete = False
    try:
        accounts = pwd.getpwall()
    except OSError:
        accounts = []
        incomplete = True
    admin_names: set[str] = set()
    for group_name in ("sudo", "wheel"):
        try:
            group = grp.getgrnam(group_name)
        except KeyError:
            continue
        except OSError:
            incomplete = True
            continue
        admin_names.update(group.gr_mem)
        admin_names.update(entry.pw_name for entry in accounts if entry.pw_gid == group.gr_gid)
    admin_names.discard("root")

    key_file_count = 0
    unsafe_key_file_count = 0
    for entry in accounts:
        home = Path(entry.pw_dir)
        if not home.is_absolute():
            continue
        record = _metadata_record(home / ".ssh" / "authorized_keys", {0o600, 0o640}, entry.pw_uid)
        if record["status"] == "unknown":
            incomplete = True
        if record["status"] == "observed":
            key_file_count += 1
            if not record["admitted"]:
                unsafe_key_file_count += 1
    root_keys = _metadata_record(Path("/root/.ssh/authorized_keys"), {0o600, 0o640}, 0)
    if root_keys["status"] == "unknown":
        incomplete = True

    dropin_count = 0
    unsafe_sudoers = 0
    sudoers_dir = Path("/etc/sudoers.d")
    try:
        entries = list(sudoers_dir.iterdir()) if sudoers_dir.is_dir() else []
    except OSError:
        entries = []
        incomplete = True
    for entry in entries:
        record = _metadata_record(entry, {0o400, 0o440, 0o600}, 0)
        if record["status"] == "unknown":
            incomplete = True
        elif record["status"] == "observed":
            dropin_count += 1
            if not record["admitted"]:
                unsafe_sudoers += 1
    return {
        "status": "partial" if incomplete else "observed",
        "non_root_admin_group_member_count": len(admin_names),
        "authorized_key_file_count": key_file_count,
        "unsafe_authorized_key_file_count": unsafe_key_file_count,
        "root_authorized_keys": root_keys,
        "sudoers_dropin_file_count": dropin_count,
        "unsafe_sudoers_metadata_count": unsafe_sudoers,
        "direct_sudo_grants_assessed": False,
        "key_contents_collected": False,
        "sudoers_contents_collected": False,
    }


def _critical_file_metadata() -> dict[str, Any]:
    checkpoint()
    expected = {
        "/etc/passwd": {0o644},
        "/etc/group": {0o644},
        "/etc/shadow": {0o600, 0o640},
        "/etc/gshadow": {0o600, 0o640},
        "/etc/sudoers": {0o440},
    }
    records: list[dict[str, Any]] = []
    for filename, admitted_modes in expected.items():
        path = Path(filename)
        if not path.exists():
            records.append({"path": filename, "status": "missing", "mode": None, "owner": None, "group": None, "admitted": False})
            continue
        try:
            metadata = path.stat()
        except OSError as exc:
            records.append(
                {
                    "path": filename,
                    "status": "unknown",
                    "mode": None,
                    "owner": None,
                    "group": None,
                    "admitted": False,
                    "error": type(exc).__name__,
                }
            )
            continue
        mode = stat.S_IMODE(metadata.st_mode)
        try:
            owner = pwd.getpwuid(metadata.st_uid).pw_name
        except KeyError:
            owner = str(metadata.st_uid)
        try:
            group = grp.getgrgid(metadata.st_gid).gr_name
        except KeyError:
            group = str(metadata.st_gid)
        records.append(
            {
                "path": filename,
                "status": "observed",
                "mode": f"{mode:04o}",
                "owner": owner,
                "group": group,
                "admitted": mode in admitted_modes and metadata.st_uid == 0,
            }
        )
    overall = "observed" if all(item["status"] in {"observed", "missing"} for item in records) else "partial"
    return {"status": overall, "files": records, "file_contents_collected": False}


def _parse_key_values(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) == 2:
            result[parts[0].casefold()] = parts[1].strip()
    return result


def _ssh_posture(hostname: str) -> tuple[dict[str, Any], dict[str, Any]]:
    command = run_read_only_command(["sshd", "-T", "-C", f"user=root,host={hostname},addr=127.0.0.1"])
    values = _parse_key_values(command.get("stdout", "")) if command_complete(command) else {}
    posture = {
        "status": "observed" if all(values.get(k.replace("_", "")) in allowed for k, allowed in SSH_VALUES.items()) else "unknown",
        "permit_root_login": values.get("permitrootlogin", "unknown"),
        "password_authentication": values.get("passwordauthentication", "unknown"),
        "pubkey_authentication": values.get("pubkeyauthentication", "unknown"),
        "effective_configuration": bool(values),
        "evaluated_context": {"user": "root", "host": hostname, "addr": "127.0.0.1"},
    }
    return posture, command


def _nft_input_summary(evidence: dict[str, Any]) -> dict[str, Any]:
    """Project base-chain metadata; a base-chain accept is not a global verdict."""
    result: dict[str, Any] = {
        "status": "unknown", "input_chains": [], "input_coverage": "unknown",
        "inbound_policy": "unknown", "rule_count": 0, "allow_rule_count": 0,
    }
    if not command_complete(evidence):
        return result
    try:
        document = json.loads(evidence.get("stdout", ""))
    except (ValueError, TypeError, RecursionError):
        return result
    objects = document.get("nftables") if isinstance(document, dict) else None
    if not isinstance(objects, list) or any(not isinstance(item, dict) for item in objects):
        return result
    substantive = [item for item in objects if set(item) != {"metainfo"}]
    if not substantive:
        result.update(status="inactive", input_coverage="no_input_chains")
        return result
    chains: dict[tuple[str, str, str], dict[str, Any]] = {}
    for item in objects:
        chain = item.get("chain")
        if not isinstance(chain, dict) or chain.get("hook") != "input":
            continue
        names = [chain.get(key) for key in ("family", "table", "name")]
        if (any(not isinstance(value, str) or not value or len(value) > 255
                or any(ord(character) < 32 or 127 <= ord(character) <= 159 for character in value)
                for value in names)
                or chain.get("family") not in {"ip", "ip6", "inet", "arp", "bridge", "netdev"}
                or chain.get("type") not in {"filter", "nat", "route"}
                or chain.get("policy") not in {"accept", "drop"}
                or type(chain.get("prio")) is not int):
            return result
        key = tuple(names)
        if key in chains or len(chains) >= 200:
            return result
        chains[key] = {
            "family": chain["family"], "table": chain["table"], "chain": chain["name"],
            "type": chain["type"], "hook": "input", "priority": chain["prio"],
            "policy": chain["policy"], "rule_count": 0, "allow_rule_count": 0,
        }
    for item in objects:
        rule = item.get("rule")
        if not isinstance(rule, dict):
            continue
        names = [rule.get(key) for key in ("family", "table", "chain")]
        if not all(isinstance(value, str) for value in names):
            return result
        chain = chains.get(tuple(names))
        if chain is None:
            continue
        expressions = rule.get("expr")
        if not isinstance(expressions, list) or any(not isinstance(value, dict) for value in expressions):
            return result
        chain["rule_count"] += 1
        chain["allow_rule_count"] += int(any("accept" in expression for expression in expressions))
    records = [chains[key] for key in sorted(chains)]
    filters = [chain for chain in records if chain["type"] == "filter" and chain["family"] in {"ip", "ip6", "inet"}]
    families = {chain["family"] for chain in filters}
    full_coverage = "inet" in families or {"ip", "ip6"}.issubset(families)
    result.update(
        input_chains=records,
        input_coverage="ipv4_and_ipv6" if full_coverage else "ipv4_only" if families == {"ip"}
        else "ipv6_only" if families == {"ip6"} else "no_supported_input_chains",
        status="active" if filters else "unknown",
        rule_count=sum(chain["rule_count"] for chain in filters),
        allow_rule_count=sum(chain["allow_rule_count"] for chain in filters),
    )
    if full_coverage:
        # Preserve all chains when priorities/families overlap. Do not promote
        # one permissive chain to a host-wide default-allow finding.
        result["inbound_policy"] = "drop" if len(records) == 1 and records[0]["policy"] == "drop" else "managed"
    return result


def _firewall_posture() -> tuple[dict[str, Any], dict[str, Any]]:
    attempts = []
    states = []
    nft_summary: dict[str, Any] = {}
    for argv in (["ufw", "status", "verbose"], ["firewall-cmd", "--state"], ["nft", "--json", "list", "ruleset"]):
        evidence = run_read_only_command(argv)
        attempts.append(evidence)
        state = "unknown"
        if command_complete(evidence):
            value = evidence.get("stdout", "").strip().casefold()
            if argv[0] == "ufw":
                state = "active" if "status: active" in value else "inactive" if "status: inactive" in value else "unknown"
            elif argv[0] == "firewall-cmd":
                state = "active" if value == "running" else "inactive" if value == "not running" else "unknown"
            else:
                nft_summary = _nft_input_summary(evidence)
                state = nft_summary["status"]
        elif evidence.get("status") == "unavailable":
            state = "unavailable"
        states.append({"provider": argv[0], "status": state})
    active = [s for s in states if s["status"] == "active"]
    inactive = [s for s in states if s["status"] == "inactive"]
    unresolved = any(s["status"] == "unknown" for s in states)
    status = "active" if active else "inactive" if inactive and not unresolved else "unknown"
    provider = active[0]["provider"] if active else inactive[0]["provider"] if status == "inactive" else None
    inbound_policy = "unknown"
    inbound_rule_count = 0
    inbound_allow_rule_count = 0
    policy_source = None
    ufw = next((item for item in attempts if item["argv"][0] == "ufw" and command_complete(item)), None)
    if ufw and any(item == {"provider": "ufw", "status": "active"} for item in states):
        match = re.search(r"default:\s*(allow|deny|reject)\s*\(incoming\)", ufw["stdout"], re.IGNORECASE)
        if match:
            inbound_policy = match.group(1).casefold()
            policy_source = "ufw"
        inbound_rule_count = sum(1 for line in ufw["stdout"].splitlines() if re.search(r"\b(ALLOW|DENY|REJECT)\b", line))
        inbound_allow_rule_count = sum(1 for line in ufw["stdout"].splitlines() if re.search(r"\bALLOW\b", line))
    nft = next((item for item in attempts if item["argv"][0] == "nft" and command_complete(item)), None)
    if inbound_policy == "unknown" and nft:
        if nft_summary.get("inbound_policy") != "unknown":
            inbound_policy = nft_summary["inbound_policy"]
            policy_source = "nft"
            inbound_rule_count = nft_summary["rule_count"]
            inbound_allow_rule_count = nft_summary["allow_rule_count"]
            status = "active"
            provider = "nft"
    policy_attempts: list[dict[str, Any]] = []
    if inbound_policy == "unknown" and any(item == {"provider": "firewall-cmd", "status": "active"} for item in states):
        detail = run_read_only_command(["firewall-cmd", "--list-all"])
        policy_attempts.append(detail)
        if command_complete(detail):
            target = re.search(r"^\s*target:\s*(\S+)", detail["stdout"], re.MULTILINE | re.IGNORECASE)
            inbound_policy = "allow" if target and target.group(1).casefold() == "accept" else "managed"
            policy_source = "firewalld"
            rich_rules = False
            for line in detail["stdout"].splitlines():
                stripped = line.strip()
                if stripped.startswith(("services:", "ports:")):
                    count = len(stripped.split(":", 1)[1].split())
                    inbound_rule_count += count
                    inbound_allow_rule_count += count
                    rich_rules = False
                elif stripped.startswith("rich rules:"):
                    rich_rules = True
                elif rich_rules and stripped.startswith("rule "):
                    inbound_rule_count += 1
                    inbound_allow_rule_count += int("accept" in stripped.casefold())
                elif stripped and ":" in stripped:
                    rich_rules = False
    if status == "inactive" and inbound_policy == "unknown":
        inbound_policy = "allow"
        policy_source = "no_active_supported_host_firewall"
    return {
        "status": status,
        "provider": provider,
        "backend_states": states,
        "inbound_policy": inbound_policy,
        "inbound_rule_count": inbound_rule_count,
        "inbound_allow_rule_count": inbound_allow_rule_count,
        "policy_source": policy_source,
        "nft_input_chains": nft_summary.get("input_chains", []),
        "nft_input_coverage": nft_summary.get("input_coverage", "unknown"),
        "nft_rule_count_scope": "direct input base-chain rules; referenced chains were not traversed",
        "policy_scope": "declared input policies; not effective filtering, forwarding, NAT, or reachability",
        "rule_contents_collected": True,
    }, {"attempts": attempts, "policy_attempts": policy_attempts}


def _clock_posture() -> tuple[dict[str, Any], dict[str, Any]]:
    evidence = run_read_only_command(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    value = evidence.get("stdout", "").strip().casefold() if command_complete(evidence) else ""
    synchronized: bool | None = True if value == "yes" else False if value == "no" else None
    return {"status": "observed" if synchronized is not None else "unknown", "ntp_synchronized": synchronized}, evidence


def _listener_endpoint(line: str) -> dict[str, Any] | None:
    parts = line.split()
    if len(parts) < 5 or parts[0].casefold() not in {"tcp", "udp"}:
        return None
    local = parts[4]
    if ":" not in local:
        return None
    address, port_text = local.rsplit(":", 1)
    try:
        address = normalize_listener_address(address)
        port = int(port_text)
    except ValueError:
        return None
    if not address or not 1 <= port <= 65535:
        return None
    return {"transport": parts[0].casefold(), "address": address, "port": port}


def _listener_posture(expected_listeners: list[dict[str, Any]] | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    evidence = run_read_only_command(["ss", "-H", "-lntu"])
    lines = [line for line in evidence.get("stdout", "").splitlines() if line.strip()]
    actual = []
    unparsed_line_count = 0
    if command_complete(evidence):
        actual = [item for line in lines if (item := _listener_endpoint(line)) is not None]
        unparsed_line_count = len(lines) - len(actual)
        actual = [{"transport": transport, "address": address, "port": port} for transport, address, port in
                  sorted({(item["transport"], item["address"], item["port"]) for item in actual})]
    expected = normalize_expected_listeners(expected_listeners) if expected_listeners is not None else None
    actual_keys = {(item["transport"], item["address"], item["port"]) for item in actual}
    expected_keys = {(item["transport"], item["address"], item["port"]) for item in expected or []}
    as_records = lambda values: [{"transport": transport, "address": address, "port": port} for transport, address, port in sorted(values)]
    complete = command_complete(evidence) and unparsed_line_count == 0
    return {
        "status": "observed" if complete else "partial" if command_complete(evidence) else "unknown",
        "listener_count": len(actual) if command_complete(evidence) else 0,
        "unparsed_line_count": unparsed_line_count,
        "truncated": bool(evidence.get("stdout_truncated") or evidence.get("stderr_truncated")),
        "process_identifiers_collected": False,
        **({
            "actual_endpoints": actual,
            "expected_endpoints": expected,
            "unexpected_endpoints": as_records(actual_keys - expected_keys),
            "missing_endpoints": as_records(expected_keys - actual_keys) if complete else [],
        } if expected is not None else {}),
    }, evidence


def _service_posture() -> tuple[dict[str, Any], dict[str, Any]]:
    evidence = run_read_only_command(["systemctl", "--failed", "--no-legend", "--plain"])
    units = []
    for line in evidence.get("stdout", "").splitlines()[:200]:
        parts = line.split()
        if parts:
            units.append(parts[0])
    return {
        "status": "observed" if command_complete(evidence) else "unknown",
        "failed_unit_count": len(units),
        "failed_units": units,
        "truncated": len(evidence.get("stdout", "").splitlines()) > 200 or bool(evidence.get("stdout_truncated") or evidence.get("stderr_truncated")),
    }, evidence


def _update_rows(text: str) -> list[str]:
    ignored = ("last metadata", "available upgrades", "obsoleting", "security:", "update notice")
    return [line for line in text.splitlines() if line.strip() and not line.strip().casefold().startswith(ignored)]


def _update_failure(command: dict[str, Any]) -> tuple[str, str]:
    """Return fixed diagnostics, never fragments of package-manager output."""
    if command.get("status") == "unavailable":
        return "provider_unavailable", "No supported package-status command is available."
    if command.get("status") == "timeout":
        return "command_timeout", "Package-status query exceeded its time limit."
    if command.get("stdout_truncated") or command.get("stderr_truncated"):
        return "output_truncated", "Package-status output exceeded its capture limit."
    diagnostic = (command.get("stderr", "") + "\n" + command.get("stdout", "")).casefold()
    if any(value in diagnostic for value in ("permission denied", "are you root", "could not open lock")):
        return "permission_denied", "Package-status query could not access required local metadata."
    if any(value in diagnostic for value in ("unmet dependencies", "held broken packages", "dependency problems", "conflicting requests")):
        return "broken_dependencies", "Local package dependency state prevented the query."
    if any(value in diagnostic for value in ("unable to fetch some archives", "not enough cached data", "no cache", "no usable cache", "package lists or status file could not be parsed")):
        return "cache_unavailable", "Required local package metadata or cached archives were unavailable."
    return "command_failed", "Package-status command failed; no update count was established."


def _update_posture() -> tuple[dict[str, Any], dict[str, Any]]:
    attempts: list[dict[str, Any]] = []
    base: dict[str, Any] = {
        "status": "unknown", "provider": None, "available_update_count": None,
        "security_update_count": None, "reboot_required": Path("/var/run/reboot-required").exists(),
        "cache_only": True, "cache_freshness": "not_assessed", "package_names_collected": False,
        "security_classification": "unavailable",
    }

    def failed(provider: str | None, command: dict[str, Any], *, available: int | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
        category, reason = _update_failure(command)
        return {
            **base, "status": "partial" if available is not None else "unknown", "provider": provider,
            "available_update_count": available, "package_names_collected": available is not None,
            "command_status": command.get("status"), "returncode": command.get("returncode"),
            "error_category": category, "diagnostic_reason": reason,
        }, {"attempts": attempts}

    apt = _run_update_command(list(UPDATE_COMMANDS["apt"]))
    attempts.append(apt)
    if apt.get("status") != "unavailable":
        if not command_complete(apt):
            return failed("apt", apt)
        rows = [line for line in apt["stdout"].splitlines() if re.match(r"^Inst \S+", line)]
        summary = re.search(r"^(\d+) upgraded, (\d+) newly installed, \d+ to remove", apt["stdout"], re.MULTILINE)
        if ((not rows and not summary)
                or (summary and sum(int(value) for value in summary.groups()) != len(rows))):
            return {
                **base, "provider": "apt", "command_status": apt.get("status"), "returncode": apt.get("returncode"),
                "error_category": "unrecognized_output", "diagnostic_reason": "APT simulation output did not establish a planned update count.",
            }, {"attempts": attempts}
        return {
            **base, "status": "partial", "provider": "apt", "available_update_count": len(rows),
            "package_names_collected": True, "command_status": apt["status"], "returncode": apt["returncode"],
            "available_update_count_basis": "planned_upgrade_install_rows",
            "error_category": "security_classification_unavailable",
            "diagnostic_reason": "APT simulation does not establish a security-update count; local package index freshness was not assessed.",
        }, {"attempts": attempts}
    for provider in ("dnf", "yum"):
        all_updates = _run_update_command(list(UPDATE_COMMANDS[f"{provider}_all"]))
        attempts.append(all_updates)
        if all_updates.get("status") == "unavailable":
            continue
        usable_all = (all_updates.get("status") in {"captured", "command_error"}
                      and all_updates.get("returncode") in {0, 100}
                      and not all_updates.get("stdout_truncated") and not all_updates.get("stderr_truncated"))
        if not usable_all:
            return failed(provider, all_updates)
        available = len(_update_rows(all_updates["stdout"]))
        security_updates = _run_update_command(list(UPDATE_COMMANDS[f"{provider}_security"]))
        attempts.append(security_updates)
        usable_security = (security_updates.get("status") in {"captured", "command_error"}
                           and security_updates.get("returncode") in {0, 100}
                           and not security_updates.get("stdout_truncated") and not security_updates.get("stderr_truncated"))
        if not usable_security:
            return failed(provider, security_updates, available=available)
        return {
            **base, "status": "observed", "provider": provider, "available_update_count": available,
            "security_update_count": len(_update_rows(security_updates["stdout"])),
            "package_names_collected": True, "command_status": security_updates["status"],
            "returncode": security_updates["returncode"], "security_classification": "cached_advisory_query",
            "error_category": None, "diagnostic_reason": "Counts use existing local package metadata; freshness was not assessed.",
        }, {"attempts": attempts}
    return failed(None, attempts[-1])


def _hardening_posture() -> tuple[dict[str, Any], dict[str, Any]]:
    checkpoint()
    keys = ["kernel.unprivileged_bpf_disabled", "kernel.kptr_restrict", "kernel.dmesg_restrict", "fs.protected_hardlinks", "fs.protected_symlinks"]
    evidence: dict[str, Any] = {"commands": []}
    values: dict[str, str | None] = {}
    for key in keys:
        command = run_read_only_command(["sysctl", "-n", key])
        evidence["commands"].append(command)
        values[key] = command.get("stdout", "").strip() if command_complete(command) else None
    apparmor_path = Path("/sys/module/apparmor/parameters/enabled")
    try:
        apparmor = apparmor_path.read_text(encoding="utf-8", errors="replace").strip() if apparmor_path.is_file() else None
    except OSError:
        apparmor = None
    selinux_path = Path("/sys/fs/selinux/enforce")
    try:
        selinux = selinux_path.read_text(encoding="utf-8", errors="replace").strip() if selinux_path.is_file() else None
    except OSError:
        selinux = None
    observed_values = sum(value is not None for value in values.values())
    if observed_values == len(values):
        status = "observed"
    elif observed_values or apparmor is not None or selinux is not None:
        status = "partial"
    else:
        status = "unknown"
    return {
        "status": status,
        "sysctl": values,
        "apparmor_enabled": True if apparmor == "Y" else False if apparmor is not None else None,
        "selinux_enforcing": True if selinux == "1" else False if selinux is not None else None,
    }, evidence


def collect_live(*, asset_id: str, expected_listeners: list[dict[str, Any]] | None = None, profile_id: str = PROFILE_ID) -> tuple[dict[str, Any], dict[str, Any]]:
    if platform.system() != "Linux":
        raise RuntimeError("live collection is supported only on Linux")
    if expected_listeners is None:
        raise ValueError("expected listener policy is required for live collection")
    hostname = observed_hostname()
    clock, clock_evidence = _clock_posture()
    ssh, ssh_evidence = _ssh_posture(hostname)
    firewall, firewall_evidence = _firewall_posture()
    listeners, listener_evidence = _listener_posture(expected_listeners)
    services, service_evidence = _service_posture()
    updates, update_evidence = _update_posture()
    privileged_access = _privileged_access_posture()
    hardening, hardening_evidence = _hardening_posture()
    checkpoint()
    observations = {
        "schema": OBSERVATIONS_SCHEMA,
        "observed_at_utc": utc_now_text(),
        "target": {"hostname": hostname, "asset_id": asset_id},
        "profile_id": profile_id,
        "synthetic": False,
        "data_classification": "customer_host_posture",
        "sections": {
            "host_identity": {
                "status": "observed",
                "hostname": hostname,
                "kernel": platform.release(),
                "architecture": platform.machine(),
                "os_release": _os_release(),
                "machine_identity": _hashed_machine_identity(),
            },
            "clock": clock,
            "accounts": _account_posture(),
            "ssh": ssh,
            "firewall": firewall,
            "listeners": listeners,
            "privileged_access": privileged_access,
            "services": services,
            "hardening": hardening,
            "critical_files": _critical_file_metadata(),
            "updates": updates,
        },
        "command_evidence": {
            "clock": clock_evidence,
            "ssh": ssh_evidence,
            "firewall": firewall_evidence,
            "listeners": listener_evidence,
            "services": service_evidence,
            "updates": update_evidence,
            "hardening": hardening_evidence,
        },
        "declared_exclusions": [
            "processes",
            "process_command_lines",
            "process_environment",
            "credentials",
            "browser_data",
            "tokens",
            "private_keys",
            "user_documents",
            "event_logs",
            "memory",
            "network_discovery",
        ],
        "declared_side_effects": ["local_process_execution", "local_file_reads", "local_output_file_creation"],
    }
    posture = build_posture(observations)
    observations["command_evidence"] = delivery_command_evidence(observations["command_evidence"])
    return observations, posture


def collect_fixture(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    observations = json.loads(path.read_text(encoding="utf-8"))
    validate_observations(observations)
    posture = build_posture(observations)
    observations["command_evidence"] = delivery_command_evidence(observations["command_evidence"])
    return observations, posture


def delivery_command_evidence(value: Any) -> Any:
    """Retain execution metadata while excluding raw command output from delivery."""
    projected = copy.deepcopy(value)

    def omit_output(item: Any) -> Any:
        if isinstance(item, dict):
            result = {key: omit_output(child) for key, child in item.items()}
            if "stdout" in result or "stderr" in result:
                result["stdout"] = ""
                result["stderr"] = ""
                result["output_disposition"] = "omitted_after_local_parsing"
            return result
        if isinstance(item, list):
            return [omit_output(child) for child in item]
        return item

    return omit_output(projected)


def validate_observations(observations: Any, *, allow_live: bool = False) -> None:
    if not isinstance(observations, dict) or observations.get("schema") != OBSERVATIONS_SCHEMA:
        raise ValueError("unsupported fixture observations schema")
    required = {
        "observed_at_utc",
        "target",
        "profile_id",
        "sections",
        "command_evidence",
        "declared_exclusions",
        "declared_side_effects",
        "synthetic",
        "data_classification",
    }
    missing = sorted(required - set(observations))
    if missing:
        raise ValueError("fixture observations missing fields: " + ", ".join(missing))
    if observations["profile_id"] != PROFILE_ID:
        raise ValueError("fixture profile is outside v1")
    admitted_live = allow_live and observations["synthetic"] is False and observations["data_classification"] == "customer_host_posture"
    if not admitted_live and (observations["synthetic"] is not True or observations["data_classification"] != "synthetic_non_customer"):
        raise ValueError("fixture input must be explicitly marked synthetic_non_customer")
    if not isinstance(observations["target"], dict) or not observations["target"].get("hostname") or not observations["target"].get("asset_id"):
        raise ValueError("fixture target is incomplete")
    required_sections = {"host_identity", "clock", "accounts", "ssh", "firewall", "listeners", "privileged_access", "services", "hardening", "critical_files", "updates"}
    if not isinstance(observations["sections"], dict) or set(observations["sections"]) != required_sections:
        raise ValueError("fixture sections must exactly match the v1 required section set")


def build_posture(observations: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": POSTURE_SCHEMA,
        "observed_at_utc": observations["observed_at_utc"],
        "target": observations["target"],
        "profile_id": observations["profile_id"],
        "synthetic": observations["synthetic"],
        "data_classification": observations["data_classification"],
        "sections": assessed_sections(observations),
        "declared_exclusions": observations["declared_exclusions"],
        "declared_side_effects": observations["declared_side_effects"],
        "claim_boundary": "bounded local posture observations; not a security, compromise, or compliance conclusion",
    }
