"""Small operator front end; collection and verification stay in the existing engine."""
from __future__ import annotations

import argparse
import getpass
import ipaddress
import json
import os
import platform
import re
import shutil
import stat
import sys
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .authority import evaluate_authority, normalize_expected_listeners, normalize_listener_address, validate_authority_shape
from .canonical import canonical_json_bytes, parse_utc, sha256_bytes, sha256_file, write_json_new, write_text_new
from .collector import TRUSTED_COMMAND_PATH, observed_hostname
from .contracts import AUTHORITY_SCHEMA, PROFILE_ID, PROHIBITED_ARTIFACT_CLASSES, TOKEN_RE, TRUST_REGISTRY_SCHEMA

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

PURPOSES = ("witnessops_local_server_audit_receipt", "witnessops_local_server_audit_proofpack")
CONFIG_FIELDS = {"version", "authority", "public_key_id", "output"}
# Enough for the 200-endpoint contract even with long scoped IPv6 addresses.
MAX_LISTENER_ANSWER_CHARS = 64 * 1024
# Minimum working-space allowance for ordinary runs, not a maximum pack size
# or a reservation. Space may change after preflight.
MIN_OUTPUT_FREE_BYTES = 32 * 1024 * 1024


def _runtime_dependencies() -> None:
    try:
        from . import crypto  # noqa: F401; also checks cryptography's native runtime
    except ImportError as exc:
        raise RuntimeError(
            "Signing and verification runtime unavailable. Prepare Python 3.11+ with this release and its "
            "cryptography dependencies; for an offline host, use wheels matching its Python version, OS, and architecture."
        ) from exc


def assemble_product(**kwargs: Any) -> dict[str, Any]:
    from .package import assemble_product as assemble
    return assemble(**kwargs)


def verify_proofpack(proofpack: Path, signature: Path, registry: Path) -> dict[str, Any]:
    from .verifier import verify_proofpack as verify
    return verify(proofpack, signature, registry)


def _utc(value: datetime) -> str:
    return value.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _display(value: object) -> str:
    return "".join(c if c.isprintable() else "?" for c in str(value))


def _read(path: Path, *, private: bool = False, limit: int = 1024 * 1024) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    descriptor = os.open(path, flags)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError(f"Expected a bounded regular file: {_display(path)}")
        if private and (info.st_uid != os.geteuid() or info.st_mode & 0o077):
            raise PermissionError(f"Private file must be owned by this operator and mode 0600: {_display(path)}")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError("Configuration exceeds its size limit")
        return data
    finally:
        os.close(descriptor)


def _json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(_read(path))
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise ValueError(f"Invalid JSON configuration: {_display(path)}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {_display(path)}")
    return value


def _key(path: Path) -> Ed25519PrivateKey:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    try:
        raw = bytes.fromhex(_read(path, private=True, limit=4096).decode("ascii").strip())
        return Ed25519PrivateKey.from_private_bytes(raw)
    except (UnicodeError, ValueError) as exc:
        raise ValueError("Signing key must contain exactly 32 raw Ed25519 bytes in hex") from exc


def _directory(path: Path, *, create: bool = False) -> Path:
    path = path.expanduser().absolute()
    if create:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
        raise PermissionError(f"Use a real private directory owned by this operator (mode 0700): {_display(path)}")
    return path.resolve()


def _config_dir(args: argparse.Namespace) -> Path:
    return Path(args.config_dir).expanduser().absolute()


def _config(root: Path) -> tuple[dict[str, Any], Path]:
    root = _directory(root)
    config = _json(root / "config.json")
    if set(config) != CONFIG_FIELDS or config["version"] != 1:
        raise ValueError("Unsupported setup; run witnessops audit init")
    relative = config["authority"]
    if not isinstance(relative, str) or not re.fullmatch(r"scopes/[a-f0-9]{32}/authority.json", relative):
        raise ValueError("Invalid authority location; run witnessops audit init")
    authority_path = root / relative
    _directory(root / "scopes")
    _directory(authority_path.parent)
    if not isinstance(config["output"], str) or not Path(config["output"]).is_absolute():
        raise ValueError("Invalid output directory in setup")
    return config, authority_path


def _ask(label: str, default: str | None = None, *, limit: int = 256) -> str:
    while True:
        value = input(label + (f" [{_display(default)}]" if default is not None else "") + ": ").strip()
        value = value or default or ""
        if value and len(value) <= limit and all(c.isprintable() for c in value):
            return value
        print(f"Enter a non-empty, single-line value (up to {limit} characters).")


def _choice(label: str, choices: tuple[str, ...], default: str | None = None) -> str:
    while True:
        value = _ask(label + " (" + "/".join(choices) + ")", default).casefold()
        if value in choices:
            return value
        print("Choose " + ", ".join(choices) + ".")


def _port(value: str) -> int:
    if not value.isascii() or not value.isdigit() or not 1 <= int(value) <= 65535:
        raise ValueError("Ports must be integers from 1 to 65535")
    return int(value)


def _addresses(value: str) -> list[str]:
    addresses = [normalize_listener_address(part) for part in value.split(",")]
    if "*" in addresses:
        raise ValueError("Use explicit IPv4 or IPv6 bind addresses instead of *")
    if len(set(addresses)) != len(addresses):
        raise ValueError("Duplicate bind address")
    return addresses


def parse_listeners(value: str) -> list[dict[str, Any]]:
    """Bare ports explicitly mean TCP on IPv4 and IPv6 wildcard addresses."""
    if value.casefold() == "none":
        return []
    endpoints = []
    for token in value.split(","):
        token = token.strip()
        if token.isascii() and token.isdigit():
            endpoints.extend({"transport": "tcp", "address": address, "port": _port(token)} for address in ("0.0.0.0", "::"))
            continue
        match = re.fullmatch(r"(tcp|udp)://(\[[^\]]+\]|[^:]+):(\d+)", token)
        if not match:
            raise ValueError("Use ports such as 443, explicit tcp://127.0.0.1:8000 or udp://[::1]:53, or none")
        transport, address, port = match.groups()
        endpoints.append({"transport": transport, "address": _addresses(address)[0], "port": _port(port)})
    return normalize_expected_listeners(endpoints)


def _listener_text(endpoints: list[dict[str, Any]]) -> str:
    return ",".join(f"{e['transport']}://[{e['address']}]:{e['port']}" for e in endpoints) or "none"


def _listeners(saved: dict[str, Any] | None = None) -> tuple[str, list[dict[str, Any]]]:
    exposure = _choice("Expected SSH exposure", ("public", "private", "none"),
        saved["authority_source"]["operator_declaration"]["expected_ssh_exposure"] if saved else None)
    if saved:
        # Stored scope has a flat list, not a per-endpoint service role. Review
        # all endpoints together rather than guessing which saved port is SSH.
        print("Review the complete saved listener declaration, including SSH. Check its port and bind addresses explicitly; endpoint service roles were not stored.")
        while True:
            try:
                return exposure, parse_listeners(_ask("Expected listeners including SSH",
                    _listener_text(saved["target"]["expected_listeners"]), limit=MAX_LISTENER_ANSWER_CHARS))
            except ValueError as exc:
                print(_display(exc))
    endpoints: list[dict[str, Any]] = []
    if exposure != "none":
        while True:
            try:
                port = _port(_ask("SSH port", "22"))
                print("Declare exact local bind addresses. Wildcards do not prove internet reachability.")
                addresses = _addresses(_ask("SSH bind addresses, comma separated", "0.0.0.0,::" if exposure == "public" else None,
                    limit=MAX_LISTENER_ANSWER_CHARS))
                if exposure == "private" and any(ipaddress.ip_address(a).is_unspecified for a in addresses):
                    raise ValueError("Private SSH needs explicit interface or loopback addresses, not wildcard binds")
                endpoints = [{"transport": "tcp", "address": a, "port": port} for a in addresses]
                break
            except ValueError as exc:
                print(_display(exc))
    print("Other listeners: a bare port means TCP on 0.0.0.0 and ::. Use tcp://IP:PORT or udp://[IPv6]:PORT for exact binds; enter none explicitly.")
    while True:
        try:
            others = parse_listeners(_ask("Expected other listeners", limit=MAX_LISTENER_ANSWER_CHARS))
            return exposure, normalize_expected_listeners(endpoints + others)
        except ValueError as exc:
            print(_display(exc))


def _output_path(value: str, root: Path) -> Path:
    path = Path(value).expanduser().absolute()
    # Reject links in the operator-selected output hierarchy. System aliases such
    # as /tmp on macOS are allowed above the nearest existing parent.
    if path.is_symlink():
        raise ValueError("Output directory cannot be a symlink")
    resolved = path.resolve()
    if resolved == root or root in resolved.parents or resolved in root.parents:
        raise ValueError("Output and private configuration directories must be separate")
    parent = path
    while not parent.exists():
        parent = parent.parent
    if not parent.is_dir() or not os.access(parent, os.W_OK | os.X_OK):
        raise PermissionError("Output directory is not writable")
    if path.exists():
        _directory(path)
    return resolved


def command_init(args: argparse.Namespace) -> int:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from .crypto import private_key_hex, public_key_hex

    root = _config_dir(args)
    existing = root.exists() or root.is_symlink()
    if existing:
        root = _directory(root)
    current = None
    saved = None
    if (root / "config.json").exists():
        current, saved_path = _config(root)
        saved = _json(saved_path)
        errors = validate_authority_shape(saved)
        if errors or saved["authority_source"].get("kind") != "operator_declared_scope":
            raise ValueError("Saved scope cannot be reviewed by guided setup; preserve it and use a separate --config-dir")
    if current and (args.signing_key or args.public_key_id):
        raise ValueError("Setup already has signing material; use a separate --config-dir to import another signer")
    print("Local Audit setup. Enter non-secret scope details. These are operator declarations; the named authorizer is not independently authenticated.")
    if saved:
        print("Review the saved defaults. Authorization is renewed only after the final confirmation; existing keys and scope records are retained.")
        print("Previous authorization ends: " + _display(saved["authorization_window"]["ends_at_utc"]))
    declaration = saved["authority_source"]["operator_declaration"] if saved else {}
    hostname = _ask("Target hostname", saved["target"]["allowed_hostnames"][0] if saved else observed_hostname())
    if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", hostname) or len(hostname) > 253:
        raise ValueError("Enter an exact DNS hostname")
    customer = _ask("Customer", declaration.get("customer"))
    authorizer = _ask("Authorized by", saved["authority_source"]["authority_identity"] if saved else None)
    purpose = _ask("Purpose", declaration.get("purpose"))
    operator = _ask("Operator", saved["operator_id"] if saved else getpass.getuser())
    previous_hours = 24
    if saved:
        window = saved["authorization_window"]
        duration = (parse_utc(window["ends_at_utc"]) - parse_utc(window["starts_at_utc"])).total_seconds() / 3600
        if duration.is_integer() and 1 <= duration <= 720:
            previous_hours = int(duration)
    while True:
        hours = _ask("Authorization validity in hours", str(previous_hours))
        if hours.isascii() and hours.isdigit() and 1 <= int(hours) <= 720:
            break
        print("Enter 1 to 720 hours; expired scope is renewed with audit init.")
    exposure, endpoints = _listeners(saved)
    output = _output_path(args.output or (current["output"] if current else "./output"), root.resolve())
    now = datetime.now(timezone.utc)
    declaration = {"customer": customer, "purpose": purpose, "expected_ssh_exposure": exposure}
    identifier = uuid.uuid4().hex
    authority = {
        "schema": AUTHORITY_SCHEMA,
        "authorization_id": "AUTH-" + identifier,
        "case_id": "WO-" + now.strftime("%Y%m%d") + "-" + identifier[:8],
        "authority_source": {"kind": "operator_declared_scope", "authority_identity": authorizer,
            "approved_at_utc": _utc(now), "artifact_sha256": sha256_bytes(canonical_json_bytes(declaration)),
            "operator_declaration": declaration},
        "operator_id": operator,
        "target": {"asset_id": hostname, "allowed_hostnames": [hostname], "expected_listeners": endpoints},
        "profile_id": PROFILE_ID,
        "authorization_window": {"starts_at_utc": _utc(now), "ends_at_utc": _utc(now + timedelta(hours=int(hours)))},
        "execution_mode": "operator_present_local",
        "allowed_actions": ["read_only_posture_collection"],
        "prohibited_artifact_classes": sorted(PROHIBITED_ARTIFACT_CLASSES),
    }
    errors = validate_authority_shape(authority)
    if errors:
        raise ValueError("Invalid generated scope: " + "; ".join(errors))
    print(f"\nTarget: {hostname}\nCustomer: {customer}\nAuthorized by: {authorizer}\nPurpose: {purpose}")
    print("Expected listeners: " + _listener_text(endpoints))
    print("Authorization ends: " + authority["authorization_window"]["ends_at_utc"])
    if _choice("Confirm this authorization and read-only scope", ("yes", "no"), "no") != "yes":
        print("Setup cancelled. No files written.")
        return 2
    if current:
        key = _key(root / "signing-key.hex")
        key_id = current["public_key_id"]
        _check_trust(root / "trusted-keys.json", key, key_id)
    else:
        key = _key(Path(args.signing_key).expanduser()) if args.signing_key else Ed25519PrivateKey.generate()
        key_id = args.public_key_id or "audit_" + sha256_bytes(bytes.fromhex(public_key_hex(key.public_key())))[:16]
        if not isinstance(key_id, str) or not TOKEN_RE.fullmatch(key_id):
            raise ValueError("Public key ID must be a lowercase token")
        if any((root / name).exists() or (root / name).is_symlink() for name in ("signing-key.hex", "trusted-keys.json")):
            raise FileExistsError("Existing signing material has no completed setup; preserve it and use a different --config-dir")
    root = _directory(root, create=True)
    if not current:
        write_text_new(root / "signing-key.hex", private_key_hex(key) + "\n")
        write_json_new(root / "trusted-keys.json", {
            "schema": TRUST_REGISTRY_SCHEMA, "registry_id": "operator_local_registry", "version": 1,
            "keys": [{"public_key_id": key_id, "algorithm": "ed25519", "encoding": "hex",
                "public_key": public_key_hex(key.public_key()), "status": "active", "purposes": list(PURPOSES)}],
        })
    scopes = _directory(root / "scopes", create=True)
    scope_dir = _directory(scopes / identifier, create=True)
    write_json_new(scope_dir / "authority.json", authority)
    config = {"version": 1, "authority": f"scopes/{identifier}/authority.json", "public_key_id": key_id, "output": str(output)}
    temporary = root / ("config-" + uuid.uuid4().hex + ".tmp")
    try:
        write_json_new(temporary, config)
        os.replace(temporary, root / "config.json")
    finally:
        temporary.unlink(missing_ok=True)
    print(f"\nAUDIT READY\nConfiguration: {_display(root)}\nPublic trust registry: {_display(root / 'trusted-keys.json')}\nRun: witnessops audit run")
    print("Share the public trust registry with recipients through a separate trusted channel. Keep signing-key.hex private.")
    return 0


def _check_trust(path: Path, key: Ed25519PrivateKey, key_id: str) -> None:
    from .crypto import load_trusted_public_key, public_key_hex

    if not isinstance(key_id, str) or not TOKEN_RE.fullmatch(key_id):
        raise ValueError("Public key ID must be a lowercase token")
    data = _read(path)
    # Existing trust loader reads a file; stage the bounded bytes to keep both
    # purpose checks on the same registry without duplicating crypto logic.
    with tempfile.TemporaryDirectory(prefix="witnessops-audit-trust-") as temp:
        staged = Path(temp) / "registry.json"
        staged.write_bytes(data)
        for purpose in PURPOSES:
            trusted = load_trusted_public_key(staged, key_id, purpose)
            if public_key_hex(trusted) != public_key_hex(key.public_key()):
                raise ValueError("Signing key does not match the external trust registry")


def _runtime() -> None:
    if sys.version_info < (3, 11) or platform.system() != "Linux":
        raise ValueError("Live audit requires Linux with Python 3.11 or newer")
    if os.geteuid() != 0:
        raise PermissionError("Use the approved privileged operator session for full host collection")


def _required_commands() -> None:
    required = ("ss", "sshd", "sysctl", "systemctl", "timedatectl")
    missing = [name for name in required if not shutil.which(name, path=TRUSTED_COMMAND_PATH)]
    for group in (("ufw", "firewall-cmd", "nft"), ("apt-get", "dnf", "yum")):
        if not any(shutil.which(name, path=TRUSTED_COMMAND_PATH) for name in group):
            missing.append("one of " + "/".join(group))
    if missing:
        raise ValueError("Required commands unavailable: " + ", ".join(missing))


def command_run(args: argparse.Namespace) -> int:
    root = _config_dir(args)
    try:
        config, authority_path = _config(root)
    except (OSError, ValueError) as exc:
        print(f"✗ setup: {_display(exc)}\n\nAudit not started.\nRun: witnessops audit init")
        return 2
    checks: list[tuple[str, bool, str]] = []
    state: dict[str, Any] = {}

    def check(label: str, action: Any) -> None:
        try:
            action()
            checks.append((label, True, ""))
        except (OSError, ValueError, RuntimeError, TypeError, KeyError, RecursionError) as exc:
            checks.append((label, False, _display(exc)))

    def authority_check() -> None:
        authority = _json(authority_path)
        state["authority"] = authority
        errors = validate_authority_shape(authority)
        if errors:
            raise ValueError("; ".join(errors))
        admission = evaluate_authority(authority, observed_hostname=observed_hostname(), operator_id=authority["operator_id"])
        state["admission"] = admission
        if admission["decision"] != "ADMIT":
            raise ValueError("; ".join(admission["reasons"]))

    def listeners_check() -> None:
        target = state.get("authority", {}).get("target", {})
        if not isinstance(target, dict) or "expected_listeners" not in target:
            raise ValueError("Expected listener declaration missing; run witnessops audit init")
        normalize_expected_listeners(target["expected_listeners"])

    def output_check() -> None:
        output = _output_path(args.output or config["output"], root.resolve())
        parent = output
        while not parent.exists():
            parent = parent.parent
        free = shutil.disk_usage(parent).free
        if free < MIN_OUTPUT_FREE_BYTES:
            raise ValueError(f"Output space below the {MIN_OUTPUT_FREE_BYTES // (1024 * 1024)} MiB minimum allowance "
                f"({free // (1024 * 1024)} MiB available); free space or choose another --output directory")
        state["output"] = output

    check("Python/runtime and privileges", _runtime)
    check("signing key", lambda: state.update(key=_key(root / "signing-key.hex")))
    check("trust registry", lambda: _check_trust(root / "trusted-keys.json", state["key"], config["public_key_id"]))
    check("authority record and target identity", authority_check)
    check("expected listener declaration", listeners_check)
    check("required commands", _required_commands)
    check("output directory", output_check)
    for label, passed, detail in checks:
        print(("✓ " if passed else "✗ ") + label + (": " + detail if detail else ""))
    if not all(passed for _, passed, _ in checks):
        print("\nAudit not started.\nCorrect the listed prerequisites. For scope or listener changes, run: witnessops audit init")
        return 2
    output_root = _directory(state["output"], create=True)
    # Reserve a fresh run directory before any collection; old packs are never
    # overwritten even for repeated invocations within the same second.
    output = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-"), dir=output_root))
    authority = state["authority"]
    # An explicit `audit run` invokes the engine's existing live-approved path.
    built = assemble_product(authority=authority, admission=state["admission"], operator_id=authority["operator_id"],
        signing_key_path=root / "signing-key.hex", public_key_id=config["public_key_id"], output_root=output, live_approved=True)
    result = verify_proofpack(Path(built["proofpack"]), Path(built["signature"]), root / "trusted-keys.json")
    if result["status"] != "valid":
        print(f"\nAUDIT VERIFICATION FAILED\nProof pack: {_display(built['proofpack'])}\nDo not hand over this package.")
        return 1
    package_dir = Path(built["package_dir"])
    completeness = _json(package_dir / "evidence" / "collection-completeness.json")
    findings = _json(package_dir / "findings.json")
    sections = completeness["section_results"]
    count = sum(item["complete"] is True for item in sections)
    summary = " · ".join(f"{findings['counts'][s]} {s}" for s in ("critical", "high", "medium", "low", "informational") if findings["counts"].get(s)) or "none"
    print("\nAUDIT COMPLETE" + (" — PARTIAL COLLECTION" if not completeness["complete"] else ""))
    print(f"\nTarget: {_display(authority['target']['allowed_hostnames'][0])}\nCollection: {count}/{len(sections)} sections completed\nFindings: {summary}")
    if count != len(sections):
        print("Incomplete: " + ", ".join(item["section"] for item in sections if not item["complete"]))
        posture = _json(package_dir / "posture.json")
        for item in sections:
            if not item["complete"]:
                record = posture.get("sections", {}).get(item["section"], {})
                reason = record.get("diagnostic_reason")
                if isinstance(reason, str) and reason:
                    print(f"  {_display(item['section'])}: {_display(reason[:240])}" + ("..." if len(reason) > 240 else ""))
    print(f"\nProof pack:\n{_display(built['proofpack'])}\n\nSignature:\n{_display(built['signature'])}\n\nSHA-256:\n{sha256_file(Path(built['proofpack']))}\nSidecar: {_display(built['sha256'])}")
    print("\nVerification:\nPASS — package integrity and signature verified\n\nNote: verification confirms the evidence package, not that the server is secure.")
    return 0 if completeness["complete"] else 3


def command_verify(args: argparse.Namespace) -> int:
    registry = Path(args.trust_registry).expanduser() if args.trust_registry else _config_dir(args) / "trusted-keys.json"
    if not registry.is_file() or registry.is_symlink():
        raise ValueError("Public trust registry missing. Run audit init, or supply --trust-registry FILE obtained through a separate trusted channel")
    proofpack = Path(args.proofpack).expanduser().absolute()
    signature = Path(str(proofpack) + ".sig.json")
    if not signature.is_file():
        raise ValueError("Signature sidecar missing. Keep the original ZIP filename and its .zip.sig.json file together")
    # Never discover trust material inside or adjacent to the supplied package.
    result = verify_proofpack(proofpack, signature, registry)
    if result.get("status") != "valid":
        print("FAIL — evidence package verification failed")
        for name, item in result.get("checks", {}).items():
            if item.get("status") == "failed":
                print(f"{_display(name)}: {_display(item.get('detail', 'failed'))}")
        return 1
    print("PASS — package integrity and signature verified")
    print("Collection outcome: " + _display(result.get("outcome", "unknown")))
    print("Note: verification confirms the evidence package, not that the server is secure.")
    return 0


def command_capture(args: argparse.Namespace) -> int:
    from .capture import write_capture
    from .package import capture_product
    if not args.live_approved:
        raise ValueError("capture requires explicit --live-approved")
    _runtime_dependencies()
    _runtime()
    authority = _json(Path(args.authority))
    admission = evaluate_authority(authority, observed_hostname=observed_hostname(), operator_id=args.operator_id)
    if admission["decision"] != "ADMIT":
        raise ValueError("capture authority denied")
    normalize_expected_listeners(authority["target"]["expected_listeners"])
    _required_commands()
    output = _directory(Path(args.output).expanduser().absolute(), create=True)
    if shutil.disk_usage(output).free < MIN_OUTPUT_FREE_BYTES:
        raise ValueError("capture output requires at least 32 MiB free")
    destination = output / "capture.json"
    if destination.exists() or destination.is_symlink() or destination.with_name("capture.json.sha256").exists():
        raise FileExistsError("capture output already exists; choose a fresh private directory")
    data = capture_product(authority=authority, admission=admission, operator_id=args.operator_id, live_approved=True)
    digest = write_capture(destination, data)
    print("UNSIGNED CAPTURE — not authenticated proof")
    print("Capture SHA-256: " + digest)
    print("Capture: " + _display(destination))
    return 0


def command_finalize(args: argparse.Namespace) -> int:
    from .capture import read_capture
    from .canonical import write_bytes_new
    from .package import finalize_product
    data = read_capture(Path(args.capture), args.capture_sha256)
    print("Consuming unsigned capture SHA-256: " + args.capture_sha256)
    print("Digest correspondence does not authenticate the host or operator.")
    # Snapshot operator-selected public trust bytes, never trust from capture.
    registry = _read(Path(args.trust_registry))
    output = _directory(Path(args.output).expanduser().absolute(), create=True)
    with tempfile.TemporaryDirectory(prefix=".finalize-trust-", dir=output) as temp:
        pinned = Path(temp) / "registry.json"
        write_bytes_new(pinned, registry)
        key_path = Path(args.signing_key)
        _check_trust(pinned, _key(key_path), args.public_key_id)
        built = finalize_product(data, signing_key_path=key_path, public_key_id=args.public_key_id, output_root=output)
        result = verify_proofpack(Path(built["proofpack"]), Path(built["signature"]), pinned)
        if result["status"] != "valid":
            raise ValueError("final package verification failed; do not hand over")
    print("Final package verified against operator-selected trust; not a host security conclusion.")
    print("Proofpack: " + _display(built["proofpack"]))
    return 0


def add_split_commands(commands: Any) -> None:
    capture = commands.add_parser("capture", help="explicit keyless live capture; unsigned internal input only")
    capture.add_argument("--authority", required=True)
    capture.add_argument("--operator-id", required=True)
    capture.add_argument("--live-approved", action="store_true", required=True)
    capture.add_argument("--output", required=True, help="fresh private capture directory")
    capture.set_defaults(func=command_capture)
    finalize = commands.add_parser("finalize", help="offline reconstruction and signing; no target access")
    for option in ("capture", "capture-sha256", "signing-key", "public-key-id", "trust-registry", "output"):
        finalize.add_argument("--" + option, required=True)
    finalize.set_defaults(func=command_finalize)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="witnessops", description="WitnessOps operator tools")
    audit = parser.add_subparsers(dest="product", required=True).add_parser("audit", help="Local Server Audit")
    commands = audit.add_subparsers(dest="command", required=True)
    add_split_commands(commands)
    default_config = str(Path.home() / ".config" / "witnessops" / "audit")
    init = commands.add_parser("init", help="generate or renew scope through guided setup; reuse existing signing material")
    init.add_argument("--signing-key", help="import a private raw Ed25519 hex file into the private configuration directory")
    init.add_argument("--public-key-id", help="public key ID for an imported or newly generated signer")
    init.add_argument("--output", help="output directory (default: ./output at setup time)")
    init.set_defaults(func=command_init)
    run = commands.add_parser("run", help="explicitly start authorized local read-only collection after preflight")
    run.add_argument("--output", help="override the configured output directory for this run")
    run.set_defaults(func=command_run)
    verify = commands.add_parser("verify", help="verify a ZIP using a separately provisioned public trust registry")
    verify.add_argument("proofpack")
    verify.add_argument("--trust-registry", help="external public trust registry; defaults to this operator's setup")
    verify.set_defaults(func=command_verify)
    for command in (init, run, verify):
        command.add_argument("--config-dir", default=default_config, help="private setup directory")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        _runtime_dependencies()
        code = args.func(args)
    except (OSError, ValueError, RuntimeError, TypeError, KeyError, RecursionError) as exc:
        print("Audit error: " + _display(exc), file=sys.stderr)
        code = 1
    except (EOFError, KeyboardInterrupt):
        print("\nAudit cancelled.", file=sys.stderr)
        code = 2
    raise SystemExit(code)


if __name__ == "__main__":
    main()
