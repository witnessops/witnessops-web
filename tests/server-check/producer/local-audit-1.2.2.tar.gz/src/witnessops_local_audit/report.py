from __future__ import annotations

import json
from typing import Any

from .assessment import section_complete
from .contracts import REQUIRED_SECTION_STATUSES


MAX_REPORT_VALUE_CHARS = 1600
MAX_REPORT_VALUE_ITEMS = 12
MAX_REPORT_TEXT_CHARS = 240
REPORT_VALUE_FIELDS = frozenset({
    "transport", "address", "port", "path", "status", "owner", "group", "owner_uid", "mode",
    "admitted", "unsafe_file_count", "root_authorized_keys", "apparmor_enabled", "selinux_enforcing",
    "provider", "command_status", "returncode", "error_category", "diagnostic_reason", "cache_freshness",
    "security_classification", "truncated", "unparsed_line_count", "user", "host", "addr",
})


def markdown_literal(value: Any) -> str:
    """Render bounded untrusted text as one inert CommonMark code span."""
    text = str(value)
    if len(text) > MAX_REPORT_VALUE_CHARS:
        text = text[:MAX_REPORT_VALUE_CHARS] + " ... [truncated]"
    text = "".join(character if character.isprintable() else " " for character in text)
    longest = current = 0
    for character in text:
        current = current + 1 if character == "`" else 0
        longest = max(longest, current)
    fence = "`" * (longest + 1)
    return f"{fence} {text} {fence}"


def observed_literal(value: Any) -> str:
    """Show bounded finding metadata without command transcripts or arbitrary fields."""
    def bounded(item: Any, depth: int = 0) -> Any:
        if item is None or isinstance(item, (bool, int, float)):
            return item
        if isinstance(item, str):
            return item[:MAX_REPORT_TEXT_CHARS] + (" ... [truncated]" if len(item) > MAX_REPORT_TEXT_CHARS else "")
        if depth >= 3:
            return "[nested values omitted]"
        if isinstance(item, list):
            values = [bounded(child, depth + 1) for child in item[:MAX_REPORT_VALUE_ITEMS]]
            if len(item) > MAX_REPORT_VALUE_ITEMS:
                values.append(f"[{len(item) - MAX_REPORT_VALUE_ITEMS} more items omitted]")
            return values
        if isinstance(item, dict):
            # Only metadata fields emitted by the finding and gap projections are rendered.
            keys = [key for key in sorted(REPORT_VALUE_FIELDS) if key in item]
            values = {key: bounded(item[key], depth + 1) for key in keys[:MAX_REPORT_VALUE_ITEMS]}
            if len(item) > len(values):
                values["omitted"] = "additional fields omitted"
            return values
        return "[unsupported value omitted]"

    return markdown_literal(json.dumps(bounded(value), ensure_ascii=False, separators=(", ", ": ")))


def ssh_context_literal(posture: dict[str, Any]) -> str:
    context = posture.get("sections", {}).get("ssh", {}).get("evaluated_context")
    if not isinstance(context, dict) or not all(isinstance(context.get(key), str) and context[key] for key in ("user", "host", "addr")):
        return "Not recorded in the supplied posture; evaluation context is unknown."
    return observed_literal({key: context[key] for key in ("user", "host", "addr")})


def render_report(receipt: dict[str, Any], findings: dict[str, Any], posture: dict[str, Any]) -> str:
    counts = findings["counts"]
    outcome = receipt["result"]["outcome"]
    completeness_text = (
        "Every required v1 collection section reached its admitted complete status."
        if outcome == "pass"
        else "One or more required v1 collection sections is incomplete; inspect the signed failure states and collection-completeness artifact."
    )
    lines = [
        "# WitnessOps Local Server Audit",
        "",
        "## Result first",
        "",
        f"The bounded collection contract outcome is **{outcome.upper()}** for proof run {markdown_literal(receipt['proof_run_id'])}.",
        completeness_text,
        "This outcome concerns authority admission, bounded collection, artifact binding, and package construction. It is not a conclusion that the host is secure, uncompromised, or compliant.",
        "",
        "## Named target and boundary",
        "",
        f"- Asset id: {markdown_literal(posture['target']['asset_id'])}",
        f"- Observed hostname: {markdown_literal(posture['target']['hostname'])}",
        f"- Profile: {markdown_literal(posture['profile_id'])}",
        f"- Observed at: {markdown_literal(posture['observed_at_utc'])}",
        "- Execution: operator-present, local, read-only",
        "- Processes, command lines, environment variables, credentials, cookies, tokens, private keys, user documents, event logs, memory, and network discovery were excluded.",
        "",
        "## Deterministic posture findings",
        "",
        f"- Critical: {counts['critical']}",
        f"- High: {counts['high']}",
        f"- Medium: {counts['medium']}",
        f"- Low: {counts['low']}",
        f"- Informational: {counts['informational']}",
        "",
    ]
    if not findings["findings"]:
        lines.extend(["No deterministic v1 posture findings were emitted from the supplied observations.", ""])
    else:
        for item in findings["findings"]:
            lines.extend(
                [
                    f"### {item['severity'].upper()} — {markdown_literal(item['title'])}",
                    "",
                    f"- Finding id: {markdown_literal(item['finding_id'])}",
                    f"- State: {markdown_literal(item['state'])}",
                    f"- Evidence: {markdown_literal(item['evidence_refs'][0])}",
                    f"- Observed value: {observed_literal(item['observed_value'])}",
                    f"- Recommendation: {markdown_literal(item['recommendation'])}",
                    f"- Limit: {markdown_literal(item['claim_limit'])}",
                    "",
                ]
            )
    lines.extend([
        "## SSH evaluation context", "",
        f"- Evaluated SSH context: {ssh_context_literal(posture)}",
        "- Findings apply to the recorded evaluation context. Other users, source addresses and SSH Match contexts are outside this check.",
        "", "## Collection gaps", "",
    ])
    gaps = []
    for name in sorted(REQUIRED_SECTION_STATUSES):
        section = posture.get("sections", {}).get(name, {})
        if section_complete(name, section):
            continue
        detail = {key: section[key] for key in (
            "status", "provider", "command_status", "returncode", "error_category", "diagnostic_reason",
            "cache_freshness", "security_classification", "truncated", "unparsed_line_count",
        ) if isinstance(section, dict) and key in section}
        gaps.append(f"- {name}: {observed_literal(detail or {'status': 'not recorded'})}")
    lines.extend(gaps or ["No required collection gaps were identified from the supplied posture."])
    lines.extend([
        "", "Gap details summarize structured collection metadata. Raw command output is not reproduced; incomplete fields require review of the named posture and completeness artifacts.", "",
    ])
    lines.extend(
        [
            "## Verification path",
            "",
            "Use the delivered ZIP, detached signature, SHA-256 sidecar, and a separately obtained trust registry with `witnessops-local-audit verify`.",
            "The verifier checks bounded inputs, the ZIP signature, receipt signature, trust-registry key admission, portable ZIP and package-tree safety, receipt-to-manifest binding, artifact hashes, strict claim semantics, reconstructed collection completeness, compatibility receipt equality, prohibited-class declarations, and embedded verifier reconstruction.",
            "",
            "## Trust assumptions and unresolved gaps",
            "",
            "- The external authority source is represented by its declared identity and SHA-256 digest; v1 does not validate the source signer's identity.",
            "- The collector reports local observations; source-system honesty and kernel integrity are not independently established.",
            "- A package-provided public key is not a trust anchor. Trust comes from the separately supplied registry.",
            "- No network reachability, exploitability, compromise, historical activity, or compliance conclusion is included.",
            "",
        ]
    )
    return "\n".join(lines)


def render_buyer_walkthrough(run_id: str, zip_name: str, signature_name: str) -> str:
    return f"""# Buyer walkthrough — WitnessOps Local Server Audit

Proof run: `{run_id}`

## Files you should receive

- `{zip_name}` — deterministic proofpack bytes
- `{zip_name}.sha256` — transport digest
- `{signature_name}` — detached Ed25519 signature over the ZIP digest
- a WitnessOps trust registry obtained through a channel separate from the proofpack

## Independent reconstruction

1. Place the ZIP, signature, and separately obtained trust registry in an offline workspace.
2. Run `witnessops-local-audit verify --proofpack {zip_name} --signature {signature_name} --trust-registry trusted-keys.json`.
3. Require exit code `0` and result `status: valid`.
4. Inspect `outcome`: `pass` means every required v1 section was complete; `partial` names required collection gaps. Neither is a host-security grade.
5. Inspect every named check. A skipped check is not a passed check.
6. Read `report.md`, `findings.json`, `posture.json`, `evidence/collection-completeness.json`, and the declared exclusions.
7. Challenge any source observation, authority declaration, finding rule, or trust assumption that cannot be reconstructed.

## Meaning of `valid`

`valid` means the delivered bytes, signer binding, receipt, manifest, artifact hashes, and collection-outcome semantics passed the named verifier checks. It does not mean the host is secure, uncompromised, or compliant.
"""
