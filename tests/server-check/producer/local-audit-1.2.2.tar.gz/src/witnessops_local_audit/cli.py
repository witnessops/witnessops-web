from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .authority import evaluate_authority
from .canonical import load_json, parse_utc, sha256_file, write_json_new, write_text_new
from .collector import observed_hostname
from .crypto import create_test_key_material
from .package import AdmissionDenied, assemble_product
from .verifier import verify_core_package, verify_proofpack


def _print(value: object) -> None:
    print(json.dumps(value, indent=2, sort_keys=True))


def _fixture_hostname(path: Path) -> str:
    fixture = load_json(path)
    try:
        return fixture["target"]["hostname"]
    except (KeyError, TypeError) as exc:
        raise ValueError("fixture does not declare target.hostname") from exc


def _write_verification_output(output: Path, result: dict[str, object]) -> None:
    sidecar = output.with_name(output.name + ".sha256")
    existing = [path for path in (output, sidecar) if path.exists() or path.is_symlink()]
    if existing:
        raise FileExistsError("refusing to overwrite verifier output: " + ", ".join(str(path) for path in existing))
    write_json_new(output, result)
    try:
        write_text_new(sidecar, f"{sha256_file(output)}  {output.name}\n")
    except Exception:
        output.unlink(missing_ok=True)
        raise


def command_run(args: argparse.Namespace) -> int:
    authority = load_json(Path(args.authority))
    fixture = Path(args.fixture) if args.fixture else None
    hostname = _fixture_hostname(fixture) if fixture else observed_hostname()
    if args.evaluation_time and not fixture:
        raise ValueError("--evaluation-time is fixture-only and cannot alter a live authority decision")
    evaluation_time = parse_utc(args.evaluation_time) if args.evaluation_time else None
    admission = evaluate_authority(
        authority,
        observed_hostname=hostname,
        operator_id=args.operator_id,
        evaluation_time=evaluation_time,
    )
    try:
        result = assemble_product(
            authority=authority,
            admission=admission,
            operator_id=args.operator_id,
            signing_key_path=Path(args.signing_key),
            public_key_id=args.public_key_id,
            output_root=Path(args.output),
            fixture_path=fixture,
            live_approved=args.live_approved,
        )
    except AdmissionDenied as exc:
        _print({"status": "denied", "decision_artifact": str(exc.decision_path), "reasons": exc.reasons})
        return 2
    _print({"status": "assembled", **result})
    return 0


def command_verify(args: argparse.Namespace) -> int:
    result = verify_proofpack(Path(args.proofpack), Path(args.signature), Path(args.trust_registry))
    if args.output:
        _write_verification_output(Path(args.output), result)
    _print(result)
    return 0 if result["status"] == "valid" else 1


def command_verify_dir(args: argparse.Namespace) -> int:
    result = verify_core_package(
        Path(args.package_dir),
        trust_registry=Path(args.trust_registry),
        require_trust=True,
        check_embedded=True,
    )
    if args.output:
        _write_verification_output(Path(args.output), result)
    _print(result)
    return 0 if result["status"] == "valid" else 1


def command_test_keygen(args: argparse.Namespace) -> int:
    if not args.test_only:
        raise ValueError("test key generation requires the literal --test-only acknowledgement")
    create_test_key_material(Path(args.private_key), Path(args.trust_registry), args.public_key_id)
    _print(
        {
            "status": "synthetic_test_key_created",
            "private_key": args.private_key,
            "trust_registry": args.trust_registry,
            "boundary": "test-only material; not production signing authority",
        }
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="witnessops-local-audit", description="WitnessOps Local Server Audit v1")
    subparsers = parser.add_subparsers(dest="command", required=True)

    from .operator import add_split_commands
    add_split_commands(subparsers)
    run = subparsers.add_parser("run", help="admit authority, collect, and assemble a signed proofpack")
    run.add_argument("--authority", required=True)
    run.add_argument("--operator-id", required=True)
    run.add_argument("--signing-key", required=True)
    run.add_argument("--public-key-id", required=True)
    run.add_argument("--output", required=True)
    source = run.add_mutually_exclusive_group(required=True)
    source.add_argument("--fixture", help="synthetic observation fixture; no live collection")
    source.add_argument("--live-approved", action="store_true", help="explicitly authorize local read-only collection on this host")
    run.add_argument("--evaluation-time", help="fixture-only RFC3339 UTC time for deterministic authority evaluation")
    run.set_defaults(func=command_run)

    verify = subparsers.add_parser("verify", help="verify a proofpack ZIP and detached signature offline")
    verify.add_argument("--proofpack", required=True)
    verify.add_argument("--signature", required=True)
    verify.add_argument("--trust-registry", required=True)
    verify.add_argument("--output", help="write the verifier result and a SHA-256 sidecar")
    verify.set_defaults(func=command_verify)

    verify_dir = subparsers.add_parser("verify-dir", help="verify an extracted package directory with external trust")
    verify_dir.add_argument("--package-dir", required=True)
    verify_dir.add_argument("--trust-registry", required=True)
    verify_dir.add_argument("--output", help="write the verifier result and a SHA-256 sidecar")
    verify_dir.set_defaults(func=command_verify_dir)

    keygen = subparsers.add_parser("test-keygen", help="create synthetic fixture-only Ed25519 material")
    keygen.add_argument("--private-key", required=True)
    keygen.add_argument("--trust-registry", required=True)
    keygen.add_argument("--public-key-id", default="witnessops_lsa_synthetic_test_001")
    keygen.add_argument("--test-only", action="store_true", required=True)
    keygen.set_defaults(func=command_test_keygen)
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        code = args.func(args)
    except (FileNotFoundError, FileExistsError, PermissionError, ValueError, RuntimeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, sort_keys=True), file=sys.stderr)
        code = 1
    raise SystemExit(code)


if __name__ == "__main__":
    main()
