"""WitnessOps Local Server Audit v1."""

__version__ = "1.2.2"
