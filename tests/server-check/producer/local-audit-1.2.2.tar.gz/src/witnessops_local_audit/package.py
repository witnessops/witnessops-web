from __future__ import annotations

from .assessment import authorized_collection, check_observation_authority

import hashlib
import re
import os
import zipfile
from pathlib import Path
from typing import Any

from .assessment import section_complete

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .canonical import canonical_json_bytes, sha256_file, write_bytes, write_bytes_new, write_json, write_json_new, write_text_new
from .collector import collect_fixture, collect_live
from .authority import normalize_expected_listeners
from .contracts import (
    COLLECTION_COMPLETENESS_SCHEMA,
    CORE_MANIFEST_EXCLUSIONS,
    CORE_MANIFEST_POLICY,
    MANIFEST_VERSION,
    PROFILE_ID,
    RECEIPT_VERSION,
    REQUIRED_SECTION_STATUSES,
    RUN_RECORD_SCHEMA,
    WORKFLOW_CLASS,
)
from .crypto import build_detached_file_signature, load_private_key, public_key_record, sign_record
from .findings import derive_findings
from .report import render_buyer_walkthrough, render_report

ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)


class AdmissionDenied(RuntimeError):
    def __init__(self, decision_path: Path, reasons: list[str]):
        super().__init__("authority admission denied: " + "; ".join(reasons))
        self.decision_path = decision_path
        self.reasons = reasons


def source_fingerprint() -> str:
    digest = hashlib.sha256()
    root = Path(__file__).resolve().parent
    for path in sorted(root.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def build_run_id(observed_at_utc: str, authorization_id: str, asset_id: str) -> str:
    stamp = re.sub(r"[^0-9]", "", observed_at_utc)[:14]
    suffix = hashlib.sha256(f"{authorization_id}\0{asset_id}".encode("utf-8")).hexdigest()[:10]
    return f"pr_lsa_{stamp}_{suffix}"


def _artifact(path: Path, package_dir: Path, artifact_id: str, artifact_class: str, source_system: str) -> dict[str, Any]:
    relative = path.relative_to(package_dir).as_posix()
    return {
        "artifact_id": artifact_id,
        "artifact_type": "local_server_audit",
        "artifact_class": artifact_class,
        "source_system": source_system,
        "path": relative,
        "sha256": f"sha256:{sha256_file(path)}",
        "collector_method": "witnessops_local_server_audit_v1",
        "sensitivity": "medium" if artifact_class in {"host_observations", "host_posture", "posture_findings"} else "low",
    }


def evaluate_collection_completeness(posture: dict[str, Any]) -> dict[str, Any]:
    sections = posture.get("sections")
    if not isinstance(sections, dict):
        raise ValueError("posture sections are missing")
    section_results: list[dict[str, Any]] = []
    for section, admitted_statuses in sorted(REQUIRED_SECTION_STATUSES.items()):
        record = sections.get(section)
        status = record.get("status") if isinstance(record, dict) else None
        complete = status in admitted_statuses and section_complete(section, record)
        section_results.append(
            {
                "section": section,
                "observed_status": status,
                "admitted_complete_statuses": sorted(admitted_statuses),
                "complete": complete,
            }
        )
    complete = all(item["complete"] for item in section_results)
    return {
        "schema": COLLECTION_COMPLETENESS_SCHEMA,
        "profile_id": posture.get("profile_id"),
        "required_sections": sorted(REQUIRED_SECTION_STATUSES),
        "section_results": section_results,
        "complete": complete,
        "failure_states": [] if complete else ["required_collection_incomplete"],
        "claim_boundary": "collection completeness only; not host security, compromise, or compliance",
    }


def build_evidence_manifest(
    package_dir: Path,
    *,
    authority: dict[str, Any],
    admission: dict[str, Any],
    posture: dict[str, Any],
    collector_hash: str,
    public_key_id: str,
    run_id: str,
) -> dict[str, Any]:
    specs = [
        ("evidence/authority.json", "authority_record", "authority_record", "operator_supplied_authority_record"),
        ("evidence/admission-decision.json", "admission_decision", "authority_decision", "witnessops_authority_gate"),
        ("evidence/scope.json", "scope_record", "scope_record", "operator_supplied_authority_record"),
        ("evidence/run_record.json", "run_record", "run_record", "witnessops_local_server_audit_collector"),
        ("evidence/observations.json", "host_observations", "host_observations", "witnessops_local_server_audit_collector"),
        ("evidence/collection-completeness.json", "collection_completeness", "collection_completeness", "witnessops_local_server_audit_rules_v1"),
        ("posture.json", "host_posture", "host_posture", "witnessops_local_server_audit_collector"),
        ("findings.json", "posture_findings", "posture_findings", "witnessops_local_server_audit_rules_v1"),
        ("report.md", "buyer_report", "buyer_report", "witnessops_local_server_audit_rules_v1"),
        ("BUYER_WALKTHROUGH.md", "buyer_walkthrough", "buyer_walkthrough", "witnessops_local_server_audit_rules_v1"),
    ]
    artifacts = [_artifact(package_dir / filename, package_dir, artifact_id, artifact_class, source) for filename, artifact_id, artifact_class, source in specs]
    clock = posture["sections"].get("clock", {})
    return {
        "manifest_version": MANIFEST_VERSION,
        "workflow_class": WORKFLOW_CLASS,
        "proof_run_id": run_id,
        "source_systems": sorted({item["source_system"] for item in artifacts}),
        "authority": {
            "authorization_id": authority["authorization_id"],
            "case_id": authority["case_id"],
            "operator_id": authority["operator_id"],
            "collection_profile_id": authority["profile_id"],
            "authorization_window": {
                "start_utc": authority["authorization_window"]["starts_at_utc"],
                "end_utc": authority["authorization_window"]["ends_at_utc"],
            },
        },
        "target": {"claimed_hostname": admission["observed_hostname"], "asset_id": authority["target"]["asset_id"], "os_family": "linux"},
        "collector": {
            "name": "witnessops_local_server_audit",
            "version": "1.2.2",
            "hash": f"sha256:{collector_hash}",
            "signature_key_id": public_key_id,
            "signature_status": "not_supplied",
        },
        "launcher": {"type": "manual_terminal", "identifier": "operator_present_local", "boundary": "no autonomous or remote launch authority"},
        "collection_profile": {"profile_id": PROFILE_ID, "prohibited_classes": authority["prohibited_artifact_classes"]},
        "declared_exclusions": posture["declared_exclusions"],
        "declared_side_effects": posture["declared_side_effects"],
        "host_clock": {
            "trust_status": "unknown",
            "observed_timezone": "UTC",
            "notes": f"host reported ntp_synchronized={clock.get('ntp_synchronized')}; no independent time authority comparison was performed",
        },
        "artifacts": artifacts,
    }


def build_receipt(
    manifest: dict[str, Any],
    run_id: str,
    private_key: Ed25519PrivateKey,
    public_key_id: str,
    completeness: dict[str, Any],
) -> dict[str, Any]:
    evidence_refs = {
        "authority_record_exists": ["authority_record"],
        "operator_is_authorized": ["admission_decision", "authority_record"],
        "target_host_in_scope": ["admission_decision", "scope_record"],
        "collection_profile_bound": ["scope_record"],
        "launcher_boundary_declared": ["run_record"],
        "collector_hash_recorded": ["run_record"],
        "collector_signature_status_recorded": ["run_record"],
        "manifest_contains_all_artifacts": ["run_record"],
        "artifact_hashes_present": ["run_record"],
        "prohibited_artifacts_absent": ["scope_record", "host_observations"],
        "required_collection_sections_available": ["collection_completeness", "host_posture"],
        "host_clock_trust_declared": ["host_posture"],
        "known_side_effects_declared": ["host_observations"],
        "package_is_offline_verifiable": ["run_record"],
    }
    claims = []
    for claim, refs in sorted(evidence_refs.items()):
        status = "passed"
        if claim == "required_collection_sections_available" and not completeness["complete"]:
            status = "partial"
        claims.append({"claim": claim, "status": status, "evidence_refs": refs})
    outcome = "pass" if completeness["complete"] else "partial"
    unsigned = {
        "receipt_version": RECEIPT_VERSION,
        "workflow_class": WORKFLOW_CLASS,
        "proof_run_id": run_id,
        "result": {"outcome": outcome, "failure_states": completeness["failure_states"]},
        "claims": claims,
        "manifest_hash": f"sha256:{hashlib.sha256(canonical_json_bytes(manifest)).hexdigest()}",
    }
    return sign_record(unsigned, private_key, public_key_id)


def write_core_manifest(package_dir: Path) -> None:
    write_json(package_dir / "MANIFEST-POLICY.json", CORE_MANIFEST_POLICY)
    paths = [
        path for path in sorted(package_dir.rglob("*"))
        if path.is_file() and path.relative_to(package_dir).as_posix() not in CORE_MANIFEST_EXCLUSIONS
    ]
    lines = [f"{sha256_file(path)}  {path.relative_to(package_dir).as_posix()}" for path in paths]
    write_bytes(package_dir / "MANIFEST.sha256", ("\n".join(lines) + "\n").encode("utf-8"))


def deterministic_zip(package_dir: Path, zip_path: Path) -> None:
    files = [path for path in sorted(package_dir.rglob("*")) if path.is_file()]
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(zip_path, flags, 0o600)
    try:
        with os.fdopen(descriptor, "w+b") as handle:
            descriptor = -1
            with zipfile.ZipFile(handle, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as archive:
                for path in files:
                    relative = path.relative_to(package_dir).as_posix()
                    info = zipfile.ZipInfo(relative, ZIP_EPOCH)
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = 0o100600 << 16
                    info.create_system = 3
                    archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    finally:
        if descriptor >= 0:
            os.close(descriptor)


def assemble_product(
    *,
    authority: dict[str, Any],
    admission: dict[str, Any],
    operator_id: str,
    signing_key_path: Path,
    public_key_id: str,
    output_root: Path,
    fixture_path: Path | None = None,
    live_approved: bool = False,
) -> dict[str, str]:
    if (fixture_path is None) == (not live_approved):
        raise ValueError("select exactly one of fixture observations or explicit live approval")
    if admission["decision"] != "ADMIT":
        denied_dir = output_root / "denied"
        denied_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        authorization_label = str(admission.get("authorization_id") or "unknown")
        safe_label = hashlib.sha256(authorization_label.encode("utf-8")).hexdigest()[:16]
        decision_path = denied_dir / f"admission-denied-{safe_label}.json"
        write_json_new(decision_path, admission)
        raise AdmissionDenied(decision_path, admission["reasons"])

    # Preserve the one-shot key preflight before any collection.
    load_private_key(signing_key_path)
    # Compatibility orchestration; only one packaging implementation remains.
    capture = capture_product(authority=authority, admission=admission, operator_id=operator_id,
        fixture_path=fixture_path, live_approved=live_approved)
    return finalize_product(capture, signing_key_path=signing_key_path,
        public_key_id=public_key_id, output_root=output_root)


def capture_product(*, authority: dict[str, Any], admission: dict[str, Any], operator_id: str,
                    fixture_path: Path | None = None, live_approved: bool = False) -> bytes:
    from .capture import freeze_capture
    if (fixture_path is None) == (not live_approved):
        raise ValueError("select exactly one of fixture observations or explicit live approval")
    if admission.get("decision") != "ADMIT":
        raise ValueError("capture requires admitted authority")
    with authorized_collection(authority, operator_id, admission["observed_hostname"], live=fixture_path is None):
        observations, posture = (collect_fixture(fixture_path) if fixture_path else collect_live(
            asset_id=authority["target"]["asset_id"],
            expected_listeners=authority["target"]["expected_listeners"],
        ))
    check_observation_authority(authority, observations, operator_id)
    if observations["target"]["hostname"].strip().casefold() != admission["observed_hostname"].strip().casefold():
        raise ValueError("admitted hostname and collected hostname diverged")
    if observations["target"]["asset_id"] != authority["target"]["asset_id"]:
        raise ValueError("collected asset_id and authority asset_id diverged")
    expected_listeners = normalize_expected_listeners(authority["target"]["expected_listeners"])
    if posture.get("sections", {}).get("listeners", {}).get("expected_endpoints") != expected_listeners:
        raise ValueError("collected listener policy diverged from signed authority")

    from .canonical import utc_now_text
    return freeze_capture(authority=authority, admission=admission, operator_id=operator_id,
        observations=observations, collector_hash=source_fingerprint(),
        finished_at=utc_now_text() if live_approved else observations["observed_at_utc"],
        mode="live_approved" if live_approved else "fixture")


def finalize_product(capture: bytes, *, signing_key_path: Path, public_key_id: str,
                     output_root: Path) -> dict[str, str]:
    from .capture import validate_capture
    from .collector import build_posture
    frozen, admission = validate_capture(capture)
    authority, observations = frozen["authority"], frozen["observations"]
    operator_id, collector_hash = frozen["operator_id"], frozen["collector_hash"]
    posture = build_posture(observations)
    private_key = load_private_key(signing_key_path)
    completeness = evaluate_collection_completeness(posture)
    findings = derive_findings(posture)
    run_id = build_run_id(observations["observed_at_utc"], authority["authorization_id"], authority["target"]["asset_id"])
    output_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    package_dir = output_root / f"local-server-audit-{run_id}"
    zip_name = f"proofpack-{run_id}.zip"
    signature_name = f"{zip_name}.sig.json"
    zip_path = output_root / zip_name
    signature_path = output_root / signature_name
    sha_path = output_root / f"{zip_name}.sha256"
    existing_outputs = [path for path in (package_dir, zip_path, signature_path, sha_path) if path.exists() or path.is_symlink()]
    if existing_outputs:
        raise FileExistsError("refusing to overwrite existing output: " + ", ".join(str(path) for path in existing_outputs))
    package_dir.mkdir(mode=0o700)
    (package_dir / "evidence").mkdir(mode=0o700)

    scope = {
        "schema": "witnessops.local_server_audit.scope.v1",
        "authorization_id": authority["authorization_id"],
        "case_id": authority["case_id"],
        "operator_id": operator_id,
        "target": authority["target"],
        "profile_id": authority["profile_id"],
        "execution_mode": authority["execution_mode"],
        "allowed_actions": authority["allowed_actions"],
        "prohibited_artifact_classes": authority["prohibited_artifact_classes"],
    }
    run_record = {
        "schema": RUN_RECORD_SCHEMA,
        "proof_run_id": run_id,
        "authorization_id": authority["authorization_id"],
        "operator_id": operator_id,
        "observed_hostname": admission["observed_hostname"],
        "observed_at_utc": observations["observed_at_utc"],
        "collector": {"name": "witnessops_local_server_audit", "version": "1.2.2", "source_sha256": collector_hash, "signature_status": "not_supplied"},
        "execution": {"mode": frozen["mode"], "local_only": True, "read_only": True, "network_discovery": False},
        "input_classification": observations["data_classification"],
        "synthetic": observations["synthetic"],
        "authority_source_validation": "digest_and_declared_identity_recorded; external signer identity not independently validated",
    }
    write_json(package_dir / "evidence" / "authority.json", authority)
    write_json(package_dir / "evidence" / "admission-decision.json", admission)
    write_json(package_dir / "evidence" / "scope.json", scope)
    write_json(package_dir / "evidence" / "run_record.json", run_record)
    write_json(package_dir / "evidence" / "observations.json", observations)
    write_json(package_dir / "evidence" / "collection-completeness.json", completeness)
    write_json(package_dir / "posture.json", posture)
    write_json(package_dir / "findings.json", findings)

    report_context = {"proof_run_id": run_id, "result": {"outcome": "pass" if completeness["complete"] else "partial"}}
    write_text_new(package_dir / "report.md", render_report(report_context, findings, posture))
    write_text_new(package_dir / "BUYER_WALKTHROUGH.md", render_buyer_walkthrough(run_id, zip_name, signature_name))

    manifest = build_evidence_manifest(
        package_dir,
        authority=authority,
        admission=admission,
        posture=posture,
        collector_hash=collector_hash,
        public_key_id=public_key_id,
        run_id=run_id,
    )
    write_json(package_dir / "evidence_manifest.json", manifest)
    receipt = build_receipt(manifest, run_id, private_key, public_key_id, completeness)
    write_json(package_dir / "receipt.json", receipt)
    write_bytes_new(package_dir / "RECEIPT-COMPAT.json", (package_dir / "receipt.json").read_bytes())
    write_json(package_dir / "public_key.json", public_key_record(private_key, public_key_id))
    write_core_manifest(package_dir)

    from .verifier import verify_core_package

    core_result = verify_core_package(package_dir, trust_registry=None, require_trust=False, check_embedded=False)
    if core_result["status"] != "valid":
        raise RuntimeError("producer core verification failed: " + repr(core_result))
    write_json(package_dir / "verification_result.json", core_result)

    deterministic_zip(package_dir, zip_path)
    write_json_new(signature_path, build_detached_file_signature(zip_path, private_key, public_key_id))
    write_text_new(sha_path, f"{sha256_file(zip_path)}  {zip_name}\n")

    return {
        "proof_run_id": run_id,
        "package_dir": str(package_dir),
        "proofpack": str(zip_path),
        "signature": str(signature_path),
        "sha256": str(sha_path),
        "receipt": str(package_dir / "receipt.json"),
        "verification_result": str(package_dir / "verification_result.json"),
    }
