# Aegis (clean-room)

Deterministic local scanner for agent `SKILL.md` files.

**Provenance:** clean-room reconstruction from behavioral receipts after loss of an ephemeral App Builder tree. **Not** byte-identical to any prior implementation. See [PROVENANCE.md](./PROVENANCE.md).

**Identifier:** `aegis-deterministic@2.0.0-cleanroom.3`

## What it does

Given a skill document, Aegis runs a **local, deterministic** pipeline:

1. Parse / line mapping  
2. Documentary / meta / prohibition context (bounded clauses)  
3. Hidden Unicode reveal  
4. NFKC + selective confusable fold (detection aid only; original is authoritative)  
5. Rule families (injection, supply-chain, secrets, obfuscation, …)  
6. Bounded transfer composition (source + action + external sink; Phase 6: adjacent explicit-pronoun binding)  
7. Policy packs (Standard / Enterprise / Restricted / Research)  
8. Evidence + Markdown report  

Optional LLM review is **out of scope for this package core**. If a host UI adds “Ask Grok”, that opinion must never alter the deterministic verdict.

## What it does **not** claim

- Arbitrary skill safety or semantic understanding  
- Full Unicode TR39 / confusable completeness  
- Data-flow / taint analysis or general NLP  
- Cryptographic attestation of scans  

## Quick start

```bash
npm ci
npm test
npm run typecheck
npm run build
node dist/cli/scan.js path/to/SKILL.md standard
```

## Local package smoke (no publish)

```bash
npm ci
npm run build
npm pack
npm install ./aegis-deterministic-2.0.0-cleanroom.3.tgz
npx aegis-scan path/to/SKILL.md standard
```

Verifier identity in reports: `aegis-deterministic@2.0.0-cleanroom.3`.

## Policy packs

| Pack | Fail at | Review at |
|---|---|---|
| Standard | critical | high |
| Enterprise | high | medium |
| Restricted | medium | low |
| Research | critical | critical |

## Authority

`github.com/VaultSovereign/Aegis@<SHA>`
