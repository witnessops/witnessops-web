# Provenance

**Provenance: clean-room reconstruction from behavioral receipts and product requirements after loss of the original ephemeral App Builder source. This repository is not claimed to be byte-identical or source-identical to the earlier implementation.**

## Lineage

| Field | Value |
|---|---|
| Identifier | `aegis-deterministic@2.0.0-cleanroom.3` |
| Kind | Clean-room reconstruction |
| Not | Recovered Phase 1–4 App Builder source |
| Not | Byte-identical to any prior tree |

Prior phase receipts (conversation artifacts describing Phases 1–4) were used only as:

- behavioral requirements
- regression specifications
- product requirements
- known limitations
- fixture descriptions

They were **not** used as proof that this source matches the lost implementation.

## Classification of design decisions

| Tag | Meaning |
|---|---|
| `RECONSTRUCTED_FROM_RECEIPT` | Behavior required by prior receipts; implementation chosen fresh |
| `NEW_IMPLEMENTATION_CHOICE` | Structure or algorithm chosen for simplicity / testability |
| `UNKNOWN_ORIGINAL_BEHAVIOR` | Receipts did not specify detail; conservative choice documented |

## Authority

After the first verified push, durable authority is:

`github.com/VaultSovereign/Aegis@<FULL_COMMIT_SHA>`

Ephemeral local paths are not authority.

## Phase 5 (documentary / meta context)

Bounded clause-local classification for meta verbs, prohibition, quotation, example fences, and threat-model labels. Pattern findings and transfer composition share the same inactivity rules. No adjacent-sentence pronoun binding. No general NLP.

Identifier after Phase 5: `aegis-deterministic@2.0.0-cleanroom.2`

## Phase 6 (adjacent-pronoun transfer binding)

Bounded binding only: Sentence N contains an explicit recognized source; Sentence N+1 contains an explicit pronoun (`it`/`them`/`this`/`these`) plus transfer action and external sink. One adjacent sentence only. No general coreference, no multi-hop, no omitted pronouns. Ambiguous multi-class antecedents do not bind. Phase 5 documentary/prohibition/meta rules remain authoritative over both sentences.

Identifier after Phase 6: `aegis-deterministic@2.0.0-cleanroom.3`
