# OffSecShield Proof-Pack

Self-verifying evidence bundle. To verify offline on any machine with Python 3:

    python3 offsecshield.py verify <this-folder>

Or, if you only have this folder, recompute and compare against MANIFEST.sha256:

    while read h f; do echo "$(shasum -a 256 "$f" | awk '{print $1}')  $f"; done < MANIFEST.sha256

Authorship (if signed):

    python3 offsecshield.py verify-sig <this-folder> --trust <trusted-pubkey-hex>

Contents: evidence/ (posture, findings, drift, bound authority/scope), evidence_manifest.json,
RECEIPT.json (honest hashes, no fabrication), MANIFEST.sha256 (integrity over the bundle), and
RECEIPT.sig.json if signed — three authorities: integrity (manifest) + authorship (Ed25519) + time
(TSA token). LAB-GRADE crypto; swap Ed25519/TSA for vetted libs + RFC3161 before production.
