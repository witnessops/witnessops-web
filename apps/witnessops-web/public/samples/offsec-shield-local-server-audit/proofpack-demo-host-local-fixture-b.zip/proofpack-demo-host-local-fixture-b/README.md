# OffSecShield Proof-Pack

This is a public sample proofpack fixture. It demonstrates the structure of a receipt-backed audit package. It is not a live customer audit, not a production verification result, and not evidence that any third-party system was tested.

Synthetic fixture host `demo-host` from OffSecShield `run.sh`. Localhost and `127.0.0.1` values are synthetic fixture scope only.

This bundle is not a live customer audit, not a production verification result, and not evidence that any third-party system was tested. It is not verified by WitnessOps `/api/verify` unless a specific public verifier path is provided.

To verify offline on any machine with Python 3:

    python3 offsecshield.py verify <this-folder>

Or, if you only have this folder, recompute and compare against MANIFEST.sha256:

    while read h f; do echo "$(shasum -a 256 "$f" | awk '{print $1}')  $f"; done < MANIFEST.sha256

Authorship (if signed):

    python3 offsecshield.py verify-sig <this-folder> --trust <trusted-pubkey-hex>

Contents: evidence/ (posture, findings, drift, bound authority/scope), evidence_manifest.json,
RECEIPT.json (honest hashes, no fabrication), MANIFEST.sha256 (integrity over the bundle), and
RECEIPT.sig.json if signed. Signature metadata is sample/lab-grade only; swap Ed25519/TSA for vetted libs + RFC3161 before production.
