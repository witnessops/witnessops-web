If verification returns valid, it proves receipt integrity, signer trust against the supplied registry, and supplied source artifact hash consistency.

It does not prove the target is secure, the workflow was exhaustive, or every possible exposure was found.
