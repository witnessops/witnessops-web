A valid result checks the receipt signature against the supplied signer registry
and the bytes of every artifact in the receipt-bound source manifest, including
recorded evidence and authority documents. Trust in that registry is a separate
input. Matching bytes does not establish that an observation was true, that an
action was authorized in the source system, or that the system is secure today.

This historical sample does not establish current deployment state, absence of
authorization bypasses, complete endpoint coverage, legal compliance or a security
certification. The unsigned outer MANIFEST.sha256 is a file index, not signing authority.
