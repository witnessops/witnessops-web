stop_conditions:
  - unexpected_sensitive_data_exposed
  - command_requires_credentials
  - workflow_requires_intrusive_testing
