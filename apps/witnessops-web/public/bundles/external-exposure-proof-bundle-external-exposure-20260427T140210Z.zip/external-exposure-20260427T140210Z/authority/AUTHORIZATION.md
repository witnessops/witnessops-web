run_id: external-exposure-20260427T140210Z
target_owner: WitnessOps
operator: sovereign
authorized_target: witnessops.com
authorized_actions:
  - dns_resolution
  - tls_certificate_observation
  - http_header_observation
  - robots_txt_fetch
prohibited_actions:
  - exploitation
  - credential_collection
  - fuzzing
  - brute_force
  - form_submission
