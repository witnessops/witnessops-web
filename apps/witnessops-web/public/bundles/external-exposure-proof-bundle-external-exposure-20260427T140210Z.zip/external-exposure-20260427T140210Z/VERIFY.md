Run from bundle root.

Dependency: Python 3 with cryptography installed. One isolated option:

python3 -m venv .verify-venv
.verify-venv/bin/python -m pip install -r verifier/requirements.txt

Then verify:

.verify-venv/bin/python verifier/witnessops_verify_receipt.py \
  --receipt witnessops-receipt.json \
  --signature witnessops-receipt.sig \
  --manifest source/manifest.json \
  --hash-manifest source/hash-manifest.txt \
  --state source/state.json \
  --source-receipt source/receipt.json \
  --trusted-signers trusted-signers.json \
  --json

Expected: result = valid
