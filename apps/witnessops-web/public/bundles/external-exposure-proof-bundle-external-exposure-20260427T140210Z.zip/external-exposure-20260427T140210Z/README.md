# External Exposure Proof Bundle

Run ID: external-exposure-20260427T140210Z
Target: witnessops.com
Workflow: external-exposure-proof-run-v1

This bundle lets you verify that the signed receipt matches the supplied source artifacts.

Read CLAIM_BOUNDARY.md before relying on the result.
