stop_conditions:
  - endpoint requests credentials
  - unexpected data exposure
  - rate limiting triggers
  - any command requires POST/PUT/DELETE
  - any command requires credentials or token generation
