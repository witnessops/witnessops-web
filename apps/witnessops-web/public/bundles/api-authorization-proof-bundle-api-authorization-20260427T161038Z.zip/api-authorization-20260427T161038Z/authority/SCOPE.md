in_scope:
  - https://witnessops.com/api/receipts
  - https://witnessops.com/api/admin/intake/reconciliation-report
out_of_scope:
  - all other targets
  - credentialed access
  - unsafe HTTP methods
