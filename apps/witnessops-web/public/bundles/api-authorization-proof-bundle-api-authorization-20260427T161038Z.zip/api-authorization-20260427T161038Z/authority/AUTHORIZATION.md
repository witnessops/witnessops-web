run_id: api-authorization-20260427T161038Z
target: witnessops.com
operator: sovereign
workflow_id: api-authorization-proof-run-v1
class: authorization-boundary-check
allowed_actions:
  - http_get
  - http_head
  - token-less access checks
  - endpoint enumeration (non-invasive)
prohibited_actions:
  - credential use
  - token generation
  - brute force
  - fuzzing
  - POST/PUT/DELETE
  - auth bypass attempts
stop_conditions:
  - endpoint requests credentials
  - unexpected data exposure
  - rate limiting triggers
