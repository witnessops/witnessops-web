Run from bundle root:

python3 verifier/witnessops_verify_receipt.py \
  --receipt witnessops-receipt.json \
  --signature witnessops-receipt.sig \
  --manifest source/manifest.json \
  --hash-manifest source/hash-manifest.txt \
  --state source/state.json \
  --source-receipt source/receipt.json \
  --trusted-signers trusted-signers.json \
  --json

Expected: result = valid
