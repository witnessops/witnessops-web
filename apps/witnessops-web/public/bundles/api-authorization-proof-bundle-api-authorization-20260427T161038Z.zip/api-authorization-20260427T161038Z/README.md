# API Authorization Proof Bundle

Run ID: api-authorization-20260427T161038Z
Target: witnessops.com
Workflow: api-authorization-proof-run-v1
Class: authorization-boundary-check

This bundle lets you verify that the signed receipt matches the supplied source artifacts and token-less API authorization observations.

Read CLAIM_BOUNDARY.md before relying on the result.

Verifier maintenance, 7 September 2026: this download now checks every artifact
in the receipt-bound source manifest. Signed receipts, signatures, source files,
authority documents and captured evidence are unchanged. Files under verification/
are historical outputs from the original run, not a result of this repaired verifier.
Run the command in VERIFY.md to check the files in your downloaded copy.
