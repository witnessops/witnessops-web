# API Authorization Proof Bundle

Run ID: api-authorization-20260427T161038Z
Target: witnessops.com
Workflow: api-authorization-proof-run-v1
Class: authorization-boundary-check

This bundle lets you verify that the signed receipt matches the supplied source artifacts and token-less API authorization observations.

Read CLAIM_BOUNDARY.md before relying on the result.
